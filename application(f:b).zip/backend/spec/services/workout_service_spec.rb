require'rails_helper'

RSpec.describe WorkoutService, type: :service do

  describe "#get_exercise_time" do
    context "for a cardio exercise " do
      before(:each) do
        @exercise = FactoryGirl.create(:exercise, category: "cardio", modes: [create(:mode, value: "duration")])
        @user = FactoryGirl.create(:user)
        @service = WorkoutService.new(@user, {total_time: 30, location_id: @user.locations.first.id,
                                              category: "cardio", body_area_ids: [BodyArea.first.id]})
      end
      it { expect(@service.get_exercise_time(@exercise)).to equal(30) }
    end

    context "for exercise with mode duration and usage of endurance and intensity of 5" do
      before(:each) do
        @exercise = FactoryGirl.create(:exercise, category: "cross", modes: [create(:mode, value: "duration")])
        @user = FactoryGirl.create(:user, usage: create(:usage, value: "endurance"))
        @user.intensity = 5
        @service = WorkoutService.new(@user, {total_time: 30, location_id: @user.locations.first.id,
                                              category: "cross", body_area_ids: [BodyArea.first.id]})
      end

      it {expect(@service.get_exercise_time(@exercise)).to equal(300)}
    end
  end

  describe "#create_routine" do
    context "when a user with a small location with one equipment chooses a strenth for one body area" do

      before(:each) do
        @ba = BodyArea.all.first
        @eq = Equipment.all.first
        @user = FactoryGirl.create(:user)
        @user.locations.first.equipment_ids = [@eq.id]
        @user.locations.first.update_attribute(:space_id, 1)
        @service = WorkoutService.new(@user, {total_time: 3000, location_id: @user.locations.first.id,
                                              category: "strength", body_area_ids: [@ba.id], name: "MyWorkout"})
        @service.create_routine
      end

      it { expect(@service.routine.name).to eq("MyWorkout") }
    end
  end

  describe "#build_exercises" do
    context "when a user with a small location with one equipment chooses a strenth for one body area" do

      before(:each) do
        @ba = BodyArea.all.first
        @eq = Equipment.all.first
        @user = FactoryGirl.create(:user)
        @user.locations.first.equipment_ids = [@eq.id]
        @user.locations.first.update_attribute(:space_id, 1)
        @service = WorkoutService.new(@user, {total_time: 30, location_id: @user.locations.first.id,
                                              category: "strength", body_area_ids: [@ba.id]})
        @service.build_exercises
      end

      it do
        @service.body_area_exercises.flatten.each do |e|
          if !e.equipments.empty?
            expect(e.equipments.map(&:id)).to include(@eq.id)
          end
          expect(e.body_areas.map(&:id)).to include(@ba.id)
        end
      end

    end
  end
end
