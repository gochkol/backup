FactoryGirl.define do
  factory :exercise do
    name "Exercise Name"
    category "strength"
    alt_name "Alternate Name"
    link "http://some.link.com"
    body_areas {[create(:body_area)]}
    muscles {[create(:muscle)]}
    modes {[create(:mode)]}
    space 
  end
end
