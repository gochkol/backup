FactoryGirl.define do
  factory :department_member do
    user_id 1
department_id 1
role_id 1
  end

end
