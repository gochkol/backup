FactoryGirl.define do
  factory :routine do
    name "MyString"
  end

end
