FactoryGirl.define do
  factory :workout do
    name "MyString"
routine_id 1
user_id 1
  end

end
