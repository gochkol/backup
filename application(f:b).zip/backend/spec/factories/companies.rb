FactoryGirl.define do
  factory :company do
    name "MyString"
  end

end
