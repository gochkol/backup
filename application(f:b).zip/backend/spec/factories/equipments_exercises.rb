FactoryGirl.define do
  factory :equipments_exercise do
    
  end

end
