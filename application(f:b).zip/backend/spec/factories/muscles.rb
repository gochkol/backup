FactoryGirl.define do
  factory :muscle do
    name "Muscle Name"
    value "muscle_value"
  end

end
