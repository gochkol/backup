FactoryGirl.define do
  factory :value_set do
    block_set_id 1
values ""
  end

end
