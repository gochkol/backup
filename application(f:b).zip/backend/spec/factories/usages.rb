FactoryGirl.define do
  factory :usage do
    name "MyString"
    value "MyString"
  end

end
