FactoryGirl.define do
  factory :body_part_stat do
    body_part_id 1
data 1.5
user_id 1
is_current false
  end

end
