FactoryGirl.define do
  factory :transaction do
    user_id 1
  end

end
