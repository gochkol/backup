FactoryGirl.define do
  factory :body_area do
    name "Upper Body"
    value "upper_body"
  end

end
