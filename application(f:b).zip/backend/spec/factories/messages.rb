FactoryGirl.define do
  factory :message do
    text "MyString"
message_type "MyString"
  end

end
