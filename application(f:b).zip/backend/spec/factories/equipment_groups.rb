FactoryGirl.define do
  factory :equipment_group do
    name "MyString"
value "MyString"
  end

end
