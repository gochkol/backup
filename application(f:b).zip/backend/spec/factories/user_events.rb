FactoryGirl.define do
  factory :user_event do
    user_id 1
event_type "MyString"
data ""
  end

end
