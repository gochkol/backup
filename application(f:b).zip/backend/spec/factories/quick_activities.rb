FactoryGirl.define do
  factory :quick_activity do
    name "MyString"
value "MyString"
is_distance false
  end

end
