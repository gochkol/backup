FactoryGirl.define do
  factory :body_part do
    name "MyString"
value "MyString"
  end

end
