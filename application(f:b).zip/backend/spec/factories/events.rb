FactoryGirl.define do
  factory :event do
    eventable_id 1
eventable_type "MyString"
  end

end
