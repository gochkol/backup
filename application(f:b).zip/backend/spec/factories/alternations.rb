FactoryGirl.define do
  factory :alternation do
    name "MyString"
value "MyString"
  end

end
