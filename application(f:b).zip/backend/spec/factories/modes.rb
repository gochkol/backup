FactoryGirl.define do
  factory :mode do
    name "MyString"
    value "MyString"
  end

end
