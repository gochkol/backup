FactoryGirl.define do
  factory :plan do
    code "MyString"
name "MyString"
description "MyString"
price_cents 1
duration_days 1
plan_type "MyString"
  end

end
