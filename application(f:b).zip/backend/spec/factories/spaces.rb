FactoryGirl.define do
  factory :space do
    name "MyString"
value "MyString"
  end

end
