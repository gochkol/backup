FactoryGirl.define do
  factory :exercises_muscle do
    
  end

end
