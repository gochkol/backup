FactoryGirl.define do

  sequence :email do |n|
    "email_#{rand(10000000)}_#{n}@example.com"
  end

  factory :user do
    first_name "Johan"
    last_name  "Kellum"
    email
    password "asdfasdf"
    password_confirmation "asdfasdf"
    birth_year 1974
    birth_month 2
    birth_day 11
    gender "male"
    experience 1
    intensity 2
    usage { create(:usage, value: "strength") }
  end

end
