FactoryGirl.define do
  factory :quick_log do
    quick_activity_id 1
duration 1
user_id 1
  end

end
