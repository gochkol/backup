FactoryGirl.define do
  factory :subscription do
    user_id 1
  end

end
