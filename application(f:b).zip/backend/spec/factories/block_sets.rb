FactoryGirl.define do
  factory :block_set do
    rank 1
block_id 1
exercise_id 1
  end

end
