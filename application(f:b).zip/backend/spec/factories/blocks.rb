FactoryGirl.define do
  factory :block do
    kind "MyString"
rank 1
routine_id 1
  end

end
