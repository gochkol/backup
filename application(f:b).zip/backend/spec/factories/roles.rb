FactoryGirl.define do
  factory :role do
    name "MyString"
  end

end
