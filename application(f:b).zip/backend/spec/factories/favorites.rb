FactoryGirl.define do
  factory :favorite do
    user_id 1
routine_id 1
name "MyString"
  end

end
