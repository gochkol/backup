FactoryGirl.define do
  factory :location do
    name "MyString"
space_id 1
  end

end
