FactoryGirl.define do
  factory :category do
    name "MyString"
value "MyString"
  end

end
