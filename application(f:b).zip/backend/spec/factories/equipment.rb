FactoryGirl.define do
  factory :equipment do
    name "MyString"
value "MyString"
  end

end
