FactoryGirl.define do
  factory :friend_request do
    user nil
friend nil
  end

end
