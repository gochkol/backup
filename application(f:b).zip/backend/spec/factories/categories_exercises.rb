FactoryGirl.define do
  factory :categories_exercise do
    
  end

end
