FactoryGirl.define do
  factory :comment do
    user_id 1
event_id 1
comment_text "MyString"
  end

end
