FactoryGirl.define do
  factory :team_member do
    user_id 1
team_id 1
role_id 1
  end

end
