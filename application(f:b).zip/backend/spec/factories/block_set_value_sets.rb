FactoryGirl.define do
  factory :block_set_value_set do
    workout_id 1
block_set_id 1
value_set_id 1
  end

end
