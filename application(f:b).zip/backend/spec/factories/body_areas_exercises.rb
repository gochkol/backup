FactoryGirl.define do
  factory :body_areas_exercise do
    
  end

end
