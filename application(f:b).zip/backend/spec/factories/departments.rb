FactoryGirl.define do
  factory :department do
    name "MyString"
  end

end
