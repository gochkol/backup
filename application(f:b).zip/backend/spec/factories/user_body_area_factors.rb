FactoryGirl.define do
  factory :user_body_area_factor do
    user_id 1
body_area_id 1
mr 1.5
mw 1.5
  end

end
