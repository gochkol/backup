FactoryGirl.define do
  factory :money_log do
    api_call "MyString"
params ""
result "MyText"
  end

end
