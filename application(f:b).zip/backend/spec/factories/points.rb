FactoryGirl.define do
  factory :point do
    name "MyString"
point_type "MyString"
point_data ""
number_of 1
  end

end
