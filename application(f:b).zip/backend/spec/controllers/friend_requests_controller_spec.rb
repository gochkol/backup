require 'rails_helper'

RSpec.describe FriendRequestsController, type: :controller do

end
