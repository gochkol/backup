
Location.destroy_all
FriendRequest.destroy_all
Friendship.destroy_all

User.destroy_all
u = User.create( email: "asdf@asdf.asdf", password: "asdfasdf", password_confirmation: "asdfasdf",
            first_name: "Johan", last_name: "Kellum",
            birth_year: 1974, birth_month: 2, birth_day: 11,
            gender: "male", experience: 2, intensity: 6, usage: Usage.find_by_value("strength"), admin: true)
u2 = User.create( email: "johankellum@gmail.com", password: "asdfasdf", password_confirmation: "asdfasdf",
            first_name: "User1", last_name: "Kellum",
            birth_year: 1974, birth_month: 2, birth_day: 11,
            gender: "male", experience: 2, intensity: 6, usage: Usage.find_by_value("strength"))
u3 = User.create( email: "qwer3@asdf.asdf", password: "asdfasdf", password_confirmation: "asdfasdf",
            first_name: "User2", last_name: "Kellum",
            birth_year: 1974, birth_month: 2, birth_day: 11,
            gender: "male", experience: 2, intensity: 6, usage: Usage.find_by_value("strength"))
u4 = User.create( email: "qwer4@asdf.asdf", password: "asdfasdf", password_confirmation: "asdfasdf",
            first_name: "user3", last_name: "Kellum",
            birth_year: 1974, birth_month: 2, birth_day: 11,
            gender: "male", experience: 2, intensity: 6, usage: Usage.find_by_value("strength"))

u.friends << u2
u2.friends << u
Point.destroy_all
Event.destroy_all
QuickLog.destroy_all
Company.destroy_all
Role.destroy_all
Department.destroy_all
Team.destroy_all
Comment.destroy_all



Role.destroy_all
Role.create(name: "owner")
Role.create(name: "member")

Company.destroy_all
c = Company.create(name: "UpdownTech")
#c.members << User.all

Department.destroy_all
da = Department.create(name: "Dept A", company: c)
db = Department.create(name: "Dept B", company: c)

ta = Team.create(name: "team a", department: da, company: c)
tb = Team.create(name: "team b", department: db, company: c)

#TeamMember.create(member: u, team: ta, role: Role.first)
#TeamMember.create(member: u2, team: ta, role: Role.first)
#TeamMember.create(member: u3, team: tb, role: Role.first)
#TeamMember.create(member: u4, team: tb, role: Role.first)


