# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20160119172116) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"
  enable_extension "pg_stat_statements"

  create_table "alternations", force: :cascade do |t|
    t.string   "name"
    t.string   "value"
    t.datetime "created_at",                null: false
    t.datetime "updated_at",                null: false
    t.boolean  "is_active",  default: true
  end

  add_index "alternations", ["value"], name: "index_alternations_on_value", using: :btree

  create_table "billing_plans", force: :cascade do |t|
    t.string   "code"
    t.string   "name"
    t.string   "description"
    t.integer  "price_cents"
    t.string   "duration_type"
    t.integer  "duration_number"
    t.boolean  "is_active",         default: true
    t.string   "billing_plan_type", default: "subscription"
    t.datetime "created_at",                                 null: false
    t.datetime "updated_at",                                 null: false
  end

  create_table "block_set_value_sets", force: :cascade do |t|
    t.integer  "workout_id"
    t.integer  "block_set_id"
    t.integer  "value_set_id"
    t.datetime "created_at",   null: false
    t.datetime "updated_at",   null: false
  end

  create_table "block_sets", force: :cascade do |t|
    t.integer  "rank"
    t.integer  "block_id"
    t.integer  "exercise_id"
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
  end

  create_table "blocks", force: :cascade do |t|
    t.string   "block_type"
    t.integer  "rank"
    t.integer  "workout_id"
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
    t.json     "block_data"
    t.integer  "exercise_id"
  end

  create_table "body_areas", force: :cascade do |t|
    t.string   "name"
    t.string   "value"
    t.datetime "created_at",                null: false
    t.datetime "updated_at",                null: false
    t.integer  "parent_id"
    t.boolean  "is_active",  default: true
  end

  add_index "body_areas", ["value"], name: "index_body_areas_on_value", using: :btree

  create_table "body_areas_exercises", force: :cascade do |t|
    t.integer "exercise_id",  null: false
    t.integer "body_area_id", null: false
  end

  add_index "body_areas_exercises", ["body_area_id", "exercise_id"], name: "index_body_areas_exercises_on_body_area_id_and_exercise_id", using: :btree

  create_table "body_part_stats", force: :cascade do |t|
    t.integer  "body_part_id"
    t.float    "data"
    t.integer  "user_id"
    t.boolean  "is_current"
    t.datetime "created_at",   null: false
    t.datetime "updated_at",   null: false
  end

  create_table "body_parts", force: :cascade do |t|
    t.string   "name"
    t.string   "value"
    t.datetime "created_at",                null: false
    t.datetime "updated_at",                null: false
    t.boolean  "is_active",  default: true
  end

  create_table "body_stats", force: :cascade do |t|
    t.string   "name"
    t.float    "data"
    t.integer  "user_id"
    t.boolean  "is_current", default: false
    t.datetime "created_at",                 null: false
    t.datetime "updated_at",                 null: false
    t.string   "value"
  end

  create_table "categories", force: :cascade do |t|
    t.string   "name"
    t.string   "value"
    t.datetime "created_at",                null: false
    t.datetime "updated_at",                null: false
    t.boolean  "is_active",  default: true
  end

  create_table "categories_exercises", force: :cascade do |t|
    t.integer "exercise_id", null: false
    t.integer "category_id", null: false
  end

  add_index "categories_exercises", ["category_id", "exercise_id"], name: "index_categories_exercises_on_category_id_and_exercise_id", using: :btree
  add_index "categories_exercises", ["exercise_id", "category_id"], name: "index_categories_exercises_on_exercise_id_and_category_id", using: :btree

  create_table "comments", force: :cascade do |t|
    t.integer  "user_id"
    t.integer  "event_id"
    t.string   "comment_text"
    t.datetime "created_at",                  null: false
    t.datetime "updated_at",                  null: false
    t.boolean  "is_active",    default: true
  end

  create_table "companies", force: :cascade do |t|
    t.string   "name"
    t.datetime "created_at",                 null: false
    t.datetime "updated_at",                 null: false
    t.integer  "total_points",   default: 0
    t.integer  "monthly_points", default: 0
    t.integer  "daily_points",   default: 0
  end

  create_table "company_members", force: :cascade do |t|
    t.integer  "user_id"
    t.integer  "company_id"
    t.integer  "role_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "department_members", force: :cascade do |t|
    t.integer  "user_id"
    t.integer  "department_id"
    t.integer  "role_id"
    t.datetime "created_at",    null: false
    t.datetime "updated_at",    null: false
  end

  create_table "departments", force: :cascade do |t|
    t.string   "name"
    t.integer  "company_id"
    t.datetime "created_at",                 null: false
    t.datetime "updated_at",                 null: false
    t.integer  "total_points",   default: 0
    t.integer  "monthly_points", default: 0
    t.integer  "daily_points",   default: 0
    t.string   "signup_code"
  end

  create_table "equipment_groups", force: :cascade do |t|
    t.string   "name"
    t.string   "value"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "equipments", force: :cascade do |t|
    t.string   "name"
    t.string   "value"
    t.datetime "created_at",                        null: false
    t.datetime "updated_at",                        null: false
    t.integer  "equipment_group_id"
    t.boolean  "is_active",          default: true
  end

  create_table "equipments_exercises", force: :cascade do |t|
    t.integer "exercise_id",  null: false
    t.integer "equipment_id", null: false
  end

  add_index "equipments_exercises", ["equipment_id", "exercise_id"], name: "index_equipments_exercises_on_equipment_id_and_exercise_id", using: :btree
  add_index "equipments_exercises", ["exercise_id", "equipment_id"], name: "index_equipments_exercises_on_exercise_id_and_equipment_id", using: :btree

  create_table "equipments_locations", id: false, force: :cascade do |t|
    t.integer "location_id",  null: false
    t.integer "equipment_id", null: false
  end

  add_index "equipments_locations", ["equipment_id", "location_id"], name: "index_equipments_locations_on_equipment_id_and_location_id", using: :btree
  add_index "equipments_locations", ["location_id", "equipment_id"], name: "index_equipments_locations_on_location_id_and_equipment_id", using: :btree

  create_table "events", force: :cascade do |t|
    t.integer  "user_id"
    t.datetime "created_at",                null: false
    t.datetime "updated_at",                null: false
    t.string   "sentence"
    t.string   "event_type"
    t.json     "event_data"
    t.integer  "comment_count", default: 0
    t.json     "v2_event_data"
  end

  create_table "exercises", force: :cascade do |t|
    t.string   "name"
    t.integer  "experience"
    t.string   "alt_name"
    t.string   "link"
    t.integer  "alternation_id"
    t.integer  "space_id"
    t.integer  "mode_id"
    t.datetime "created_at",                          null: false
    t.datetime "updated_at",                          null: false
    t.integer  "base"
    t.integer  "inc"
    t.float    "rate"
    t.integer  "popularity"
    t.float    "technique"
    t.integer  "primary_body_area_id"
    t.string   "animation_sequence"
    t.float    "met"
    t.integer  "base_weight"
    t.boolean  "is_active",            default: true
    t.string   "keys"
  end

  add_index "exercises", ["popularity", "experience", "primary_body_area_id", "space_id"], name: "index_name_500", using: :btree
  add_index "exercises", ["popularity", "experience", "space_id"], name: "index_exercises_on_popularity_and_experience_and_space_id", using: :btree

  create_table "exercises_muscles", force: :cascade do |t|
    t.integer "exercise_id", null: false
    t.integer "muscle_id",   null: false
  end

  add_index "exercises_muscles", ["exercise_id", "muscle_id"], name: "index_exercises_muscles_on_exercise_id_and_muscle_id", using: :btree
  add_index "exercises_muscles", ["muscle_id", "exercise_id"], name: "index_exercises_muscles_on_muscle_id_and_exercise_id", using: :btree

  create_table "favorites", force: :cascade do |t|
    t.integer  "user_id"
    t.string   "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer  "workout_id"
  end

  create_table "friend_requests", force: :cascade do |t|
    t.integer  "user_id"
    t.integer  "friend_id"
    t.string   "status"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "friendships", force: :cascade do |t|
    t.integer  "user_id"
    t.integer  "friend_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "joins", force: :cascade do |t|
  end

  create_table "levels", force: :cascade do |t|
    t.integer "min_points"
    t.integer "max_points"
    t.string  "name"
    t.integer "value"
    t.string  "icon_name"
    t.integer "next_level_points"
  end

  add_index "levels", ["min_points"], name: "index_levels_on_min_points", using: :btree

  create_table "locations", force: :cascade do |t|
    t.string   "name"
    t.integer  "space_id"
    t.datetime "created_at",                 null: false
    t.datetime "updated_at",                 null: false
    t.integer  "user_id"
    t.boolean  "is_guest",   default: false
  end

  create_table "locations_users", id: false, force: :cascade do |t|
    t.integer "location_id", null: false
    t.integer "user_id",     null: false
  end

  add_index "locations_users", ["location_id", "user_id"], name: "index_locations_users_on_location_id_and_user_id", using: :btree
  add_index "locations_users", ["user_id", "location_id"], name: "index_locations_users_on_user_id_and_location_id", using: :btree

  create_table "messages", force: :cascade do |t|
    t.string   "text"
    t.string   "message_type"
    t.datetime "created_at",   null: false
    t.datetime "updated_at",   null: false
  end

  create_table "modes", force: :cascade do |t|
    t.string   "name"
    t.string   "value"
    t.datetime "created_at",                null: false
    t.datetime "updated_at",                null: false
    t.boolean  "is_active",  default: true
  end

  add_index "modes", ["value"], name: "index_modes_on_value", using: :btree

  create_table "modifiers", force: :cascade do |t|
    t.integer "user_id"
    t.string  "name"
    t.string  "modifier_type"
    t.float   "value",         default: 1.0
  end

  add_index "modifiers", ["user_id", "modifier_type"], name: "index_modifiers_on_user_id_and_modifier_type", using: :btree

  create_table "money_logs", force: :cascade do |t|
    t.string   "api_call"
    t.text     "result"
    t.integer  "user_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "muscles", force: :cascade do |t|
    t.string   "name"
    t.string   "value"
    t.datetime "created_at",                null: false
    t.datetime "updated_at",                null: false
    t.boolean  "is_active",  default: true
  end

  add_index "muscles", ["value"], name: "index_muscles_on_value", using: :btree

  create_table "points", force: :cascade do |t|
    t.string   "name"
    t.string   "point_type"
    t.json     "point_data"
    t.integer  "number_of",     default: 0
    t.integer  "user_id"
    t.datetime "created_at",                null: false
    t.datetime "updated_at",                null: false
    t.datetime "earned_at"
    t.string   "sentence"
    t.json     "v2_point_data"
  end

  create_table "quick_activities", force: :cascade do |t|
    t.string   "name"
    t.string   "value"
    t.boolean  "is_distance"
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
  end

  create_table "quick_logs", force: :cascade do |t|
    t.integer  "quick_activity_id"
    t.integer  "duration"
    t.integer  "user_id"
    t.datetime "created_at",                    null: false
    t.datetime "updated_at",                    null: false
    t.string   "desc"
    t.integer  "calories_burned"
    t.integer  "point_id"
    t.integer  "distance_miles",    default: 0
  end

  create_table "roles", force: :cascade do |t|
    t.string   "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "routines", force: :cascade do |t|
    t.string   "name"
    t.datetime "created_at",     null: false
    t.datetime "updated_at",     null: false
    t.json     "request_params"
  end

  create_table "spaces", force: :cascade do |t|
    t.string   "name"
    t.string   "value"
    t.datetime "created_at",                null: false
    t.datetime "updated_at",                null: false
    t.boolean  "is_active",  default: true
  end

  create_table "subscriptions", force: :cascade do |t|
    t.integer  "billing_plan_id"
    t.integer  "billing_day_of_month"
    t.date     "billing_period_end_date"
    t.date     "billing_period_start_date"
    t.integer  "current_billing_cycle"
    t.integer  "days_past_due"
    t.integer  "failure_count"
    t.string   "braintree_id"
    t.date     "next_billing_date"
    t.float    "next_billing_period_amount"
    t.integer  "number_of_billing_cycles"
    t.date     "paid_through_date"
    t.string   "payment_method_token"
    t.float    "price"
    t.string   "status"
    t.datetime "created_at",                 null: false
    t.datetime "updated_at",                 null: false
    t.date     "first_billing_date"
    t.integer  "old_user_id"
  end

  create_table "team_members", force: :cascade do |t|
    t.integer  "user_id"
    t.integer  "team_id"
    t.integer  "role_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "teams", force: :cascade do |t|
    t.string   "name"
    t.integer  "company_id"
    t.integer  "department_id"
    t.datetime "created_at",                 null: false
    t.datetime "updated_at",                 null: false
    t.integer  "total_points",   default: 0
    t.integer  "monthly_points", default: 0
    t.integer  "daily_points",   default: 0
    t.string   "signup_code"
  end

  create_table "usages", force: :cascade do |t|
    t.string   "name"
    t.string   "value"
    t.datetime "created_at",                null: false
    t.datetime "updated_at",                null: false
    t.boolean  "is_active",  default: true
  end

  create_table "user_body_area_factors", force: :cascade do |t|
    t.integer  "user_id"
    t.integer  "body_area_id"
    t.float    "mr"
    t.float    "mw"
    t.datetime "created_at",   null: false
    t.datetime "updated_at",   null: false
  end

  add_index "user_body_area_factors", ["user_id", "body_area_id", "created_at"], name: "helpful_index", using: :btree
  add_index "user_body_area_factors", ["user_id", "created_at"], name: "index_user_body_area_factors_on_user_id_and_created_at", using: :btree

  create_table "user_events", force: :cascade do |t|
    t.integer  "user_id"
    t.string   "event_type"
    t.json     "data"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "users", force: :cascade do |t|
    t.string   "first_name"
    t.string   "last_name"
    t.date     "birthdate"
    t.string   "gender"
    t.string   "email",                                null: false
    t.string   "password_digest",                      null: false
    t.datetime "created_at",                           null: false
    t.datetime "updated_at",                           null: false
    t.integer  "usage_id"
    t.integer  "intensity"
    t.integer  "experience"
    t.integer  "birth_year"
    t.integer  "birth_month"
    t.integer  "birth_day"
    t.datetime "points_updated_at"
    t.integer  "daily_points",        default: 0
    t.integer  "monthly_points",      default: 0
    t.integer  "total_points",        default: 0
    t.string   "remember_token"
    t.string   "username"
    t.boolean  "admin",               default: false
    t.json     "settings"
    t.string   "signup_code"
    t.boolean  "is_active",           default: true
    t.string   "password_reset_code"
    t.string   "avatar_url"
    t.string   "country_code"
    t.string   "state_code"
    t.string   "city"
    t.string   "zipcode"
    t.string   "current_status"
    t.datetime "current_status_at"
    t.integer  "category_id"
    t.boolean  "is_guest",            default: false
    t.integer  "level_id"
    t.string   "content_level",       default: "free"
    t.string   "subscription_id"
    t.integer  "billing_plan_id"
    t.string   "billing_customer_id"
  end

  create_table "value_sets", force: :cascade do |t|
    t.integer  "block_set_value_set_id"
    t.json     "values"
    t.datetime "created_at",             null: false
    t.datetime "updated_at",             null: false
  end

  create_table "workouts", force: :cascade do |t|
    t.string   "name"
    t.integer  "user_id"
    t.datetime "created_at",                                    null: false
    t.datetime "updated_at",                                    null: false
    t.json     "request_params"
    t.integer  "calories_burned",             default: 0
    t.datetime "finished_at"
    t.integer  "category_id"
    t.string   "format_version"
    t.integer  "finished_total_time_seconds", default: 0
    t.integer  "total_time_seconds",          default: 0
    t.json     "equipment_ids"
    t.json     "body_area_ids"
    t.json     "bae"
    t.string   "workout_type",                default: "quick"
    t.integer  "point_id"
  end

  add_index "workouts", ["user_id", "finished_at", "workout_type"], name: "index_workouts_on_user_id_and_finished_at_and_workout_type", using: :btree
  add_index "workouts", ["user_id", "finished_at"], name: "index_workouts_on_user_id_and_finished_at", using: :btree
  add_index "workouts", ["user_id", "workout_type"], name: "index_workouts_on_user_id_and_workout_type", using: :btree

end
