class AddIndexToBodyAreaFactors < ActiveRecord::Migration
  def change
    add_index :user_body_area_factors, [:user_id, :created_at]
  end
end
