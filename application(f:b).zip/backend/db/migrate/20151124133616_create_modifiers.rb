class CreateModifiers < ActiveRecord::Migration
  def change
    create_table :modifiers, force: :cascade do |t|
      t.integer :user_id
      t.string  :name
      t.string  :modifier_type
      t.float   :value, default: 1.0
      t.index   [:user_id, :modifier_type]
    end
    User.all.map(&:create_default_modifiers)
  end
end
