class CreateQuickLogs < ActiveRecord::Migration
  def change
    create_table :quick_logs do |t|
      t.integer :quick_activity_id
      t.integer :duration
      t.integer :user_id

      t.timestamps null: false
    end
  end
end
