class AddIndexesToWorkouts < ActiveRecord::Migration
  def change
    add_index :workouts, [:user_id, :workout_type]
    add_index :workouts, [:user_id, :finished_at]
    add_index :workouts, [:user_id, :finished_at, :workout_type]
  end
end
