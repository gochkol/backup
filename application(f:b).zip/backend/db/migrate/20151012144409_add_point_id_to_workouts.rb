class AddPointIdToWorkouts < ActiveRecord::Migration
  def change
    add_column :workouts, :point_id, :integer
  end
end
