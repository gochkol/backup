class AddMoreToWorkouts < ActiveRecord::Migration
  def change
    rename_column :workouts, :total_time, :total_time_seconds
    rename_column :blocks, :block_set_data, :block_data
    add_column :workouts, :format_version, :string
    add_column :workouts, :workout_total_time_seconds, :integer, default: 0
    remove_column :workouts, :total_time_seconds, :integer
    add_column :workouts, :total_time_seconds, :integer, default: 0
    add_column :favorites, :workout_id, :integer

    Workout.destroy_all
    Block.destroy_all
    Event.destroy_all
    Favorite.destroy_all
    Point.destroy_all
    QuickLog.destroy_all
  end
end
