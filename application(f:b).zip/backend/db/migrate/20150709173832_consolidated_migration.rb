class ConsolidatedMigration < ActiveRecord::Migration
  def change
    create_table "alternations", force: :cascade do |t|
      t.string   "name"
      t.string   "value"
      t.datetime "created_at", null: false
      t.datetime "updated_at", null: false
    end

    add_index "alternations", ["value"], name: "index_alternations_on_value", using: :btree

    create_table "block_set_value_sets", force: :cascade do |t|
      t.integer  "workout_id"
      t.integer  "block_set_id"
      t.integer  "value_set_id"
      t.datetime "created_at",   null: false
      t.datetime "updated_at",   null: false
    end

    create_table "block_sets", force: :cascade do |t|
      t.integer  "rank"
      t.integer  "block_id"
      t.integer  "exercise_id"
      t.datetime "created_at",  null: false
      t.datetime "updated_at",  null: false
    end

    create_table "blocks", force: :cascade do |t|
      t.string   "kind"
      t.integer  "rank"
      t.integer  "routine_id"
      t.datetime "created_at", null: false
      t.datetime "updated_at", null: false
    end

    create_table "body_areas", force: :cascade do |t|
      t.string   "name"
      t.string   "value"
      t.datetime "created_at", null: false
      t.datetime "updated_at", null: false
      t.integer  "parent_id"
    end

    add_index "body_areas", ["value"], name: "index_body_areas_on_value", using: :btree

    create_table "body_areas_exercises", id: false, force: :cascade do |t|
      t.integer "exercise_id",  null: false
      t.integer "body_area_id", null: false
    end

    create_table "body_stats", force: :cascade do |t|
      t.string   "name"
      t.integer  "body_part_name"
      t.float    "data"
      t.integer  "user_id"
      t.boolean  "is_current",     default: false
      t.datetime "created_at",                     null: false
      t.datetime "updated_at",                     null: false
    end

    create_table "categories", force: :cascade do |t|
      t.string   "name"
      t.string   "value"
      t.datetime "created_at", null: false
      t.datetime "updated_at", null: false
    end

    create_table "categories_exercises", id: false, force: :cascade do |t|
      t.integer "exercise_id", null: false
      t.integer "category_id", null: false
    end

    create_table "companies", force: :cascade do |t|
      t.string   "name"
      t.datetime "created_at", null: false
      t.datetime "updated_at", null: false
    end

    create_table "company_members", force: :cascade do |t|
      t.integer  "user_id"
      t.integer  "company_id"
      t.integer  "role_id"
      t.datetime "created_at", null: false
      t.datetime "updated_at", null: false
    end

    create_table "department_members", force: :cascade do |t|
      t.integer  "user_id"
      t.integer  "department_id"
      t.integer  "role_id"
      t.datetime "created_at",    null: false
      t.datetime "updated_at",    null: false
    end

    create_table "departments", force: :cascade do |t|
      t.string   "name"
      t.integer  "company_id"
      t.datetime "created_at", null: false
      t.datetime "updated_at", null: false
    end

    create_table "equipment_groups", force: :cascade do |t|
      t.string   "name"
      t.string   "value"
      t.datetime "created_at", null: false
      t.datetime "updated_at", null: false
    end

    create_table "equipments", force: :cascade do |t|
      t.string   "name"
      t.string   "value"
      t.datetime "created_at",         null: false
      t.datetime "updated_at",         null: false
      t.integer  "equipment_group_id"
    end

    create_table "equipments_exercises", id: false, force: :cascade do |t|
      t.integer "exercise_id",  null: false
      t.integer "equipment_id", null: false
    end

    create_table "equipments_locations", id: false, force: :cascade do |t|
      t.integer "location_id",  null: false
      t.integer "equipment_id", null: false
    end

    create_table "events", force: :cascade do |t|
      t.integer  "eventable_id"
      t.string   "eventable_type"
      t.integer  "user_id"
      t.datetime "created_at",     null: false
      t.datetime "updated_at",     null: false
    end

    create_table "exercises", force: :cascade do |t|
      t.string   "name"
      t.integer  "experience"
      t.string   "alt_name"
      t.string   "link"
      t.integer  "alternation_id"
      t.integer  "space_id"
      t.integer  "mode_id"
      t.datetime "created_at",           null: false
      t.datetime "updated_at",           null: false
      t.integer  "base"
      t.integer  "inc"
      t.float    "rate"
      t.integer  "popularity"
      t.float    "technique"
      t.integer  "primary_body_area_id"
      t.string   "animation_sequence"
      t.float    "met"
      t.integer  "base_weight"
    end

    create_table "exercises_muscles", id: false, force: :cascade do |t|
      t.integer "exercise_id", null: false
      t.integer "muscle_id",   null: false
    end

    create_table "favorites", force: :cascade do |t|
      t.integer  "user_id"
      t.integer  "routine_id"
      t.string   "name"
      t.datetime "created_at", null: false
      t.datetime "updated_at", null: false
    end

    create_table "joins", force: :cascade do |t|
    end

    create_table "locations", force: :cascade do |t|
      t.string   "name"
      t.integer  "space_id"
      t.datetime "created_at", null: false
      t.datetime "updated_at", null: false
    end

    create_table "locations_users", id: false, force: :cascade do |t|
      t.integer "user_id",     null: false
      t.integer "location_id", null: false
    end

    create_table "modes", force: :cascade do |t|
      t.string   "name"
      t.string   "value"
      t.datetime "created_at", null: false
      t.datetime "updated_at", null: false
    end

    add_index "modes", ["value"], name: "index_modes_on_value", using: :btree

    create_table "muscles", force: :cascade do |t|
      t.string   "name"
      t.string   "value"
      t.datetime "created_at", null: false
      t.datetime "updated_at", null: false
    end

    add_index "muscles", ["value"], name: "index_muscles_on_value", using: :btree

    create_table "points", force: :cascade do |t|
      t.string   "name"
      t.string   "point_type"
      t.json     "point_data"
      t.integer  "number_of"
      t.integer  "user_id"
      t.datetime "created_at", null: false
      t.datetime "updated_at", null: false
      t.date     "earned_at"
    end

    create_table "roles", force: :cascade do |t|
      t.string   "name"
      t.datetime "created_at", null: false
      t.datetime "updated_at", null: false
    end

    create_table "routines", force: :cascade do |t|
      t.string   "name"
      t.datetime "created_at",     null: false
      t.datetime "updated_at",     null: false
      t.json     "request_params"
    end

    create_table "spaces", force: :cascade do |t|
      t.string   "name"
      t.string   "value"
      t.datetime "created_at", null: false
      t.datetime "updated_at", null: false
    end

    create_table "team_members", force: :cascade do |t|
      t.integer  "user_id"
      t.integer  "team_id"
      t.integer  "role_id"
      t.datetime "created_at", null: false
      t.datetime "updated_at", null: false
    end

    create_table "teams", force: :cascade do |t|
      t.string   "name"
      t.integer  "company_id"
      t.integer  "department_id"
      t.datetime "created_at",    null: false
      t.datetime "updated_at",    null: false
    end

    create_table "usages", force: :cascade do |t|
      t.string   "name"
      t.string   "value"
      t.datetime "created_at", null: false
      t.datetime "updated_at", null: false
    end

    create_table "user_body_area_factors", force: :cascade do |t|
      t.integer  "user_id"
      t.integer  "body_area_id"
      t.float    "mr"
      t.float    "mw"
      t.datetime "created_at",   null: false
      t.datetime "updated_at",   null: false
    end

    add_index "user_body_area_factors", ["user_id", "body_area_id", "created_at"], name: "helpful_index", using: :btree

    create_table "users", force: :cascade do |t|
      t.string   "first_name"
      t.string   "last_name"
      t.date     "birthdate"
      t.string   "gender"
      t.string   "email",                         null: false
      t.string   "password_digest",               null: false
      t.datetime "created_at",                    null: false
      t.datetime "updated_at",                    null: false
      t.integer  "usage_id"
      t.integer  "intensity"
      t.integer  "experience"
      t.integer  "birth_year"
      t.integer  "birth_month"
      t.integer  "birth_day"
      t.date     "points_updated_at"
      t.integer  "daily_points",      default: 0
      t.integer  "monthly_points",    default: 0
      t.integer  "total_points",      default: 0
    end

    create_table "value_sets", force: :cascade do |t|
      t.integer  "block_set_value_set_id"
      t.json     "values"
      t.datetime "created_at",             null: false
      t.datetime "updated_at",             null: false
    end

    create_table "workouts", force: :cascade do |t|
      t.string   "name"
      t.integer  "routine_id"
      t.integer  "user_id"
      t.datetime "created_at",     null: false
      t.datetime "updated_at",     null: false
      t.json     "request_params"
      t.integer  "total_time"
    end
  end
end
