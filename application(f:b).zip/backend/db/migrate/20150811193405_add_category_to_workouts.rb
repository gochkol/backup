class AddCategoryToWorkouts < ActiveRecord::Migration
  def change
    add_column :routines, :category_id, :integer
    add_column :workouts, :category_id, :integer
    Routine.all.each do |r|
      cname = r.request_params["category"]
      c = Category.find_by_value(cname)
      if c.blank?
        r.update_attribute(:category_id, Category.first.id)
      else
        r.update_attribute(:category_id, c.id)
      end
    end
    Workout.all.each do |r|
      cname = r.request_params["category"]
      c = Category.find_by_value(cname)
      if c.blank?
        r.update_attribute(:category_id, Category.first.id)
      else
        r.update_attribute(:category_id, c.id)
      end
    end
  end
end
