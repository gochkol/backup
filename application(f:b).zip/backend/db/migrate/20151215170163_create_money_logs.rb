class CreateMoneyLogs < ActiveRecord::Migration
  def change
    if !ActiveRecord::Base.connection.table_exists? 'money_logs'
      create_table :money_logs do |t|
        t.string :api_call
        t.text :result
        t.integer :user_id
        t.timestamps null: false
      end
    end
  end
end
