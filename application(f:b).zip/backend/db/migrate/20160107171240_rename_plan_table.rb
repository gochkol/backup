class RenamePlanTable < ActiveRecord::Migration
  def change
    if !ActiveRecord::Base.connection.table_exists? 'billing_plans'
      rename_table :plans, :billing_plans
      rename_column :billing_plans, :plan_type, :billing_plan_type
      rename_column :users, :plan_id, :billing_plan_id
      rename_column :users, :plan_status, :billing_plan_status
    end
  end
end
