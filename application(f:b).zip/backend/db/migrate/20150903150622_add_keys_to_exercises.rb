class AddKeysToExercises < ActiveRecord::Migration
  def change
    add_column :exercises, :keys, :string
    Exercise.all.each do |e|
      e.update_attribute(:keys, e.name.downcase)
    end
  end
end
