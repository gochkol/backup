class CreateMessages < ActiveRecord::Migration
  def up
    create_table :messages do |t|
      t.string :text
      t.string :message_type

      t.timestamps null: false
    end

    Message.create(text: "Nice work!", message_type: "feel_good")
  end

  def down
    drop_table :messages
  end
end
