class AddSomeIndicies < ActiveRecord::Migration
  def change
    add_index :exercises, [:popularity, :experience, :space_id]
    add_index :exercises, [:popularity, :experience, :primary_body_area_id, :space_id], name: "index_name_500"
    add_index :exercises_muscles, [:exercise_id, :muscle_id]
    add_index :exercises_muscles, [:muscle_id, :exercise_id]
    add_index :equipments_exercises, [:exercise_id, :equipment_id]
    add_index :equipments_exercises, [:equipment_id, :exercise_id]
    add_index :equipments_locations, [:location_id, :equipment_id]
    add_index :equipments_locations, [:equipment_id, :location_id]
    add_index :categories_exercises, [:exercise_id, :category_id]
    add_index :categories_exercises, [:category_id, :exercise_id]
  end
end
