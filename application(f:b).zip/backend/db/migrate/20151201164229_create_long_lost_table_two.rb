class CreateLongLostTableTwo < ActiveRecord::Migration
  def change
    puts "Now this should really do the trick"
  end
end
