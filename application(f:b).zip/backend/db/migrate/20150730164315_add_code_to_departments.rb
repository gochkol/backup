class AddCodeToDepartments < ActiveRecord::Migration
  def change
    add_column :departments, :signup_code, :string
  end
end
