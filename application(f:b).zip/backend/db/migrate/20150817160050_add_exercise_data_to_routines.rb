class AddExerciseDataToRoutines < ActiveRecord::Migration
  def change
    add_column :routines, :exercise_data, :json
  end
end
