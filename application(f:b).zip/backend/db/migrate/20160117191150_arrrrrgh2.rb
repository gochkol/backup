class Arrrrrgh2 < ActiveRecord::Migration
  def change
    rename_column :subscriptions,:current_billing_cyle, :current_billing_cycle
    rename_column :subscriptions, :number_of_billing_cylces, :number_of_billing_cycles
    remove_column :subscriptions, :first_billing_date
    add_column :subscriptions, :first_billing_date, :date
  end
end
