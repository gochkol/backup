class AddSentenceToEvents < ActiveRecord::Migration
  def change
    add_column :events, :sentence, :string
    add_column :events, :event_type, :string
    remove_column :events, :eventable_type, :string
    remove_column :events, :eventable_id, :integer
    add_column :events, :event_data, :json
    remove_column :quick_logs, :sentence, :string
  end
end
