class CreateQuickActivities < ActiveRecord::Migration
  def up
    create_table :quick_activities do |t|
      t.string :name
      t.string :value
      t.boolean :is_distance

      t.timestamps null: false
    end

    QuickActivity.create name: "Running", value: "running", is_distance: true
  end

  def down
    drop_table :quick_activities
  end
end
