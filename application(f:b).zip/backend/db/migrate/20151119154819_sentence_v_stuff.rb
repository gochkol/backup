class SentenceVStuff < ActiveRecord::Migration
  def change
    add_column :events, :v2_event_data, :json
    add_column :points, :v2_point_data, :json
    EventService.update_all_event_meta_data
    PointsService.update_all_point_meta_data
  end
end
