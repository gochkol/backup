class CreateJoinTable < ActiveRecord::Migration
  def change
    create_join_table :locations, :users do |t|
      t.index [:location_id, :user_id]
      t.index [:user_id, :location_id]
    end
    Location.all.each do |l|
      LocationsUser.create(user_id: l.user_id, location_id: l.id)
    end
  end
end
