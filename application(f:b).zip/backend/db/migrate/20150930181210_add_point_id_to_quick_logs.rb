class AddPointIdToQuickLogs < ActiveRecord::Migration
  def change
    add_column :quick_logs, :point_id, :integer
  end
end
