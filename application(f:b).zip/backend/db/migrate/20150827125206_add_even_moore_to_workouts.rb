class AddEvenMooreToWorkouts < ActiveRecord::Migration
  def change
    add_column :workouts, :bae, :json
  end
end
