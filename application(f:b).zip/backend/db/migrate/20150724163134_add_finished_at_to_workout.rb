class AddFinishedAtToWorkout < ActiveRecord::Migration
  def change
    add_column :workouts, :finished_at, :datetime
  end
end
