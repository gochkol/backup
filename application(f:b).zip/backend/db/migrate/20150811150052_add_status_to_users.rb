class AddStatusToUsers < ActiveRecord::Migration
  def change
    add_column :users, :current_status, :string
    add_column :users, :current_status_at, :datetime
  end
end
