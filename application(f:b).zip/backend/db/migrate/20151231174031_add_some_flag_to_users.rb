class AddSomeFlagToUsers < ActiveRecord::Migration
  def change
    add_column :users, :content_level, :string, default: "free"
  end
end
