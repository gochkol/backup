class FixBodyStats < ActiveRecord::Migration
  def change
    change_column :body_stats, :body_part_name, :string
  end
end
