class AddDistanceMilesToQuickLogs < ActiveRecord::Migration
  def change
    add_column :quick_logs, :distance_miles, :integer, default: 0
  end
end
