class AddBillingIdToUsers < ActiveRecord::Migration
  def change
    add_column :users, :billing_id, :string
  end
end
