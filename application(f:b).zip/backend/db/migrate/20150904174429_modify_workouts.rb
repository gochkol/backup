class ModifyWorkouts < ActiveRecord::Migration
  def change
    rename_column :workouts, :workout_total_time_seconds, :finished_total_time_seconds
    add_column :workouts, :workout_type, :string, default: "quick"
  end
end
