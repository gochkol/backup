class CreateBodyPartStats < ActiveRecord::Migration
  def change
    create_table :body_part_stats do |t|
      t.integer :body_part_id
      t.float :data
      t.integer :user_id
      t.boolean :is_current

      t.timestamps null: false
    end
  end
end
