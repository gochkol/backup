class CreateLongLostTable < ActiveRecord::Migration
  def change
    puts "This should do the trick"
  end
end
