class CreateLevels < ActiveRecord::Migration
  def change
    create_table :levels do |t|
      t.integer :min_points
      t.integer :max_points
      t.string :name
      t.integer :value
      t.string :icon_name
      t.integer :next_level_points
    end
    add_index :levels, :min_points

    add_column :users, :level_id, :integer

    levels = [20, 100, 250, 500, 1000, 1500, 2000, 2550, 3150, 3800, 4500, 5250, 6050, 6900, 7800, 8750, 9750, 10800, 11900, 13050, 4294967]
    min = 0
    levels.each_with_index do |l, i|
      Level.create(min_points: min, max_points: l-1, next_level_points: l,
                   value: i+1, name: "L#{i+1}", icon_name: "level_#{i+1}.png")
      min = l
    end
  end
end
