class CreateSubscriptions < ActiveRecord::Migration
  def change
    remove_column :users, :billing_plan_id
    remove_column :users, :billing_plan_status
    remove_column :users, :billing_id
    create_table :subscriptions do |t|
      t.integer :user_id
      t.integer :billing_plan_id
      t.integer :billing_day_of_month
      t.date    :billing_period_end_date
      t.date    :billing_period_start_date
      t.integer :current_billing_cyle
      t.integer :days_past_due
      t.integer :failure_count
      t.integer :first_billing_date
      t.string  :braintree_id
      t.date    :next_billing_date
      t.float   :next_billing_period_amount
      t.integer :number_of_billing_cylces
      t.date    :paid_through_date
      t.string  :payment_method_token
      t.float   :price
      t.string  :status
      t.timestamps null: false
    end
  end
end
