class AddMoneyStuffToUsers < ActiveRecord::Migration
  def change
    add_column :users, :plan_id, :integer
    add_column :users, :plan_status, :string, default: "none"
  end
end
