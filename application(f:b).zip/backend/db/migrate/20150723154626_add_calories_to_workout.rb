class AddCaloriesToWorkout < ActiveRecord::Migration
  def change
    add_column :workouts, :calories_burned, :integer, default: 0
  end
end
