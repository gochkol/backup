class AddGuestFlagToUsers < ActiveRecord::Migration
  def change
    add_column :users, :is_guest, :boolean, default: false
    add_column :locations, :is_guest, :boolean, default: false

    l = Location.create(name: "Home", space_id: Space.where(value: "s").first.id, is_guest: true)
    e = Equipment.where(value: "towel")
    unless e.empty?
      l.equipments << e.first
    end

    l = Location.create(name: "Gym", space_id: Space.where(value: "l").first.id, is_guest: true)
    l.equipment_ids = Equipment.active.where.not(value: ["hurdles", "bike"]).map(&:id)
  end
end
