class AddEvenMoreToWorkouts < ActiveRecord::Migration
  def change
    add_column :workouts, :equipment_ids, :json
    add_column :workouts, :body_area_ids, :json
  end
end
