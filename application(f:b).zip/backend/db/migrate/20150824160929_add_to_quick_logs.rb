class AddToQuickLogs < ActiveRecord::Migration
  def change
    add_column :quick_logs, :desc, :string
    add_column :quick_logs, :calories_burned, :integer
  end
end
