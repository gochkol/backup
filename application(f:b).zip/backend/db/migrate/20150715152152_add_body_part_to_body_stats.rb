class AddBodyPartToBodyStats < ActiveRecord::Migration
  def change
    remove_column :body_stats, :body_part_name
    add_column :body_stats, :value, :string
  end
end
