class DropRoutines < ActiveRecord::Migration
  def change
    drop_table :routines
    rename_column :blocks, :routine_id, :workout_id
    remove_column :favorites, :routine_id, :integer
    add_column :blocks, :exercise_id, :integer
    remove_column :workouts, :routine_id, :integer
    drop_table :block_sets
    drop_table :block_set_value_sets
    drop_table :value_sets
    rename_column :blocks, :kind, :block_type
  end
end
