class ChangePoints < ActiveRecord::Migration
  def change
    change_column :points, :earned_at, :datetime
  end
end
