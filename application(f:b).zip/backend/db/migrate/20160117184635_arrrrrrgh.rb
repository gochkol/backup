class Arrrrrrgh < ActiveRecord::Migration
  def change
    add_column :users, :billing_plan_id, :integer
    add_column :users, :billing_customer_id, :string
  end
end
