class ArrrghhhToExercises < ActiveRecord::Migration
  def change
    add_column :equipments_exercises, :id, :primary_key
  end
end
