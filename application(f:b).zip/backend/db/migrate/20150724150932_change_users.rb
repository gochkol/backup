class ChangeUsers < ActiveRecord::Migration
  def change
    change_column :users, :points_updated_at, :datetime
  end
end
