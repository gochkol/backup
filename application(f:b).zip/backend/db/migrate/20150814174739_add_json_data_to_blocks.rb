class AddJsonDataToBlocks < ActiveRecord::Migration
  def change
    add_column :blocks, :block_set_data, :json
  end
end
