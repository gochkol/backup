class AddInactiveFlags < ActiveRecord::Migration
  def change
    add_column :body_areas, :is_active, :boolean, default: true
    add_column :body_parts, :is_active, :boolean, default: true
    add_column :equipments, :is_active, :boolean, default: true
    add_column :exercises, :is_active, :boolean, default: true
    add_column :muscles, :is_active, :boolean, default: true
    add_column :spaces, :is_active, :boolean, default: true
    add_column :usages, :is_active, :boolean, default: true
    add_column :users, :is_active, :boolean, default: true
    add_column :modes, :is_active, :boolean, default: true
    add_column :comments, :is_active, :boolean, default: true
    add_column :categories, :is_active, :boolean, default: true
    add_column :alternations, :is_active, :boolean, default: true
  end
end
