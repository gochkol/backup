class AddSignupCodeToTeams < ActiveRecord::Migration
  def change
    add_column :teams, :signup_code, :string
  end
end
