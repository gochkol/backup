class AddCategoryToUsers < ActiveRecord::Migration
  def change
    add_column :users, :category_id, :integer
    User.all.each do |u|
      u.update_attribute(:category_id, Category.find_by_value('strength').id)
    end
  end
end
