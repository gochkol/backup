class AddPointsTo < ActiveRecord::Migration
  def change
    add_column :teams, :total_points, :integer, default: 0
    add_column :teams, :monthly_points, :integer, default: 0
    add_column :teams, :daily_points, :integer, default: 0

    add_column :departments, :total_points, :integer, default: 0
    add_column :departments, :monthly_points, :integer, default: 0
    add_column :departments, :daily_points, :integer, default: 0

    add_column :companies, :total_points, :integer, default: 0
    add_column :companies, :monthly_points, :integer, default: 0
    add_column :companies, :daily_points, :integer, default: 0
  end
end
