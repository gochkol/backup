class AddToSubscriptions < ActiveRecord::Migration
  def change
    add_column :subscriptions, :old_user_id, :integer
    remove_column :subscriptions, :user_id
  end
end
