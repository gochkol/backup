class AddIdToThroughAssociations < ActiveRecord::Migration
  def change
    add_column :body_areas_exercises, :id, :primary_key
    add_index :body_areas_exercises, [:body_area_id, :exercise_id]
    add_column :exercises_muscles, :id, :primary_key
    add_column :categories_exercises, :id, :primary_key
  end
end
