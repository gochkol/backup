class AddCountToEvent < ActiveRecord::Migration
  def change
    add_column :events, :comment_count, :integer, default: 0
  end
end
