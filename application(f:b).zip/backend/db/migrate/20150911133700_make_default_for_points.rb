class MakeDefaultForPoints < ActiveRecord::Migration
  def change
    change_column :points, :number_of, :integer, default: 0
  end
end
