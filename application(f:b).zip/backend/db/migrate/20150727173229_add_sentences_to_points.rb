class AddSentencesToPoints < ActiveRecord::Migration
  def change
    add_column :points, :sentence, :string
    add_column :quick_logs, :sentence, :string
  end
end
