class CreatePlans < ActiveRecord::Migration
  def change
    create_table :plans do |t|
      t.string :code
      t.string :name
      t.string :description
      t.integer :price_cents
      t.string :duration_type
      t.integer :duration_number
      t.boolean :is_active, default: true
      t.string :plan_type, default: "subscription"

      t.timestamps null: false
    end
  end
end

#BillingPlan.create(code: "testplana", price_cents: 299, duration_type: "month", duration_number: "1", name: "Test Plan A", description: "Plan A description")
#BillingPlan.create(code: "testplanb", price_cents: 699, duration_type: "month", duration_number: "3", name: "Test Plan B", description: "Plan B description")
