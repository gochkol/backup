class TeamService

  attr_accessor :user, :team, :department, :company

  def initialize(user)
    @user = user
    @team = nil
    @department = nil
    @company = nil
  end

  def use_signup_code(signup_code)
    return if signup_code.blank?

    @team = Team.find_by_signup_code(signup_code.upcase)
    return if team.nil?

    @department = team.department
    @company = team.company

    role = Role.find_by_name("member")
    TeamMember.create(member: user, team: team, role: role)

    if department
      DepartmentMember.create(member: user, role: role, department: department)
    end

    if company
      CompanyMember.create(member: user, role: role, company: company)
    end
  end

  def leave_company(team_id)
    @team = Team.find_by_id(team_id)
    return if team.nil?

    @department = team.department
    @company = team.company

    user.team_members.find_by_team_id(team.id).try(:destroy)
    user.department_members.find_by_department_id(department.id).try(:destroy)
    user.company_members.find_by_company_id(company.id).try(:destroy)
  end

end
