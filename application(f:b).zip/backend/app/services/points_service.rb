class PointsService

  attr_accessor :user, :point

  def initialize(user)
    @user = user
  end

  MAX_PER_DAY =50 
  MAX_PER_MONTH = 600
  MIN_POINTS_PER_WORKOUT = 10

  def finish_quick_log(quick_log)
    number_of = get_number_of(quick_log.duration/2, quick_log.created_at)
    distance_part = ""

    if (quick_log.distance_miles)
      distance_part = "over a distance of #{quick_log.distance_miles} miles"
    end
    if (number_of > 0)
      s = "#{user.first_name} #{user.last_name} earned #{number_of}
      points for logging #{quick_log.duration} minutes of #{quick_log.quick_activity.name} #{distance_part}"
    else
      s = "#{user.first_name} #{user.last_name} finished logging #{quick_log.duration} minutes of #{quick_log.quick_activity.name} #{distance_part} and has reached max points for the day"
    end

    number_of = get_number_of(quick_log.duration/2, quick_log.created_at)
    earned_at = quick_log.created_at
    point_type = "finish_quick_log"
    add_points(number_of, point_type, {quick_log_id: quick_log.id}, s, quick_log.meta_data, earned_at)
    # TODO V1 DEPRACATION PART 4
    # remove function above with sentence creation and uncomment below
    #add_points(number_of, point_type, quick_log.meta_data, earned_at)
  end

  def finish_workout(workout)
    tt = workout.finished_total_time_seconds
    cb = workout.calories_burned

    potential_points = ((tt.floor/60) + (cb.floor/10)).floor
    potential_points = potential_points < MIN_POINTS_PER_WORKOUT ? MIN_POINTS_PER_WORKOUT : potential_points

    number_of = get_number_of(potential_points, workout.created_at)
    earned_at = workout.finished_at
    point_type = "finish_workout"
    if (number_of > 0)
      s = "#{user.first_name} #{user.last_name} earned #{number_of} points for finishing #{workout.name}"
    else
      s = "#{user.first_name} #{user.last_name} has finishing #{workout.name} and has reached max points for the day"
    end
    add_points(number_of, point_type, {workout_id: workout.id}, s, workout.meta_data, earned_at)
    # TODO V1 DEPRACATION PART 4
    # remove function above with sentence creation and uncomment below
    #add_points(number_of, point_type, workout.meta_data, earned_at)
    workout.update_attribute(:point_id, point.id)
  end

  # TODO V1 DEPRACATION PART 0
  # run this after the migration to create v2_point_data
  def self.update_all_point_meta_data
    Point.all.each do |point|
      if point.point_type == "finish_quick_log"
        begin
          ql = QuickLog.find(point.point_data['quick_log_id'])
          point.update_attribute(:v2_point_data, ql.meta_data)
        rescue
        end
      elsif point.point_type == "finish_workout"
        w = Workout.find(point.point_data['workout_id'])
        point.update_attribute(:v2_point_data, w.meta_data)
      end
    end
  end

  def get_number_of(potential_points, created_at)
    days_ago = (DateTime.now.to_i - created_at.to_i)/ 86400
    potential_monthly_points = MAX_PER_MONTH - user.calculate_month_points(days_ago)
    potential_daily_points = MAX_PER_DAY - user.calculate_day_points(days_ago)

    return 0 if potential_monthly_points < 0 || potential_daily_points < 0

    potential_daily_points = (potential_daily_points >= potential_points) ? potential_points : potential_daily_points
    potential_monthly_points = (potential_monthly_points >= potential_points) ? potential_points : potential_monthly_points
    (potential_daily_points <= potential_monthly_points) ? potential_daily_points : potential_monthly_points
  end

  def add_points(number_of, point_type, point_data, sentence, meta_data, earned_at)
    earned_at ||= DateTime.now
    @point = Point.create(user: user, number_of: number_of, point_type: point_type, earned_at: earned_at, point_data: point_data, v2_point_data: meta_data, sentence: sentence)
    user.update_points
  end

  # TODO V1 DEPRACATION PART 4
  # remove function above and uncomment below
  #def add_points(number_of, point_type, point_data={}, earned_at)
  #  earned_at ||= DateTime.now
  #  @point = Point.create(user: user, number_of: number_of, point_type: point_type, earned_at: earned_at, point_data: point_data)
  #  user.update_points
  #end


end



