class FavoriteService
  attr_accessor :user, :params, :workout, :category, :intensity, :usage, :favorite, :cs

  def initialize(user, params={})
    @user = user
    @params = params
    @favorite = Favorite.find(params[:favorite_id])
    @category = favorite.workout.category
    @intensity = user.intensity - 1
    @usage = user.usage
    @cs = CriteriaService.new(category, usage, intensity, user.bafs, user.rest_mod, user.set_mod)
  end

  def create
    @workout = Workout.create(user: user, category: category, name: favorite.name,
                              total_time_seconds: favorite.workout.total_time_seconds,
                              request_params: params, format_version: "1.0",
                              body_area_ids: favorite.workout.body_area_ids,
                              equipment_ids: favorite.workout.equipment_ids,
                              bae: favorite.workout.bae,
                              workout_type: favorite.workout.workout_type)
    favorite.workout.blocks.each do |block|
      e = block.exercise
      bd = HashWithIndifferentAccess.new(block.block_data)
      bd[:block_sets].each do |block_set|
        block_set[:criterion] = cs.criterion(e)
      end
      workout.blocks.create(block_type: "exercise", block_data: bd, exercise: e, rank: block.rank)
    end
  end

end
