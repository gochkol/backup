class BlockService
  attr_accessor :user, :params, :workout, :current_block, :new_block, :new_blocks, :bae, :cs

  def initialize(user, params={})
    @user = user
    @params = params
    if params[:block_id]
      @current_block = user.blocks.find(params[:block_id])
      @workout = current_block.workout
    else
      @workout = user.workouts.find(params[:workout_id])
    end
    @bae = workout.bae
    @cs = CriteriaService.new(workout.category, user.usage, user.intensity - 1, user.bafs, user.rest_mod, user.set_mod)
  end

  def swap
    e = get_swap_exercise
    return if e.nil?
    @new_block = workout.blocks.create(block_type: "exercise", block_data: cs.block_data(e), rank: current_block.rank, exercise: e)
    workout.total_time_seconds -= cs.get_exercise_time(current_block.exercise)
    workout.total_time_seconds += cs.get_exercise_time(e)
    workout.save
    current_block.destroy
  end

  def random
    e = get_random_exercise
    return if e.nil?
    @new_block = workout.blocks.create(block_type: "exercise", block_data: cs.block_data(e), exercise: e)
    workout.total_time_seconds += cs.get_exercise_time(e)
    workout.save
  end

  def add_exercises
    exercises = Exercise.find(params[:exercise_ids])
    @new_blocks = []
    exercises.each do |e|
      @new_blocks.push(workout.blocks.create(block_type: "exercise", block_data: cs.block_data(e), exercise: e))
      workout.total_time_seconds += cs.get_exercise_time(e)
    end
    workout.save
  end

  def duplicate
    e = current_block.exercise
    @new_block = workout.blocks.create(block_type: "exercise", block_data: cs.block_data(e), exercise: e)
    workout.total_time_seconds += cs.get_exercise_time(e)
    workout.save
  end

  def get_random_exercise
    eids = bae.flatten.partition.each_with_index {|e, i| i.even?}[0].uniq
    exercise_ids = workout.exercise_ids.uniq
    ueids = eids - exercise_ids
    if ueids.length > 0
      return ExerciseCache.exercise_hash[ueids[rand(ueids.length)]]
    else
      return ExerciseCache.exercise_hash[eids[rand(eids.length)]]
    end
  end

  def get_swap_exercise
    body_area_id = no_body_area ? BodyArea.top_level.id : current_block.exercise.primary_body_area_id
    body_area_index = workout.body_area_ids.index(body_area_id)

    a = []
    bae.each do |exp_a|
      a += exp_a[body_area_index]
    end

    swap_index = get_body_area_swap_index(body_area_index)
    swap_index = 0 if swap_index >= a.length

    eids = workout.exercise_ids
    l = ((swap_index..a.length-1).to_a + (0..swap_index-1).to_a)

    l.each do |i|
      e = ExerciseCache.exercise_hash[a[i][0]]
      if !eids.include?(e.id)
        set_body_area_swap_index(body_area_index, i)
        return e
      end
    end
    set_body_area_swap_index(body_area_index, swap_index+1)
    return nil
  end

  def get_body_area_swap_index(body_area_index)
    key = "user_id-#{user.id}:workout_id-#{workout.id}:body_area_index-#{body_area_index}:swap_index"
    $redis.get(key).to_i
  end

  def set_body_area_swap_index(body_area_index, swap_index)
    key = "user_id-#{user.id}:workout_id-#{workout.id}:body_area_index-#{body_area_index}:swap_index"
    $redis.set(key, swap_index)
    $redis.expire(key, 600)
  end

  def get_add_index
    key = "user_id-#{user.id}:workout_id-#{workout.id}:add_index"
    $redis.get(key).to_i
  end

  def set_add_index(add_index)
    key = "user_id-#{user.id}:workout_id-#{workout.id}:add_index"
    $redis.set(key, add_index)
    $redis.expire(key, 600)
  end

  def no_body_area
    (workout.body_area_ids == [BodyArea.top_level.id]) ? true : false
  end
end
