class WorkoutService

  attr_accessor :user, :params, :total_time_seconds, :workout, :body_areas,
                :usage, :location, :category, :intensity, :no_body_area, :experiences,
                :favorite, :bae, :bafs, :cs


  def initialize(user, params={})
    @user = user
    @params = params
  end


  def custom_create
    @workout = Workout.create(user: user, category: user.category,
                              name: "Custom Workout ##{user.custom_workouts.count+1}",
                              request_params: params, format_version: "1.0",
                              workout_type: "custom", total_time_seconds: 0)
  end

  def quick_create
    puts user.settings.inspect
    @category = Category.find_by_id(params[:category_id])
    @intensity = params[:intensity].to_i - 1
    @location = user.locations.find(params[:location_id])
    @usage = user.usage
    @bafs = user.bafs

    set_total_time
    set_body_areas
    set_experiences
    set_body_area_exercises
    set_seed_value
    @cs = CriteriaService.new(category, usage, intensity, bafs, user.rest_mod, user.set_mod)

    @workout = Workout.create(user: user, category: category, name: workout_name,
                              request_params: params, format_version: "1.0",
                              body_area_ids: body_areas.map(&:id),
                              equipment_ids: location.equipment_ids, bae: bae,
                              workout_type: "quick")

    tt = total_time_seconds
    ct = 0
    old_tt = -1
    block_count = 0

    while tt > 0 && old_tt != tt && block_count < MAX_BLOCK_COUNT
      old_tt = tt
      ebae = clone_bae

      ebae.each_with_index do |bae, baei|
        pbae = []
        bae.each do |es|
          pmap = {}
          es.each do |e|
            pmap[e[1]] ||= []
            pmap[e[1]].push e[0]
          end
          pbae.push pmap.keys.sort.map {|k| pmap[k]}
        end

        prev_tt = -1
        while prev_tt != tt && block_count < MAX_BLOCK_COUNT do
          prev_tt = tt
          body_areas.each_with_index do |body_area, index|
            break if tt < 0

            pes = pbae[index]
            next if pes.empty?

            eid = get_next_eid(pes, (block_count==0))
            next if eid.nil?

            e = ExerciseCache.exercise_hash[eid]
            et = cs.get_exercise_time(e)
            next if ((tt - et) < 0  && block_count > 0)

            workout.blocks.create(block_type: "exercise", block_data: cs.block_data(e), exercise: e)
            block_count += 1
            tt -= et
            ct += et
          end
        end
      end
    end
    workout.total_time_seconds = ct
    workout.save
  end

  def workout_name
    "#{category.name.capitalize} - Intensity #{intensity+1} - #{(total_time_seconds/60).to_i}  minutes"
  end

  MAX_BLOCK_COUNT = 100

  def get_next_eid(pes, is_first_block)
    eid = nil

    pes.each do |pe|
      next if pe.empty?
      if is_first_block
        return  pe.delete_at(rand(pe.length))
      end
      n = pe.length * 2
      p = rand(n)
      if p < n/2
        pi = rand(pe.length)
        eid = pe.delete_at(pi)
        return eid
      end
    end

    pes.reverse.each do |pe|
      next if pe.empty?

      pi = rand(pe.length)
      eid = pe.delete_at(pi)
      return eid
    end
    nil
  end

  def set_total_time
    @total_time_seconds = params[:total_time] * 60
    @total_time_seconds = (@total_time_seconds > 10800) ? 10800 : @total_time_seconds
  end

  def set_seed_value
    params[:seed] ||= Time.now.to_i
    params[:user_id] = user.id
    srand(params[:seed])
  end

  def set_experiences
    case user.experience
    when 1
      @experiences = [[1], [2]]
    when 2
      @experiences = [[2], [1], [3]]
    else
      @experiences = [[3, 2], [1]]
    end
  end

  def set_body_areas
    if [3, 2, 1, 6].include?(category.id)
      @body_areas = [BodyArea.top_level]
      @no_body_area = true
    else
      @body_areas = BodyArea.where(id: params[:body_area_ids]).order(:id)
      @no_body_area = false
    end
  end

  def set_body_area_exercises
    bae = []
    max_popularity = 0

    experiences.each_with_index do |exp, ei|
      bae[ei] = []
      leids = location.equipment_ids || []
      space_ids = (1..location.space_id).to_a
      body_areas.each_with_index do |body_area, index|
        es = ExerciseCache.exercises.find_all do |e|
          e.is_active &&
          exp.include?(e.experience) &&
          (no_body_area || (e.primary_body_area_id == body_area.id)) &&
          e.popularity != 0 &&
          space_ids.include?(e.space_id) &&
          (e.equipment_ids.empty? || ((leids & e.equipment_ids).count >= e.equipment_ids.count)) &&
          e.category_ids.include?(category.id)
        end

        bae[ei][index] = es.map{|k| [k.id, k.popularity]}.sort{|a, b| a[1] <=> b[1]}
      end
    end
    @bae = bae
  end

  def clone_bae
    a = []
    bae = @bae
    bae.each_with_index do |x, i|
      a[i] = []
      x.each_with_index do |y, j|
        a[i][j] = []
        y.each_with_index do |z, k|
          a[i][j][k] = z.clone
        end
      end
    end
    a
  end

end

