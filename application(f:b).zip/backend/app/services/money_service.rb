class MoneyService
  attr_accessor :user, :json, :status, :subscription, :transactions, :lastest_transaction

  def initialize(user)
    @user = user
    @subscription = user.subscription
    @json = {errors: default_error_message}
    @status = 422
    initialize_user
  end


  def initialize_user
    return if user.billing_customer_id
    log = MoneyLog.create(api_call: "Braintree::Customer.create", user: user)
    result = Braintree::Customer.create(
      first_name: user.first_name,
      last_name: user.last_name,
      email: user.email,
      id: braintree_user_id
    )
    log.update_attribute(:result, result)
    user.update_attribute(:billing_customer_id, braintree_user_id)
  end

  def refresh_subscription
    return if !subscription

    log = MoneyLog.create(api_call: "Braintree::Subscription.find", user: user)
    begin
      result = Braintree::Subscription.find(subscription.braintree_id)
    rescue StandardError => error
      log.update_attribute(:result, error)
      return nil
    end
    log.update_attribute(:result, result)

    update_subscription(result)
    @transactions = result.transactions
  end

  def subscription_data
    return nil if !subscription || !transactions
    t = transactions.first
    s = subscription
    data = {
      subscription_status: s.status.downcase,
      billing_plan_name: s.billing_plan.name,
      next_billing_date: s.next_billing_date,
      next_billing_period_amount: s.next_billing_period_amount,
      masked_number: t.credit_card_details.masked_number,
      card_type: t.credit_card_details.card_type,
      expiration_date: t.credit_card_details.expiration_date
    }
  end

  def create_client_token
    log = MoneyLog.create(api_call: "Braintree::ClientToken.generate", user: user)
    token = Braintree::ClientToken.generate(customer_id: user.billing_customer_id)
    log.update_attribute(:result, {token: token})

    @json = {client_token: token}
    @status = 200
  end

  def set_errors(result)
    @json = {errors: default_error_message}
    @status = 422
    if result.errors.count > 0 && result.errors.count == result.errors.for(:credit_card).try(:count)
      @json = {errors: result.message}
    end
  end

  def update_payment(params)
    @subscription = user.subscription
    if !subscription
      @json = {errors: "Could not find subscription"}
      return
    end

    log = MoneyLog.create(api_call: "Braintree::PaymentMethod.create", user: user)
    result = Braintree::PaymentMethod.create(customer_id: user.billing_customer_id, payment_method_nonce: params[:nonce], options: {verify_card: true, make_default: true})
    log.update_attribute(:result, result)
    if !result.success?
      set_errors(result)
      return
    end

    payment_method_token = result.payment_method.token
    log = MoneyLog.create(api_call: "Braintree::Subscription.update", user: user)
    begin
      result = Braintree::Subscription.update(subscription.braintree_id, payment_method_token: payment_method_token)
    rescue StandardError => error
      log.update_attribute(:result, error)
      @json = {errors: "Invalid subscription"}
      return
    end
    log.update_attribute(:result, result)
    if !result.success?
      set_errors(result)
      return
    end

    s = result.subscription
    update_subscription(s)
    user.save
    user.reload
    @json = {}
    @status = 200
  end

  def cancel_subscription
    @subscription = user.subscription
    if !subscription
      @json = {errors: "Could not find subscription"}
      return
    end

    log = MoneyLog.create(api_call: "Braintree::Subscription.cancel", user: user)
    begin
      result = Braintree::Subscription.cancel(subscription.braintree_id)
    rescue StandardError => error
      log.update_attribute(:result, error)
      @json = {errors: "Invalid subscription"}
      return
    end
    log.update_attribute(:result, result)
    if !result.success?
      set_errors(result)
      return
    end
    subscription.update(old_user_id: user.id)
    user.subscription_id = nil
    user.billing_plan_id = nil
    user.save
    user.reload
    @json = {}
    @status = 200
  end

  def create_subscription(params)
    billing_plan = BillingPlan.find_by_id(params[:billing_plan_id])
    if !billing_plan
      @json = {errors: "Could not find valid billing plan"}
      return
    end

    log = MoneyLog.create(api_call: "Braintree::PaymentMethod.create", user: user)
    #params[:nonce] = 'fake-processor-declined-visa-nonce'
    result = Braintree::PaymentMethod.create(customer_id: user.billing_customer_id, payment_method_nonce: params[:nonce], options: {verify_card: true, make_default: true})
    log.update_attribute(:result, result)
    if !result.success?
      set_errors(result)
      return
    end

    payment_method_token = result.payment_method.token
    log = MoneyLog.create(api_call: "Braintree::Subscription.create", user: user)
    result = Braintree::Subscription.create(payment_method_token: payment_method_token, plan_id: billing_plan.code)
    log.update_attribute(:result, result)
    if !result.success?
      set_errors(result)
      return
    end

    s = result.subscription
    @subscription = Subscription.create(old_user_id: user.id, billing_plan_id: billing_plan.id)
    update_subscription(s)
    user.billing_plan_id = billing_plan.id
    user.subscription_id = subscription.id
    user.save
    user.reload

    if result.subscription.status != "Active"
      #not sure how to test this in the sandbox
      return
    end

    @json = {}
    @status = 200
  end


  def update_subscription(s)
    subscription.update(
      billing_day_of_month: s.billing_day_of_month,
      billing_period_start_date: s.billing_period_start_date,
      billing_period_end_date: s.billing_period_end_date,
      current_billing_cycle: s.current_billing_cycle,
      days_past_due: s.days_past_due.to_i,
      failure_count: s.failure_count,
      first_billing_date: s.first_billing_date,
      braintree_id: s.id,
      next_billing_date: s.next_billing_date,
      next_billing_period_amount: s.next_billing_period_amount,
      number_of_billing_cycles: s.number_of_billing_cycles.to_i,
      paid_through_date: s.paid_through_date,
      payment_method_token: s.payment_method_token,
      price: s.price,
      status: s.status
    )
  end

  def braintree_user_id
    "braintree_user_id_#{user.id}"
  end

  def default_error_message
    "Could not complete the transaction. Please contact support at support@updowntech.com"
  end

end

