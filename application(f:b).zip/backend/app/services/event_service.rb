class EventService

  attr_accessor :user, :event

  def initialize(user)
    @user = user
  end

  def finish_quick_log(quick_log)
    # TODO V1 DEPRACATION PART 3
    # remove sentence from below
    # AND remove v2_event_data
    @event = Event.create(user: user, event_type: "finish_quick_log",
                 sentence: quick_log.event_sentence,
                 event_data: quick_log.meta_data,
                 v2_event_data: quick_log.meta_data,
                 created_at: quick_log.created_at)
  end

  def level_jump(level)
    @event = Event.create(user: user, event_type: "level_jump", event_data: level.meta_data, v2_event_data: level.meta_data)
  end

  def finish_workout(workout)
    s = "#{user.first_name} #{user.last_name} finished #{workout.name}"
    @event = Event.create(user: user, event_type: "finish_workout", sentence: s, event_data: workout.meta_data, v2_event_data: workout.meta_data)
    # TODO V1 DEPRACATION PART 3
    # delete above code and uncomment below
    #@event = Event.create(user: user, event_type: "finish_workout", event_data: workout.meta_data)
  end

  def update_status(status)
    s = "#{user.first_name} #{user.last_name}: '#{status}'"
    @event = Event.create(user: user, event_type: "update_status", event_data: {user: user.as_json(only: [:id, :first_name, :last_name, :current_status, :current_status_at])}, v2_event_data: user.status_meta_data, sentence: s)
    # TODO V1 DEPRACATION PART 3
    # delete above code and uncomment below
    #@event = Event.create(uupdate_all_event_meta_dataser: user, event_type: "update_status", event_data: user.status_meta_data)
  end

  def self.update_all_event_meta_data
    Event.all.each do |event|
      event.update_attribute(:v2_event_data, event.event_data)
    end
  end
  
end




