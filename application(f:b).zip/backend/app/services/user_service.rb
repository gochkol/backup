class UserService
  attr_accessor :user, :params, :is_guest, :settings
  def initialize(user: nil, params: {})
    @params = permit_params(params)
    @user = user
    @is_guest = params[:is_guest] || false
  end

  def create
    @user = User.create(params)
    if user.valid? && !user.is_guest
      ProfileMailer.welcome(user).deliver
    end
  end

  def update
    if params[:current_password]
      if user.try(:authenticate, params[:current_password])
        user.valid_current_password = true;
      else
        user.valid_current_password = false
      end
    end
    upload_avatar if params[:avatar_file]
    modifier_atts = params.delete(:modifiers) || []
    modifier_atts.each do |atts|
      #TODO Johan this is sloppy, please do it the right way for nest_attributes when there is time
      Modifier.find(atts[:id]).update_attribute(:value, atts[:value])
    end
    user.update_attributes(params)
    user.update_attributes(settings: settings)
    if !user.previous_changes[:password_digest].blank?
      UserMailer.password_change(user).deliver
    end
    if !user.previous_changes[:email].blank?
      UserMailer.email_change(user).deliver
    end
  end

  def upload_avatar
    begin
      avatar_file = params[:avatar_file]
      filename = avatar_file.original_filename
      bucket = S3_BUCKET.object("users/#{user.id}/avatar/#{filename}")
      r = bucket.upload_file(avatar_file.tempfile, acl: 'public-read')
      if r
        user.avatar_url = bucket.public_url
      else
        user.avatar_url = nil
      end
    rescue => error
      puts error.inspect
      user.avatar_url = nil
    end
  end

  def permit_params(params)
    @settings = params.delete(:settings)
    params.permit(:email, :password, :password_confirmation, :is_guest,
                   :birthdate, :gender, :first_name, :last_name,
                   :current_password, :new_password, :new_password_confirmation,
                   :birth_year, :birth_month, :birth_day, :status,
                   :experience, :intensity, :usage_id, :category_id,
                   :signup_code,
                   :avatar_url, :country_code, :state_code, :city, :zipcode,
                   :current_status, :avatar_file, {modifiers: [:id, :value]})
  end


end
