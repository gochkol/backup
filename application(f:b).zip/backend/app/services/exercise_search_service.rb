class ExerciseSearchService
  attr_accessor :user, :params, :exercises

  def initialize(user, params={})
    @user = user
    @params = params
  end

  def exercises
    procs = []
    body_area_id = params[:body_area_id].blank? ? nil : params[:body_area_id].to_i
    exercise_keys = params[:exercise_keys].blank? ? nil : params[:exercise_keys].downcase.split

    if body_area_id
      procs.push -> (e) {e.primary_body_area_id == body_area_id}
    end
    if exercise_keys
      exercise_keys.each do |s|
        procs.push -> (e) {e.keys.include?(s)}
      end
    end

    @exercises ||= ExerciseCache.exercises.select do |e|
      r = true
      procs.each do |p|
        if !p.call(e)
          r = false
          break
        end
      end
      r
    end
  end
end
