class LevelingService
  attr_accessor :user, :level

  def initialize(user)
    @user = user
  end

  def get_level
    points = user.total_points
    Level.all.each do |level|
      if (points >= level.min_points && points <= level.max_points)
        return level
      end
    end
  end

  def check_and_set_level
    prev_level = user.level
    cur_level = get_level
    if (cur_level != prev_level)
      user.update_attribute(:level_id, cur_level.id)
      if (prev_level != nil && cur_level.value > prev_level.value)
        es = EventService.new(user)
        es.level_jump(cur_level)
      end
    end
  end

end
