class UserMailer < ApplicationMailer
  default from: "no_reply@updowntech.com"

  def welcome_email(user)
    @user = user
    mail(to: @user.email, subject: 'Welcome')
  end

  def password_change(user)
    @user = user
    mail(to: @user.email, subject: 'Password Change')
  end

  def email_change(user)
    @user = user
    mail(to: @user.email, subject: 'Email Change')
  end

end
