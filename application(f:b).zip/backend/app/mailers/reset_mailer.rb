class ResetMailer < ApplicationMailer

  def reset_password(user)
    @user = user
    mail(:to => @user.email, :subject => "[UpDownTech] Reset your password")
  end

end
