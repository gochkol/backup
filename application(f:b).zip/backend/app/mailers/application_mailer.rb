class ApplicationMailer < ActionMailer::Base

  default from: %Q{"UpDownTech" <noreply@updowntech.com>}

end
