class FriendsMailer < ApplicationMailer

  def request_made(user, friend)
    @user = user
    @friend = friend
    mail(:to => @friend.email, :subject => "#{user.first_name} added you as an Updown friend")
  end

end


