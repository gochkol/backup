module GlobalCacheWatch
  extend ActiveSupport::Concern

  included do
    @cache_watch_models = []
    @cache_watch_key = "cache:model-#{name}:update_time_t"
    after_commit :update_cache_time_t
  end


  class_methods do
    def watch_update(*args)
      options = args.last
      if options.is_a?(Hash)
        @cache_watch_models += options[:also] ? options[:also].map(&:to_s) : []
      end
    end

    def needs_refresh?(time_t)
      time_t < cache_time_t ? true : false
    end

    def cache_time_t
      time_t = $redis.get(@cache_watch_key).to_i
      if !time_t || time_t == 0
        time_t = Time.now.to_i
        $redis.set(@cache_watch_key, time_t)
      end
      time_t
    end

    def update_cache_time_t
      $redis.set(@cache_watch_key, Time.now.to_i)
      @cache_watch_models.each do |m|
        m.camelize.constantize.update_cache_time_t
      end
    end
  end

  def update_cache_time_t
    self.class.update_cache_time_t
  end
end

