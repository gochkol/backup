module UserCacheWatch
  extend ActiveSupport::Concern

  included do
    @@cache_watch_associations = []
    User.class_eval <<-EORUBY
      def #{name.pluralize.underscore}_cache_time_t
        key = "cache:user_id-"+self.id.to_s+":association-#{name.pluralize.underscore}:update_time_t"
        time_t = $redis.get(key).to_i
        if !time_t || time_t == 0
          time_t = Time.now.to_i
          $redis.set(key, time_t)
        end
        time_t
      end
    EORUBY
    after_commit :update_user_cache_time_t
  end

  class_methods do
    def watch_update(*args)
      options = args.last
      if options.is_a?(Hash)
        @@cache_watch_associations += options[:also] ? options[:also].map(&:to_s) : []
      end
    end
  end

  def update_user_cache_time_t
    return unless user
    key =  "cache:user_id-#{user.id}:association-#{self.class.name.pluralize.underscore}:update_time_t"
    $redis.set(key, Time.now.to_i)
    @@cache_watch_associations.each do |m|
      key =  "cache:user_id-#{user.id}:association-#{m}:update_time_t"
      $redis.set(key, Time.now.to_i)
    end
  end

  def update_friend_cache_time_t
    return unless friend
    key =  "cache:user_id-#{friend.id}:association-#{self.class.name.pluralize.underscore}:update_time_t"
    $redis.set(key, Time.now.to_i)
    @@cache_watch_associations.each do |m|
      key =  "cache:user_id-#{friend.id}:association-#{m}:update_time_t"
      $redis.set(key, Time.now.to_i)
    end
  end
end


