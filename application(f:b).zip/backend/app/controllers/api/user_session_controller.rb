class API::UserSessionController < API::BaseController
end
