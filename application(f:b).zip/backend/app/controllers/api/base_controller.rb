class API::BaseController < ActionController::Base
  before_action :set_current_user, :authenticate_request
  before_action :check_user_freshness, only: [:index]

  def check_user_freshness
    return unless @current_user
    key = controller_name + "_cache_time_t";
    time_t = @current_user.try(key)
    if time_t && !stale?(time_t)
      head 304
    end
  end

  rescue_from NotAuthenticatedError do
    render json: { error: 'Not Authorized' }, status: :unauthorized
  end

  rescue_from AuthenticationTimeoutError do
    render json: { error: 'Auth token is expired' }, status: 419 
  end

  private

  def set_current_user
    if decoded_auth_token
      @current_user ||= User.find(decoded_auth_token[:user_id])
      @current_user.auth_token = decoded_auth_token
    end
  end

  def authenticate_request
    if auth_token_expired?
      fail AuthenticationTimeoutError
    elsif !@current_user
      fail NotAuthenticatedError
    end
  end

  def decoded_auth_token
    @decoded_auth_token ||= AuthToken.decode(http_auth_header_content)
  end

  def auth_token_expired?
    decoded_auth_token && decoded_auth_token.expired?
  end

  def http_auth_header_content
    return @http_auth_header_content if defined? @http_auth_header_content
    @http_auth_header_content = begin
      if request.headers['Authorization'].present?
        request.headers['Authorization'].split(' ').last
      else
        nil
      end
    end
  end
end
