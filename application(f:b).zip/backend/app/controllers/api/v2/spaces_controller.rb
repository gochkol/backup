class API::V2::SpacesController < API::GlobalController

  def index
    render json: Space.active.to_json(only: [:name, :id])
  end
end


