class API::V2::LevelsController < API::GlobalController
  def index
    render json: Level.all.to_json(methods: [:icon_url])
  end
end
