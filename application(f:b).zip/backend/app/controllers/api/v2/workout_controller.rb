class API::V2::WorkoutController < API::BaseController

  def quick_create
    @service = WorkoutService.new(@current_user, params)
    @service.quick_create
    @workout= @service.workout
    render :create
  end

  def custom_create
    @service = WorkoutService.new(@current_user, params)
    @service.custom_create
    @workout= @service.workout
    render :create
  end

  def favorite_create
    @service = FavoriteService.new(@current_user, params)
    @service.create
    @workout = @service.workout
    render :create
  end

  def update
    @service = WorkoutUpdateService.new(@current_user, params)
    @service.update
    render json: @service.workout.as_json(only: [:id]).merge(point: @service.workout.point.as_json(version: 2)), status: :ok
  end

  def show
    @workout = @current_user.finished_friend_workouts.find(params[:id])
    render :create
  end

end


