class API::V2::Users::CompaniesController < API::BaseController

  def show
    @company = @current_user.companies.first
    if @company
      render :show
    else
      render json: "", status: :ok
    end
  end

  def join_company
    ts = TeamService.new(@current_user)
    ts.use_signup_code(params[:signup_code])
    @company = ts.company
    if @company
      render :show
    else
      render json: {errors: "Invalid Signup Code"}, status: 422
    end
  end

  def leave_company
    ts = TeamService.new(@current_user)
    ts.leave_company(@current_user.teams.last.id)
    render json: "", status: :ok
  end

end



