class API::V2::Users::QuickLogsController < API::BaseController
  def create
    n = params[:number_of_days_ago].to_i
    n = n > 2 ? 2 : n
    ql = @current_user.quick_logs.create(quick_activity_id: params[:quick_activity_id],
                                    duration: params[:duration], desc: params[:desc],
                                    calories_burned: params[:calories_burned],
                                    created_at: n.days.ago, distance_miles: params[:distance_miles])
    render json: ql.to_json(include: :point), status: :ok
  end
end




