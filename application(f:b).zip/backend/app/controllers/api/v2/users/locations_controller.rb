class API::V2::Users::LocationsController < API::BaseController
  def index
    render json: @current_user.locations.to_json(only: [:id, :name, :space_id], methods: :equipment_ids)
  end

  def update
    user = @current_user
    params[:locations].each do |l|
      location = user.locations.find(l[:id])
      location.update_attributes(name: l[:name], equipment_ids: l[:equipment_ids], space_id: l[:space_id])
      if (!location.valid?)
        render json: { errors: location.errors.full_messages }, status: 422
        return
      end
    end
    render json: @current_user.locations.to_json(only: [:id, :name, :space_id], methods: :equipment_ids)
  end
end
