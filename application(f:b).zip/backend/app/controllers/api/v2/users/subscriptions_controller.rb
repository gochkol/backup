class API::V2::Users::SubscriptionsController < API::GlobalController
  def show
    ms = MoneyService.new(@current_user)
    ms.refresh_subscription
    data = ms.subscription_data
    if (!data)
      render json: {errors: "Could not retrieve subscription data"}, status: 422
    else
      render json: data.to_json, status: :ok
    end
  end
end
