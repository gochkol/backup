class API::V2::Users::MoneyController < API::BaseController
  def payment_token
    service = MoneyService.new(@current_user)
    client_token = service.create_client_token
    render json: service.json, status: service.status
  end

  def payment_transaction
    service = MoneyService.new(@current_user)
    service.create_subscription(params)
    render json: service.json, status: service.status
  end

  def payment_update
    service = MoneyService.new(@current_user)
    service.update_payment(params)
    render json: service.json, status: service.status
  end

  def cancel_subscription
    service = MoneyService.new(@current_user)
    service.cancel_subscription
    render json: service.json, status: service.status
  end
end


