class API::V2::Users::EventsController < API::BaseController

  def index
    render json: @current_user.friend_events.all.includes([:user]).limit(25).order(created_at: :desc).to_json(version: 2)
  end
end

