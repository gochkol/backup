class API::V2::VersionController < API::BaseController
  skip_before_action :authenticate_request

  def check
    render json: {status: "dead"}
  end
end


