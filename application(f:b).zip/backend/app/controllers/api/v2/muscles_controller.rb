class API::V2::MusclesController < API::GlobalController
  def index
    render json: Muscle.active.to_json(only: [:name, :id])
  end
end


