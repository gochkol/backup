class API::V2::BlocksController < API::BaseController
  def destroy
    @current_user.blocks.find(params[:block_id]).try(:destroy)
    render json: "", status: :ok
  end

  def swap
    bs = BlockService.new(@current_user, params)
    bs.swap
    if bs.new_block
      @block = bs.new_block
      render :show
    else
      render json: {errors: "No similar exercises found!"}, status: 422
    end
  end

  def update
    b = @current_user.blocks.find(params[:block][:id])
    b.update_attribute(:rank, params[:block][:rank])
    b.update_attribute(:block_data, {block_sets: params[:block][:block_sets]})
    render json: "", status: :ok
  end

  def add_exercises
    bs = BlockService.new(@current_user, params)
    bs.add_exercises
    @blocks = bs.new_blocks
    render :add_exercises
  end

  def random
    bs = BlockService.new(@current_user, params)
    bs.random
    if bs.new_block
      @block = bs.new_block
      render :show
    else
      render json: {errors: "Could not add new exercise"}, status: 422
    end
  end

  def duplicate
    bs = BlockService.new(@current_user, params)
    bs.duplicate
    if bs.new_block
      @block = bs.new_block
      render :show
    else
      render json: {errors: "Could duplicate exercise"}, status: 422
    end
  end
end



