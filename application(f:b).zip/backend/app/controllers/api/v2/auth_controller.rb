class API::V2::AuthController < API::BaseController
  skip_before_action :authenticate_request

  def authenticate
    user = User.active.nonguest.find_by_email(params[:email]).try(:authenticate, params[:password])
    if user
      user.user_events.create(event_type: "login")
      render json: { auth_token: user.generate_auth_token }
    else
      render json: { errors: 'Invalid username or password' }, status: 422
    end
  end
end
