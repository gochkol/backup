class API::V2::BillingPlansController < API::GlobalController

  def index
    render json: BillingPlan.active.to_json(only: [:id, :name, :description])
  end
end

