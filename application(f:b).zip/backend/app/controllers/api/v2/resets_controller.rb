class API::V2::ResetsController < API::BaseController

  skip_before_action :authenticate_request

  def create
    if @user = User.find_by_email(params[:email])
      @user.forgot_password!
      ResetMailer.reset_password(@user).deliver
      render json: "", status: :ok
    else
      render json: { errors: "Email could not be found" }, status: 422
    end
  end

  def update
    if params[:password_reset_code].blank?
      render json: { errors: "Invalid password token" }, status: 422
      return
    end

    user = User.where(email: params[:email], password_reset_code: params[:password_reset_code]).first
    if !user
      render json: { errors: "Invalid email or password token" }, status: 422
      return
    end

    user.update_attributes(password: params[:password], password_confirmation: params[:password_confirmation])
    if user.valid?

      user.update_attribute(:password_reset_code, nil)
      render json: { auth_token: user.generate_auth_token }
    else
      render json: { errors: user.errors.full_messages }, status: 422
    end
  end

end

