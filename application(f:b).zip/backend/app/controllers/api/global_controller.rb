class API::GlobalController < API::BaseController
  skip_before_action :authenticate_request

  before_action :check_class_freshness, only: [:index]

  def check_class_freshness
    time_t = controller_name.classify.constantize.try(:cache_time_t)
    if time_t && !stale?(time_t)
      head 304
    end
  end
end

