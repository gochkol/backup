class API::V1::Users::BodyPartStatsController < API::BaseController

  def index
    render json: @current_user.body_part_stats.current.order(:body_part_id).includes([:body_part]).to_json(only: [:id, :body_part_id, :data], include: {body_part: {only: [:id, :name, :value]}})
  end

  def update
    user = @current_user
    params[:body_part_stats].each do |bs|
      old_bs = user.body_part_stats.current.where(id: bs[:id]).first
      next unless old_bs
      old_bs.update_data(bs[:data].to_f)
    end
    render json: @current_user.body_part_stats.current.order(:body_part_id).includes([:body_part]).to_json(only: [:id, :body_part_id, :data], include: {body_part: {only: [:id, :name, :value]}})
  end

  def stream
    render json: @current_user.body_part_stats.where(body_part_id: params[:body_part_id]).order(:created_at).to_json(only: [:data, :created_at])
  end
end


