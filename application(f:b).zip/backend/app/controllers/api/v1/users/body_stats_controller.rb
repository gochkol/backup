class API::V1::Users::BodyStatsController < API::BaseController

  def index
    render json: @current_user.body_stats.current.to_json(only: [:id, :name, :value, :data])
  end

  def update
    user = @current_user
    params[:body_stats].each do |bs|
      old_bs = user.body_stats.current.where(value: bs[:value]).first
      next unless old_bs
      old_bs.update_data(bs[:data].to_f)
    end

    render json: @current_user.body_stats.current.to_json(only: [:id, :name, :value, :data])  end

  def stream
    render json: @current_user.body_stats.where(value: params[:value]).order(:created_at).to_json(only: [:data, :created_at])
  end

end

