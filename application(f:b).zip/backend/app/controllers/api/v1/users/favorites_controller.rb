class API::V1::Users::FavoritesController < API::BaseController

  def index
    render json: @current_user.favorites.all.to_json(only: [:name, :id])
  end

  def create
    if @current_user.favorites.count >= 10
      render json: {errors: "You've reached the maximum number of favorites! You may delete current favorites to add new ones."}, status: 404
    else
      workout = Workout.find(params[:workout_id])
      Favorite.create(workout: workout, user: @current_user, name: params[:name])
      workout.update_attribute(:name, params[:name]);
      render json: "", status: :ok
    end
  end

  def destroy
    @current_user.favorites.find(params[:favorite_id]).destroy
    render json: @current_user.favorites.all.to_json(only: [:name, :id])
  end

end

