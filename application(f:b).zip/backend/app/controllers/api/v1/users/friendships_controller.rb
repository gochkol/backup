class API::V1::Users::FriendshipsController < API::BaseController

  def index
    friends = @current_user.friends.active.to_a.concat([@current_user])
    render json: friends.to_json(only: [:id, :first_name, :last_name, :avatar_url], methods: [:current_daily_points, :current_monthly_points, :current_total_points])
  end

  def search
    render json: @current_user.friend_search(params[:search_text]).to_json(only: [:id, :first_name, :last_name, :avatar_url])
  end

  def destroy
    Friendship.where(user_id: @current_user.id, friend_id: params[:friend_id]).first.destroy
    Friendship.where(user_id: params[:friend_id], friend_id: @current_user.id).first.destroy
    render json: @current_user.friends.active.to_json(only: [:id, :first_name, :last_name, :avatar_url], methods: [:current_daily_points, :current_monthly_points, :current_total_points])
  end

  def show
    @friend = @current_user.friends.where(id: params[:friend_id]).first
    @friend ||= @current_user.pending_friend_requests.where(user_id: params[:friend_id]).first.try(:user)
    if @friend
      @finished_workouts = @friend.finished_workouts
      render :show
    else
      render json: {errors: "Could not find friend"}, status: 422
    end
  end
end




