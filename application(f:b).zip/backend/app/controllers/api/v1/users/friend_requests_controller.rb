class API::V1::Users::FriendRequestsController < API::BaseController

  def index
    if params[:friend_request_type] == 'for_me'
      render json: @current_user.pending_friend_requests.includes([:user]).to_json(only: [:id], include: {user: {only: [:id, :first_name, :last_name, :avatar_url]}})
    elsif params[:friend_request_type] == 'from_me'
      render json: @current_user.pending_friends.includes([:user]).to_json(only: [:id], include: {friend: {only: [:id, :first_name, :last_name, :avatar_url]}})
    end
  end

  def create
    friend = User.active.find(params[:friend_id])
    @friend_request = @current_user.friend_requests.new(friend: friend, status: "pending")

    if @friend_request.save
      #FriendsMailer.request_made(@current_user, friend).deliver
      render json: @current_user.pending_friends.includes([:user]).to_json(only: [:id], include: {friend: {only: [:id, :first_name, :last_name, :avatar_url]}})
    else
      render json: @friend_request.errors, status: 422
    end
  end

  def destroy
    @current_user.pending_friends.where(friend_id: params[:friend_id]).first.try(:destroy)
    render json: @current_user.pending_friends.includes([:user]).to_json(only: [:id], include: {friend: {only: [:id, :first_name, :last_name, :avatar_url]}})
  end

  def accept
    fr = @current_user.pending_friend_requests.where(user_id: params[:user_id]).first
    fr.update_attribute(:status, "accepted")
    if fr.user.is_active?
      @current_user.friends << fr.user
      fr.user.friends << @current_user
    end
    render json: @current_user.pending_friend_requests.includes([:user]).to_json(only: [:id], include: {user: {only: [:id, :first_name, :last_name, :avatar_url]}})
  end

  def decline
    fr = @current_user.pending_friend_requests.where(user_id: params[:user_id]).first
    fr.update_attribute(:status, "declined")
    render json: @current_user.pending_friend_requests.includes([:user]).to_json(only: [:id], include: {user: {only: [:id, :first_name, :last_name, :avatar_url]}})
  end

end
