class API::V1::Users::PointsController < API::BaseController

  def index
    render json: @current_user.points.all.order(created_at: :desc).to_json
  end
end


