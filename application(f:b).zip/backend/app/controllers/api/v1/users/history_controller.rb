class API::V1::Users::HistoryController < API::BaseController

  def show
    @finished_workouts = @current_user.finished_workouts
    render :show
  end

end


