class API::V1::Users::EventsController < API::BaseController

  def index
    render json: @current_user.friend_events.all.includes([:user]).limit(25).order(created_at: :desc).to_json
  end
end

