class API::V1::Users::EventCommentsController < API::BaseController

  def create
    event = Event.find(params[:event_id])
    Comment.create(event: event, user: @current_user, comment_text: params[:comment_text])
    render json: event.comments.active.all.includes([:user]).order(created_at: :desc).to_json(only: [:comment_text, :id, :created_at], include: {user: {only: [:id, :first_name, :last_name, :avatar_url]}})
  end

  def index
    event = Event.find(params[:event_id])
    render json: event.comments.active.all.includes([:user]).order(created_at: :desc).to_json(only: [:comment_text, :id, :created_at], include: {user: {only: [:id, :first_name, :last_name, :avatar_url]}})
  end

  def destroy
    event = Event.find(params[:event_id])
    @current_user.comments.find(params[:comment_id]).destroy
    render json: event.comments.active.all.includes([:user]).order(created_at: :desc).to_json(only: [:comment_text, :id, :created_at], include: {user: {only: [:id, :first_name, :last_name, :avatar_url]}})
  end
end

