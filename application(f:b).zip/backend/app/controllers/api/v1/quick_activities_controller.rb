class API::V1::QuickActivitiesController < API::GlobalController
  def index
    render json: QuickActivity.all.to_json(only: [:name, :id, :is_distance])
  end
end
