class API::V1::EquipmentsController < API::GlobalController

  def index
    render json: Equipment.active.to_json(only: [:name, :id], methods: [:image_url], include: {equipment_group: {only: [:name, :id]}})
  end
end

