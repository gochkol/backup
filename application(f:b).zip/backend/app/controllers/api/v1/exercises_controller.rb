class API::V1::ExercisesController < API::GlobalController

  def index
    render json: ExerciseCache.exercise_array_json, status: :ok
  end

  def search
    s = ExerciseSearchService.new(@current_user, params)
    render json: s.exercises[0..30].to_json(only: [:id, :name]), status: :ok
  end
end
