class API::V1::BodyAreasController < API::GlobalController

  def index
    if params[:nested]
      render json: BodyArea.active.nested_list.to_json
    else
      render json: BodyArea.active.to_json(only: [:id, :name])
    end
  end
end
