class API::V1::UsagesController < API::GlobalController

  def index
    render json: Usage.active.to_json(only: [:name, :id])
  end
end
