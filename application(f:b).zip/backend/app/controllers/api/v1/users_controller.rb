class API::V1::UsersController < API::BaseController
  skip_before_action :authenticate_request, only: [:create]

  def create
    @service = UserService.new(params: params)
    @service.create
    @current_user = @service.user
    default_render
  end

  def show
    default_render(skip_validation: true)
  end

  def update
    @service = UserService.new(user: @current_user, params: params)
    @service.update
    @current_user = @service.user
    default_render
  end

  def default_render(skip_validation: false)
    if skip_validation || @current_user.valid?
      render json: {auth_token: @current_user.auth_token}.merge(@current_user.as_json(json_params)), status: :ok
    else
      render json: {errors: @current_user.errors.full_messages.join("\n") }, status: 422
    end
  end

  def json_params
    {
      only: [
        :id, :first_name, :last_name, :email, :birthdate, :gender, :experience,
        :intensity, :usage_id, :category_id, :birth_year, :birth_month, :birth_day,
        :settings, :avatar_url, :country_code, :state_code, :city, :zipcode,
        :current_status, :current_status_at
      ],
      methods: [
        :current_daily_points, :current_monthly_points,
        :current_total_points
      ]
    }
  end

end
