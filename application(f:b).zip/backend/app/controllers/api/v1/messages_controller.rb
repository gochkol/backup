class API::V1::MessagesController < API::GlobalController

  def index
    render json: Message.all.where(message_type: params[:message_type]).to_json(only: [:id, :text])
  end
end


