class API::V1::CategoriesController < API::GlobalController

  def index
    render json: Category.active.all.to_json(only: [:name, :id])
  end
end

