class SessionsController < ApplicationController

  skip_before_filter :login_required, only: [:new, :create]

  def new
    self.current_user = nil
    render :new
  end

  def create
    user = User.where(:email => params[:login]).first
    if user && user.authenticate(params[:password]) && user.admin
      self.current_user = user
      redirect_to rails_admin_path
    else
      flash[:danger] = "Invalid email or password"
      redirect_to login_path
    end
  end

  def destroy
    redirect_to login_path
  end
end

