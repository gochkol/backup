class ApplicationController < ActionController::Base
  include Authentication
end
