class DepartmentMember < ActiveRecord::Base
  belongs_to :department
  belongs_to :member, class_name: 'User', foreign_key: :user_id
  belongs_to :role

  validates :user_id, presence: true, uniqueness: true
end
