class ExercisesMuscle < ActiveRecord::Base
  include GlobalCacheWatch

  watch_update also: [:exercise]
  belongs_to :exercise
  belongs_to :muscle
end
