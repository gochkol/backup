class Favorite < ActiveRecord::Base
  include UserCacheWatch

  belongs_to :user
  belongs_to :workout
end
