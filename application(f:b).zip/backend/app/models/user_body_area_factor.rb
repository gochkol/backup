class UserBodyAreaFactor < ActiveRecord::Base
  belongs_to :user
  belongs_to :body_area
end
