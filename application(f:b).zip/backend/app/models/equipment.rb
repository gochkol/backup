class Equipment < ActiveRecord::Base
  include GlobalCacheWatch

  watch_update also: [:exercise]
  has_many :equipments_exercises
  has_many :exercises, through: :equipments_exercises
  belongs_to :equipment_group
  scope :active, -> { where(is_active: true) }

  def image_url
    URI.join(ENV['UPDOWN_DEFAULT_IMAGE_URL'], "equipment/#{self.id}_equipment.png").to_s
  end
end
