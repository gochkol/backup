class Company < ActiveRecord::Base
  has_many :departments
  has_many :teams
  has_many :company_members
  has_many :members, through: :company_members, class_name: 'User', foreign_key: :user_id
end
