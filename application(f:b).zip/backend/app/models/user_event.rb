class UserEvent < ActiveRecord::Base
  belongs_to :user
end
