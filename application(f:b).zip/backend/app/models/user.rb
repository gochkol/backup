require 'digest/sha1'

class User < ActiveRecord::Base
  has_secure_password

  scope :active, -> { where(is_active: true) }
  scope :nonguest, -> { where(is_guest: false) }

  belongs_to :usage
  has_many :locations_users
  has_many :locations, through: :locations_users
  belongs_to :category
  belongs_to :level
  before_destroy { locations.clear }
  has_many :user_body_area_factors, dependent: :destroy
  has_many :workouts, dependent: :destroy
  has_many :blocks, through: :workouts
  has_many :favorites, dependent: :destroy
  has_many :events, dependent: :destroy
  has_many :points, dependent: :destroy
  has_many :body_stats, dependent: :destroy
  has_many :body_part_stats, dependent: :destroy
  has_many :team_members, dependent: :destroy
  has_many :teams, through: :team_members
  has_many :department_members, dependent: :destroy
  has_many :departments, through: :department_members
  has_many :company_members, dependent: :destroy
  has_many :companies, through: :company_members
  has_many :friendships, dependent: :destroy
  before_destroy :destroy_inverse_friendships
  has_many :friends, through: :friendships
  has_many :friend_requests, dependent: :destroy
  before_destroy :destroy_inverse_friend_requests
  has_many :quick_logs, dependent: :destroy
  has_many :comments, dependent: :destroy
  has_many :user_events, dependent: :destroy
  has_many :modifiers
  has_many :money_logs
  belongs_to :billing_plan
  belongs_to :subscription

  accepts_nested_attributes_for :modifiers


  # Non-Guest Users
  validates :first_name, presence: true, unless: :is_guest?
  validates :last_name, presence: true, unless: :is_guest?
  validates :email, presence: true, uniqueness: true, format: /\A[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,6}\z/i, unless: :is_guest?
  validates :password, presence: { on: :create }, unless: :is_guest?
  validates :password_confirmation, presence: { on: :create }, unless: :is_guest?
  validates :password_confirmation, presence: { on: :update }, if: ->(user){ user.password.present? }, unless: :is_guest?
  validates :birthdate, presence: true, unless: :is_guest?
  validates :birth_year, presence: true, unless: :is_guest?
  validates :birth_month, presence: true, unless: :is_guest?
  validates :birth_day, presence: true, unless: :is_guest?
  validate  :validate_current_password, unless: :is_guest?
  validate  :validate_avatar_upload, unless: :is_guest?

  before_validation :create_birthday, unless: :is_guest?
  after_create :create_body_area_factors, unless: :is_guest?
  after_create :create_default_stats, unless: :is_guest?
  after_create :use_signup_code, unless: :is_guest?
  before_update :check_status, unless: :is_guest?


  # Guests only
  before_validation :create_guest_defaults

  # Guest and Non-Guest Users
  validates :gender, inclusion: { in: %w(male female) }
  validates :experience, presence: true, inclusion: 1..3
  validates :intensity, presence: true, inclusion: 1..10
  validates :usage_id, presence: true
  validates :category_id, presence: true

  after_create :create_default_locations
  after_create :create_default_modifiers
  after_create :generate_auth_token

  attr_accessor :auth_token, :current_password, :valid_current_password, :avatar_file

  def friend_events
    Event.all.where(user_id: friend_ids.push(self.id))
  end

  def auth_token
    @auth_token ||= nil
  end

  def finished_workouts
    workouts.where.not(finished_at: nil)
  end

  def custom_workouts
    workouts.where(workout_type: "custom")
  end

  def finished_friend_workouts
    Workout.where.not(finished_at: nil).where(user_id: self.friend_ids << self.id)
  end

  def friend_points
    Point.all.where(user_id: friend_ids.push(self.id))
  end

  def status_meta_data
    {user: self.as_json(only: [:id, :first_name, :last_name, :current_status, :current_status_at])}
  end

  #these are people that have requested to be friends with you
  def pending_friend_requests
    FriendRequest.all.where(friend_id: id, status: "pending")
  end

  #these are people that you have request to be your friend
  def pending_friends
    FriendRequest.all.where(user_id: id, status: "pending")
  end

  def factors_for_body_area_id(body_area_id=nil)
    if is_guest
      body_area = BodyArea.find(body_area_id)
      h = BodyAreaConstants::BAC[gender][experience][body_area.value]
      ubaf = UserBodyAreaFactor.new(user: self, body_area: body_area, mr: h[:mr], mw: h[:mw])
    else
      ubaf = user_body_area_factors.where(body_area_id: body_area_id).order(created_at: :desc).first
      if ubaf.nil?
        body_area = BodyArea.find(body_area_id)
        h = BodyAreaConstants::BAC[gender][experience][body_area.value]
        ubaf = UserBodyAreaFactor.create(user: self, body_area: body_area, mr: h[:mr], mw: h[:mw])
      end
    end
    ubaf
  end

  def self.authenticate(email, password)
    find_by_email(email).try(:authenticate, password)
  end

  def generate_auth_token
    payload = { user_id: self.id }
    @auth_token = AuthToken.encode(payload)
  end

  def billing_plan_name
    return "" if !subscription
    subscription.billing_plan.name
  end

  def subscription_status
    return "none" if !subscription
    subscription.status.downcase
  end

  def use_signup_code
    ts = TeamService.new(self)
    ts.use_signup_code(signup_code)
  end

  def check_status
    if changed.include?('current_status')
      self.current_status_at = DateTime.now
      es = EventService.new(self)
      es.update_status(current_status)
    end
  end

  def forgot_password!
    update_attribute(:password_reset_code, make_token) if password_reset_code.blank?
  end

  def bafs
    h = {}
    BodyArea.active.each do |ba|
      h[ba.id] = factors_for_body_area_id(ba.id)
    end
    h
  end

  def event_data
    {event: self.as_json(only: [:id, :name], include: {user: {only: [:id, :first_name, :last_name]}})}
  end

  def create_default_modifiers
    if modifiers.empty?
      Modifier.types.each do |type|
        modifiers << Modifier.create(modifier_type: type, name: type.capitalize)
      end
    end
  end

  def rest_mod
    modifiers.rest_type.value
  end

  def set_mod
    modifiers.set_type.value
  end

  # TODO: this methods below is very fragile, should refactor and make better when time allows
  def create_default_locations
    if is_guest
      self.locations = Location.guest
    else
      l = Location.create(name: "Home", space_id: Space.where(value: "s").first.id)
      e = Equipment.active.where(value: "towel")
      unless e.empty?
        l.equipments << e.first
      end
      self.locations << l

      l = Location.create(name: "Work", space_id: Space.where(value: "s").first.id)
      self.locations << l

      l = Location.create(name: "Gym", space_id: Space.where(value: "l").first.id)
      l.equipment_ids = Equipment.active.where.not(value: ["hurdles", "bike"]).map(&:id)
      self.locations << l

      l = Location.create(name: "Custom 1", space_id: Space.first.id)
      self.locations << l

      l = Location.create(name: "Custom 2", space_id: Space.first.id)
      self.locations << l
    end
  end

  def create_default_stats
    BodyStat::DEFAULT_NAME_VALUES.each do |nv|
      BodyStat.create(user: self, name: nv[0], value: nv[1], data: 0.0, is_current: true)
    end
    BodyPart.all.each do |bp|
      BodyPartStat.create(user: self, body_part: bp, data: 0.0, is_current: true)
    end
  end

  def friend_search(search)
    return [] if search.blank?
    sp = search.split.map(&:downcase)
    non = (friends.map(&:id) + pending_friends.map(&:friend_id)).uniq
    non.push(self.id)
    User.active.where('id NOT IN (?) AND (lower(first_name) IN (?) OR lower(last_name) IN (?) OR lower(email) IN (?))', non, sp, sp, sp)

  end

  def create_body_area_factors
    BodyArea.all.each do |body_area|
      h = BodyAreaConstants::BAC[gender][experience][body_area.value]
      UserBodyAreaFactor.create(user: self, body_area: body_area, mr: h[:mr], mw: h[:mw])
    end
  end

  def current_daily_points
    if points_updated_at.nil? || points_updated_at < DateTime.now.beginning_of_day
      update_points
    end
    daily_points
  end

  def current_monthly_points
    if points_updated_at.nil? || points_updated_at < DateTime.now.beginning_of_month
      update_points
    end
    monthly_points
  end

  def current_total_points
    total_points
  end

  def calculate_day_points(days_ago)
    points.where('earned_at >= ? AND earned_at < ?', (DateTime.now-days_ago.days).beginning_of_day, (DateTime.now-days_ago.days).end_of_day).map(&:number_of).inject {|sum, x| sum+x} || 0
  end

  def calculate_month_points(days_ago)
    points.where('earned_at >= ? AND earned_at < ?', (DateTime.now-days_ago.days).beginning_of_month, (DateTime.now-days_ago.days).end_of_month).map(&:number_of).inject {|sum, x| sum+x} || 0
  end

  def calculate_daily_points
    points.where('earned_at >= ?', DateTime.now.beginning_of_day).map(&:number_of).inject {|sum, x| sum+x} || 0
  end

  def calculate_monthly_points
    points.where('earned_at >= ?', DateTime.now.beginning_of_month).map(&:number_of).inject {|sum, x| sum+x} || 0
  end

  def calculate_total_points
    points.all.map(&:number_of).inject {|sum, x| sum+x} || 0
  end

  def update_points
    self.daily_points = calculate_daily_points
    self.monthly_points = calculate_monthly_points
    self.total_points = calculate_total_points
    self.points_updated_at = DateTime.now
    self.save
    ls = LevelingService.new(self)
    ls.check_and_set_level
  end

  def update_level
    ls = LevelingService.new(self)
    ls.check_and_set_level
  end

  protected

  def destroy_inverse_friendships
    Friendship.where(friend_id: id).destroy_all
  end

  def destroy_inverse_friend_requests
    FriendRequest.where(friend_id: id).destroy_all
  end


  def create_birthday
    self.birthdate = self.birth_year.to_s + "-" + self.birth_month.to_s + "-" + self.birth_day.to_s
  end

  def create_guest_defaults
    return unless self.is_guest
    self.gender ||= 'male'
    self.experience ||= 2
    self.intensity ||= 5
    self.usage_id ||= Usage.default.id
    self.category_id ||= Category.default.id
    self.password = "ThisPasswordShouldNeverBeSeenUnlessYouAreLookingAtThisCode"
    self.email = "email@somewhere.com"
  end

  def secure_digest(*args)
    Digest::SHA1.hexdigest(args.flatten.join('--'))
  end

  def make_token
    secure_digest(Time.now, (1..10).map{ rand.to_s })
  end

  def validate_current_password
    if current_password && !valid_current_password
      errors.add(:base, "Current password did not match")
    end
  end

  def validate_avatar_upload
    if avatar_file && !avatar_url
      errors.add(:base, "Could not upload avatar")
    end
  end

end
