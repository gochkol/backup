class Muscle < ActiveRecord::Base
  include GlobalCacheWatch

  watch_update also: [:exercise]
  has_many :exercises_muscles
  has_many :exercises, through: :exercises_muscles
  scope :active, -> { where(is_active: true) }
end
