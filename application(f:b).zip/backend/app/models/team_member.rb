class TeamMember < ActiveRecord::Base
  belongs_to :team
  belongs_to :member, class_name: 'User', foreign_key: :user_id
  belongs_to :role

  validates :user_id, presence: true, uniqueness: {scope: [:team_id]}
end
