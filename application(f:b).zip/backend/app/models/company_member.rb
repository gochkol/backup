class CompanyMember < ActiveRecord::Base
  belongs_to :company
  belongs_to :member, class_name: 'User', foreign_key: :user_id
  belongs_to :role

  validates :user_id, presence: true, uniqueness: {scope: [:company_id]}
end
