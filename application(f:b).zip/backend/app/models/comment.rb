class Comment < ActiveRecord::Base
  belongs_to :user
  belongs_to :event
  scope :active, -> { where(is_active: true) }

  after_create :inc_comment_count
  before_destroy :dec_comment_count


  def inc_comment_count
    cnt = event.comment_count + 1
    event.update_attribute(:comment_count, cnt)
  end

  def dec_comment_count
    return unless event
    cnt = event.comment_count - 1
    event.update_attribute(:comment_count, cnt)
  end

  def seconds_ago
    (Time.now - created_at).floor
  end


end
