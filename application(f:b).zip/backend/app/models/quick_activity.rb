class QuickActivity < ActiveRecord::Base
  include GlobalCacheWatch
  has_many :quick_logs
end
