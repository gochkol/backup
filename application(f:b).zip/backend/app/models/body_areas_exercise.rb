class BodyAreasExercise < ActiveRecord::Base
  include GlobalCacheWatch

  watch_update also: [:exercise]
  belongs_to :body_area
  belongs_to :exercise
end
