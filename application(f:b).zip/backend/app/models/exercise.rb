class Exercise < ActiveRecord::Base
  include GlobalCacheWatch

  has_many :blocks
  has_many :workouts, through: :blocks
  has_many :body_areas_exercises
  has_many :body_areas, through: :body_areas_exercises
  has_many :exercises_muscles
  has_many :muscles, through: :exercises_muscles
  has_many :equipments_exercises
  has_many :equipments, through: :equipments_exercises
  has_many :categories_exercises
  has_many :categories, through: :categories_exercises
  belongs_to :alternation
  belongs_to :mode
  belongs_to :space
  belongs_to :primary_body_area, class_name: "BodyArea", foreign_key: "primary_body_area_id"

  scope :no_equipment, -> { joins("LEFT JOIN equipments_exercises ON exercises.id = equipments_exercises.exercise_id").where("equipments_exercises.exercise_id IS NULL").distinct }
  scope :active, -> { where(is_active: true) }

  def animation_image_urls
    blank = URI.join(ENV['UPDOWN_DEFAULT_IMAGE_URL'], 'exercise-photos/nope.png').to_s
    base_url = URI.join(ENV['UPDOWN_DEFAULT_IMAGE_URL'], '/exercise-photos/').to_s
    if animation_sequence.blank?
      [blank]
    else
      a = []
      l = animation_sequence.split("__")[0].split("_").count/2
      (1..l).each do |i|
        a.push("#{base_url}#{id}_#{i}.png")
      end
      a
    end
  end

  def m_ids
    muscle_ids
  end

  def e_ids
    equipment_ids
  end

  def c_ids
    category_ids
  end

  def to_h
    e = self
    {
      id: e.id,
      name: e.name,
      keys: e.keys,
      popularity: e.popularity,
      met: e.met,
      experience: e.experience,
      animation: {
        sequence: e.animation_sequence.blank? ? "1_1000__1" : e.animation_sequence,
        images: e.animation_image_urls
      },
      primary_body_area_id: e.primary_body_area.id,
      primary_body_area_value: e.primary_body_area.value,
      space_id: e.space.id,
      mode_id: e.mode.id,
      mode_value: e.mode.value,
      equipment_ids: e.equipment_ids,
      muscle_ids: e.muscle_ids,
      category_ids: e.category_ids
    }
  end

  def exercise_hash
    e = self
    {
          exercise:{
            id: e.id,
            name: e.name,
            popularity: e.popularity,
            met: e.met,
            experience: e.experience,
            animation: {
              sequence: e.animation_sequence.blank? ? "1_1000__1" : e.animation_sequence,
              images: e.animation_image_urls
            },
            primary_body_area_value: e.primary_body_area.value,
            mode_value: e.mode.value,
            equipment_ids: e.equipment_ids
          }
    }
  end
end
