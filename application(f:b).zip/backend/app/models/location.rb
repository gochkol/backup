class Location < ActiveRecord::Base
  include UserCacheWatch

  has_many :locations_users
  has_many :users, through: :locations_users
  has_and_belongs_to_many :equipments
  belongs_to :space

  validates :name, presence: true

  scope :guest, -> { where(is_guest: true) }

  def user
    users.first
  end

end
