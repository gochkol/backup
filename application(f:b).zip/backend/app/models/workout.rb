class Workout < ActiveRecord::Base
  belongs_to :user
  belongs_to :category
  belongs_to :point
  has_many :blocks, dependent: :destroy
  has_many :exercises, through: :blocks
  has_many :favorites, dependent: :destroy

  def meta_data
    {workout: self.as_json(only: [:id, :name], include: {user: {only: [:id, :first_name, :last_name]}})}
  end

  def exercises_hash
    h = {}
    exercises.each do |e|
      eh = {
          exercise:{
            id: e.id,
            name: e.name,
            popularity: e.popularity,
            met: e.met,
            experience: e.experience,
            animation: {
              sequence: e.animation_sequence.blank? ? "1_1000__1" : e.animation_sequence,
              images: e.animation_image_urls
            },
            primary_body_area_value: e.primary_body_area.value,
            mode_value: e.mode.value,
            equipment_ids: e.equipment_ids
          }
        }
      h[e.id] = eh
    end
    h
  end
  
end

