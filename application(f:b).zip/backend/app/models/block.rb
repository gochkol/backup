class Block < ActiveRecord::Base
  belongs_to :workout
  belongs_to :exercise

  after_create :set_rank

  def set_rank
    update_attribute(:rank,  workout.blocks.count) unless rank
  end
end
