class Alternation < ActiveRecord::Base
  has_many :exercises
  scope :active, -> { where(is_active: true) }
end
