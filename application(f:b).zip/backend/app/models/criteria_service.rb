class CriteriaService
  attr_accessor :category_id, :usage_value, :intensity, :bafs, :rest_mod, :set_mod

  def initialize(category, usage, intensity, bafs, rest_mod, set_mod)
    @category_id = category.id
    @usage_value = usage.value
    @intensity = intensity
    @bafs = bafs
    @rest_mod = rest_mod
    @set_mod = set_mod
  end

  def criterion(e)
    mode = e.mode.value
    h = {}
    special = [4, 1, 2, 6].include?(category_id)
    if (mode.include?("repetition"))
      if !mode.include?("weight")
        reps = get_reps (e)
        h[:reps] = reps
      else
        h[:reps] = CC[category_id][usage_value][:reps][intensity]
        h[:weight] = get_weight(e, h[:reps])
      end
      h[:rest] = (rest_mod * CC[category_id][usage_value][:rest][intensity]).floor
      if special && h[:weight].nil?
        h[:rest] = (rest_mod * h[:rest] * (0.8 - (intensity*0.03))).floor
      end
      h[:time] = (set_mod * h[:reps] * e.rate + h[:rest]).floor
      h[:rate] = e.rate
      h[:mode] = 'reps'
    elsif (mode.include?("pattern"))
      if !mode.include?("weight")
        reps = get_reps (e)
        h[:pattern] = reps
      else
        h[:pattern] = CC[category_id][usage_value][:reps][intensity]
        h[:weight] = get_weight(e, h[:pattern])
      end
      h[:rest] = (rest_mod * CC[category_id][usage_value][:rest][intensity]).floor
      if special && h[:weight].nil?
        h[:rest] = (rest_mod * h[:rest] * (0.8 - (intensity*0.03))).floor
      end
      h[:time] = (set_mod * h[:pattern] * e.rate + h[:rest]).floor
      h[:rate] = e.rate;
      h[:mode] = 'pattern'
    elsif (mode.include?("breath"))
      if !mode.include?("weight")
        reps = get_reps (e)
        h[:breath] = reps
      else
        h[:breath] = CC[category_id][usage_value][:reps][intensity]
        h[:weight] = get_weight(e, h[:breath])
      end
      h[:rest] = (rest_mod * CC[category_id][usage_value][:rest][intensity]).floor
      if special && h[:weight].nil?
        h[:rest] = (rest_mod * h[:rest] * (0.8 - (intensity*0.03))).floor
      end
      h[:time] = (set_mod * h[:breath] * e.rate + h[:rest]).floor
      h[:rate] = e.rate;
      h[:mode] = 'breath'
    else
      h[:duration] = set_mod * CC[category_id][usage_value][:duration][intensity]
      if mode.include?("weight")
        h[:weight] = e.base_weight
      end
      h[:rest] = (rest_mod * CC[category_id][usage_value][:rest][intensity]).floor
      if special && h[:weight].nil?
        h[:rest] = (rest_mod * h[:rest] * (0.8 - (intensity*0.03))).floor
      end
      h[:time] = (h[:duration] + h[:rest]).floor
      h[:rate] = 1.0;
      h[:mode] = 'duration'
    end
    if (h[:reps] && e.alternation_id == 3)
      h[:reps] = h[:reps] + (h[:reps]%2)
    end
    h
  end

  def get_weight(e, r)
    baf = bafs[e.primary_body_area_id]
    mr = baf.mr
    mw = baf.mw
    t = e.technique
    i = intensity + 1

    temp_r = t * (0.75 + (0.025 * i)) * mr
    temp_w = t * (0.75 + (0.025 * i)) * mw

    a = Math.log(r)
    b = Math.log(temp_r)
    c = temp_w * temp_w

    w = Math.sqrt(c*(1 - (a/b)))
    v = (w/5).floor * 5
    v = v < e.base_weight ? e.base_weight : v
    v
  rescue StandardError => excep
    e.base_weight
  end

  def get_reps(e)
    baf = bafs[e.primary_body_area_id]
    mr = baf.mr
    t = e.technique
    i = intensity + 1
    v = t * (0.75 + ( 0.025 * i)) * mr
    v = v.floor
    v = (v > 50) ? 50 : v
    v
  end

  def get_exercise_time(e)
    criterion(e)[:time] * sets
  end

  def sets
    CC[category_id][usage_value][:sets][intensity]
  end

  def block_data(e)
    bd = {block_sets: []}
    sets.times do |s|
      bd[:block_sets].push({exercise_id: e.id, criterion: criterion(e)})
    end
    bd
  end

  CC = HashWithIndifferentAccess.new ({
  4 => {
    :strength => {
      :rest => [180,150,120,180,150,135,120,150,135,120],
      :sets => [3,3,3,4,4,4,4,5,5,6],
      :reps => [6,5,4,6,5,5,4,6,4,4],
      :duration => [20,25,30,35,40,45,45,50,55,60]
    },
    :muscle => {
      :rest => [120,105,105,105,105,90,75,90,75,60],
      :sets => [2,2,2,3,3,3,3,4,4,4],
      :reps => [8,9,10,8,10,10,12,10,12,14],
      :duration => [20,25,30,35,40,45,45,50,55,60]
    },
    :fitness => {
      :rest => [90,75,75,90,75,75,60,75,60,45],
      :sets => [1,1,1,2,2,2,2,3,3,3],
      :reps => [8,10,12,8,10,12,14,10,12,14],
      :duration => [20,25,30,35,40,45,45,50,55,60]
    },
    :weight => {
      :rest => [90,75,75,90,75,75,60,75,60,45],
      :sets => [2,2,2,3,3,3,3,4,4,4],
      :reps => [9,10,12,13,14,9,10,12,13,15],
      :duration => [20,25,30,35,40,45,45,50,55,60]
    },
    :endurance => {
      :rest => [90,90,75,75,75,60,60,45,45,30],
      :sets => [2,2,2,3,3,3,3,3,4,4],
      :reps => [12,14,16,12,14,16,18,18,16,16],
      :duration => [20,25,30,35,40,45,45,50,55,60]
    }
  },
  1 => {
    :strength => {
      :rest => [180,150,120,180,150,135,120,150,135,120],
      :sets => [3,3,3,4,4,4,4,5,5,6],
      :reps => [6,5,4,6,5,5,4,6,4,4],
      :duration => [20,25,30,35,40,45,45,50,55,60]
    },
    :muscle => {
      :rest => [120,105,105,105,105,90,75,90,75,60],
      :sets => [2,2,2,3,3,3,3,4,4,4],
      :reps => [8,9,10,8,10,10,12,10,12,14],
      :duration => [20,25,30,35,40,45,45,50,55,60]
    },
    :fitness => {
      :rest => [90,75,75,90,75,75,60,75,60,45],
      :sets => [1,1,1,2,2,2,2,3,3,3],
      :reps => [8,10,12,8,10,12,14,10,12,14],
      :duration => [20,25,30,35,40,45,45,50,55,60]
    },
    :weight => {
      :rest => [90,75,75,90,75,75,60,75,60,45],
      :sets => [2,2,2,3,3,3,3,4,4,4],
      :reps => [9,10,12,13,14,9,10,12,13,15],
      :duration => [20,25,30,35,40,45,45,50,55,60]
    },
    :endurance => {
      :rest => [90,90,75,75,75,60,60,45,45,30],
      :sets => [2,2,2,3,3,3,3,3,4,4],
      :reps => [12,14,16,12,14,16,18,18,16,16],
      :duration => [20,25,30,35,40,45,45,50,55,60]
    }
  },
  2 => {
    :strength => {
      :rest => [75,60,45,30,25,30,25,20,15,10],
      :sets => [1,1,1,1,1,2,2,2,2,2],
      :reps => [10,11,12,13,14,11,12,13,14,15],
      :duration => [20,25,30,35,40,45,45,50,55,60]
    },
    :muscle => {
      :rest => [75,60,45,30,25,30,25,20,15,10],
      :sets => [1,1,1,1,1,2,2,2,2,2],
      :reps => [10,11,12,13,14,11,12,13,14,15],
      :duration => [20,25,30,35,40,45,45,50,55,60]
    },
    :fitness => {
      :rest => [75,60,45,30,25,30,25,20,15,10],
      :sets => [1,1,1,1,1,2,2,2,2,2],
      :reps => [10,11,12,13,14,11,12,13,14,15],
      :duration => [20,25,30,35,40,45,45,50,55,60]
    },
    :weight => {
      :rest => [75,60,45,30,25,30,25,20,15,10],
      :sets => [1,1,1,1,1,2,2,2,2,2],
      :reps => [10,11,12,13,14,11,12,13,14,15],
      :duration => [20,25,30,35,40,45,45,50,55,60]
    },
    :endurance => {
      :rest => [75,60,45,30,25,30,25,20,15,10],
      :sets => [1,1,1,1,1,2,2,2,2,2],
      :reps => [10,11,12,13,14,11,12,13,14,15],
      :duration => [20,25,30,35,40,45,45,50,55,60]
    }
  },
  6 => {
    :strength => {
      :rest => [75,60,45,30,25,30,25,20,15,10],
      :sets => [1,1,1,1,1,2,2,2,2,2],
      :reps => [10,11,12,13,14,11,12,13,14,15],
      :duration => [20,25,30,35,40,45,45,50,55,60]
    },
    :muscle => {
      :rest => [75,60,45,30,25,30,25,20,15,10],
      :sets => [1,1,1,1,1,2,2,2,2,2],
      :reps => [10,11,12,13,14,11,12,13,14,15],
      :duration => [20,25,30,35,40,45,45,50,55,60]
    },
    :fitness => {
      :rest => [75,60,45,30,25,30,25,20,15,10],
      :sets => [1,1,1,1,1,2,2,2,2,2],
      :reps => [10,11,12,13,14,11,12,13,14,15],
      :duration => [20,25,30,35,40,45,45,50,55,60]
    },
    :weight => {
      :rest => [75,60,45,30,25,30,25,20,15,10],
      :sets => [1,1,1,1,1,2,2,2,2,2],
      :reps => [10,11,12,13,14,11,12,13,14,15],
      :duration => [20,25,30,35,40,45,45,50,55,60]
    },
    :endurance => {
      :rest => [75,60,45,30,25,30,25,20,15,10],
      :sets => [1,1,1,1,1,2,2,2,2,2],
      :reps => [10,11,12,13,14,11,12,13,14,15],
      :duration => [20,25,30,35,40,45,45,50,55,60]
    }
  }, 
  3 => {
    :strength => {
      :rest => [15,15,15,15,15,10,10,10,10,10],
      :sets => [1,1,1,1,1,1,1,1,1,1],
      :reps => [10,10,10,12,12,12,14,14,14,14],
      :duration => [30,30,30,45,45,45,45,60,60,60]
    },
    :muscle => {
      :rest => [15,15,15,15,15,10,10,10,10,10],
      :sets => [1,1,1,1,1,1,1,1,1,1],
      :reps => [10,10,10,12,12,12,14,14,14,14],
      :duration => [30,30,30,45,45,45,45,60,60,60]
    },
    :fitness => {
      :rest => [15,15,15,15,15,10,10,10,10,10],
      :sets => [1,1,1,1,1,1,1,1,1,1],
      :reps => [10,10,10,12,12,12,14,14,14,14],
      :duration => [30,30,30,45,45,45,45,60,60,60]
    },
    :weight => {
      :rest => [15,15,15,15,15,10,10,10,10,10],
      :sets => [1,1,1,1,1,1,1,1,1,1],
      :reps => [10,10,10,12,12,12,14,14,14,14],
      :duration => [30,30,30,45,45,45,45,60,60,60]
    },
    :endurance => {
      :rest => [15,15,15,15,15,10,10,10,10,10],
      :sets => [1,1,1,1,1,1,1,1,1,1],
      :reps => [10,10,10,12,12,12,14,14,14,14],
      :duration => [30,30,30,45,45,45,45,60,60,60]
    }
  },
  5 => {
    :strength => {
      :rest => [15,15,15,15,15,10,10,10,10,10],
      :sets => [2,2,2,2,2,3,3,3,3,3],
      :reps => [10,10,10,11,11,11,12,12,12,12],
      :duration => [30,30,30,35,35,35,40,40,45,45]
    },
    :muscle => {
      :rest => [15,15,15,15,15,10,10,10,10,10],
      :sets => [2,2,2,2,2,3,3,3,3,3],
      :reps => [10,10,10,11,11,11,12,12,12,12],
      :duration => [30,30,30,35,35,35,40,40,45,45]
    },
    :fitness => {
      :rest => [15,15,15,15,15,10,10,10,10,10],
      :sets => [2,2,2,2,2,3,3,3,3,3],
      :reps => [10,10,10,11,11,11,12,12,12,12],
      :duration => [30,30,30,35,35,35,40,40,45,45]
    },
    :weight => {
      :rest => [15,15,15,15,15,10,10,10,10,10],
      :sets => [2,2,2,2,2,3,3,3,3,3],
      :reps => [10,10,10,11,11,11,12,12,12,12],
      :duration => [30,30,30,35,35,35,40,40,45,45]
    },
    :endurance => {
      :rest => [15,15,15,15,15,10,10,10,10,10],
      :sets => [2,2,2,2,2,3,3,3,3,3],
      :reps => [10,10,10,11,11,11,12,12,12,12],
      :duration => [30,30,30,35,35,35,40,40,45,45]
    }
  }
})
end

