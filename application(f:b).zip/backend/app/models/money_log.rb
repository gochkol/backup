class MoneyLog < ActiveRecord::Base
  serialize :result
  belongs_to :user
end
