class EquipmentGroup < ActiveRecord::Base
  include GlobalCacheWatch

  has_many :equipments
end
