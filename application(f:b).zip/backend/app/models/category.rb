class Category < ActiveRecord::Base
  include GlobalCacheWatch

  watch_update also: [:exercise]
  has_many :categories_exercises
  has_many :exercises, through: :categories_exercises
  has_many :workouts
  scope :active, -> { where(is_active: true) }
  scope :default, -> { active.first }
end
