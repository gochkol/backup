class QuickLog < ActiveRecord::Base
  include UserCacheWatch

  belongs_to :user
  belongs_to :quick_activity
  belongs_to :point

  after_create :create_event
  after_create :add_points

  def meta_data
    {quick_log: self.as_json(only: [:id, :duration, :desc, :calories_burned, :distance_miles],
                 include: {user: {only: [:id, :first_name, :last_name]},
                           quick_activity: {only: [:id, :name, :value]}})}
  end

  # TODO V1 DEPRACATION PART 3
  # remove method below
  def event_sentence
    "#{user.first_name} #{user.last_name} did #{duration} minutes of #{quick_activity.name}"
  end

  private

  def add_points
    ps = PointsService.new(user)
    ps.finish_quick_log(self)
    update_attribute(:point_id, ps.point.id)
  end

  def create_event
    es = EventService.new(user)
    es.finish_quick_log(self)
  end

end
