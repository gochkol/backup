class Event < ActiveRecord::Base
  include UserCacheWatch

  belongs_to :user
  has_many :comments, dependent: :destroy

  def as_json(options={})
    json = super(only: [:id, :comment_count, :event_type, :created_at], include: {user: {only: [:id, :first_name, :last_name, :avatar_url]}})
    if options[:version] == 2
      json[:event_data] = self.v2_event_data
    else
      json[:event_data] = self.event_data
    end
    json

    # TODO V1 DEPRACATION PART 2
    # delete above and uncomment below
    #super(only: [:id, :comment_count, :event_type, :event_data, :created_at], include: {user: {only: [:id, :first_name, :last_name, :avatar_url]}})
  end

end

