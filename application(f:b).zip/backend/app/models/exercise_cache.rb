class ExerciseCache
  @@exercises = nil
  @@exercise_hash = nil
  @@exercise_array_json = nil
  @@cache_time_t = -1

  def self.exercises
    if Exercise.needs_refresh?(@@cache_time_t)
      @@exercises = nil
      @@exercise_hash = nil
      @@exercise_array_json = nil
      @@cache_time_t = Time.now.to_i
    end
    @@exercises ||= Exercise.active.includes([:equipments, :categories, :mode, :muscles, :space, :primary_body_area]).to_a
  end

  def self.exercise_hash
    @@exercise_hash ||= begin
      h = {}
      exercises.each {|e| h[e.id] = e}
      h
    end
  end

  def self.exercise_array_json
    @@exercise_array_json ||= begin
      a = []
      exercises.each {|e| a.push(e.to_h)}
      a.to_json
    end
  end

  self.exercise_array_json

end
