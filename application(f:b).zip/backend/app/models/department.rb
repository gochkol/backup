class Department < ActiveRecord::Base
  belongs_to :company
  has_many :teams
  has_many :department_members
  has_many :members, through: :department_members, class_name: 'User', foreign_key: :user_id

end
