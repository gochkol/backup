class Team < ActiveRecord::Base
  has_many :team_members
  has_many :members, through: :team_members, class_name: 'User', foreign_key: :user_id
  belongs_to :company
  belongs_to :department

  after_create :generate_signup_code

  def generate_signup_code
    update_attribute(:signup_code, ('A'..'Z').to_a.shuffle[0,8].join)
  end
end
