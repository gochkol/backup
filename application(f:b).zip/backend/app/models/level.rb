class Level < ActiveRecord::Base
  default_scope { order(:min_points) }

  def meta_data
    {level: self.as_json(only: [:id, :min_points, :max_points, :name, :value, :next_level_points])}
  end

  def icon_url
    URI.join(ENV['UPDOWN_DEFAULT_IMAGE_URL'], "level-icons/#{icon_name}").to_s
  end
end

