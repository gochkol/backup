class BodyArea < ActiveRecord::Base
  include GlobalCacheWatch

  watch_update also: [:exercise]
  has_many :body_areas_exercises
  has_many :exercises, through: :body_areas_exercises
  has_many :user_body_area_factors

  scope :top_level, -> { where(parent_id: 0).first }
  scope :active, -> { where(is_active: true) }

  def children
    BodyArea.where(parent_id: self.id)
  end

  def self.nested_list
    t = BodyArea.top_level
    a = [{name: t.name, id: t.id, children: []}]
    t.children.each do |ca|
      b = []
      ca.children.each do |cb|
        b.push({name: cb.name, id: cb.id})
      end
      a[0][:children].push({name: ca.name, id: ca.id, children: b})
    end
    a
  end

  def self.minor
    BodyArea.where.not(id: [1, 2, 3])
  end
end

