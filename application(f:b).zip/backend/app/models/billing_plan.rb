class BillingPlan < ActiveRecord::Base
  has_many :users
  scope :active, -> { where(is_active: true) }
  #status = [:active, :canceled, :expired, :past_due, :pending]
end
