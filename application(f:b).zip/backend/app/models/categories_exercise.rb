class CategoriesExercise < ActiveRecord::Base
  include GlobalCacheWatch

  watch_update also: [:exercise]
  belongs_to :exercises
  belongs_to :category
end
