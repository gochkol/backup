class Subscription < ActiveRecord::Base
  has_one :user
  belongs_to :billing_plan
end
