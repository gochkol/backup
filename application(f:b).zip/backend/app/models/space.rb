class Space < ActiveRecord::Base
  include GlobalCacheWatch

  watch_update also: [:exercise]
  has_many :locations
  scope :active, -> { where(is_active: true) }
end
