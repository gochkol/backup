class BodyStat < ActiveRecord::Base
  include UserCacheWatch

  belongs_to :user

  scope :current, -> { where(is_current: true) }

  DEFAULT_NAME_VALUES = [["Height", "height"],
                         ["Weight", "weight"],
                         ["BMI", "bmi"],
                         ["Body Fat %", "body_fat"],
                         ["Resting Heart Rate", "resting_heart_rate"]]

  def update_data(new_data)
    return if new_data == data
    update_attribute(:is_current, false)
    BodyStat.create(user: user, name: name, value: value, data: new_data, is_current: true)
  end

end

