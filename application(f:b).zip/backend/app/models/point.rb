class Point < ActiveRecord::Base
  include UserCacheWatch

  belongs_to :user

  # TODO V1 DEPRACATION PART 1
  # rename point_data to v1_point_data
  # rename v2_point_data to point_data
  # rename sentence to v1_sentence

  def as_json(options={})
    if options[:version] == 2
      json = super(only: [:id, :earned_at, :number_of, :point_type])
      json[:point_data] = self.v2_point_data
    else
      json = super(only: [:id, :earned_at, :number_of, :sentence])
    end
    json

    # TODO V1 DEPRACATION PART 2
    # delete above and uncomment below
    # super(only: [:id, :earned_at, :number_of, :point_type, :point_data])
  end

end
