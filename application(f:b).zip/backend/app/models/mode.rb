class Mode < ActiveRecord::Base
  include GlobalCacheWatch

  watch_update also: [:exercise]
  has_many :exercises
  scope :active, -> { where(is_active: true) }
end
