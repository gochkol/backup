class Message < ActiveRecord::Base
  include GlobalCacheWatch
end
