class Modifier < ActiveRecord::Base
  belongs_to :user
  validates_uniqueness_of  :user_id, {scope: [:modifier_type]}

  scope :set_type,  -> { where(modifier_type: "set").first }
  scope :rest_type, -> { where(modifier_type: "rest").first }

  def self.types
    ["set", "rest"]
  end
end
