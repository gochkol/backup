class Usage < ActiveRecord::Base
  include GlobalCacheWatch

  has_many :users
  scope :active, -> { where(is_active: true) }
  scope :default, -> { active.first }
end
