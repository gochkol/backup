class BodyPartStat < ActiveRecord::Base
  belongs_to :user
  belongs_to :body_part

  scope :current, -> { where(is_current: true) }

  def body_part_name
    body_part.name
  end

  def update_data(new_data)
    return if new_data == data
    update_attribute(:is_current, false)
    BodyPartStat.create(user: user, body_part: body_part,  data: new_data, is_current: true)
  end
end
