class FriendRequest < ActiveRecord::Base
  include UserCacheWatch

  belongs_to :user
  belongs_to :friend, class_name: 'User'

  validates :user, presence: true
  validates :friend, presence: true
  validate :not_duplicate

  before_destroy :update_friend_cache_time_t
  after_commit :update_friend_cache_time_t

  def not_duplicate
    if !user.friend_requests.where(friend_id: friend.id, status: "pending").empty?
      self.errors.add(:base, "Duplicate friend request")
    end
    if !user.friends.where(id: friend.id).empty?
     self.errors.add(:base, "Duplicate friend")
    end
  end

end
