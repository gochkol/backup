require 'resque/errors'
require 'resque-retry'

class PointUpdater
  #extend Resque::Plugins::Retry
  @queue = :point_updater

  attr_reader :point, :user

  def initialize(point_id)
    #@point = Point.find(point_id)
    #@user = point.user
    flush "Initialized PointUpdater worker instance"
  end

  def self.perform(key)
    (new key).update_points
  rescue Resque::TermException
    Resque.enqueue(self, key)
  end

  def update_points
    flush "updating points"
  end

  def flush(str)
    puts str
    $stdout.flush
  end
end

