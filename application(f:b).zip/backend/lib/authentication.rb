module Authentication

  def self.included(base)
    base.class_eval do
      helper_method :logged_in?, :current_user
      before_filter :login_required
    end
  end


protected

  def access_denied
    respond_to do |wants|
      wants.html {
        store_location
        redirect_to '/login'
      }
    end
  end

  def store_location
    session[:return_to] = request.fullpath
  end

  def redirect_back_or_default(default)
    session[:return_to] = nil
    redirect_to(session[:return_to] || default) and return
  end

  def log_out
    self.current_user = nil
  end

  def current_user=(user)
    session[:user_id] = user ? user.id : nil
    @current_user = user || false
  end

  def current_user
    @current_user ||= login_from_session
  end

  def login_from_session
    self.current_user = User.where(:id => session[:user_id]).first if session[:user_id]
  end

  def logged_in?
    !!current_user
  end

  def login_required
    logged_in? || access_denied
  end

end

