class AuthenticationTimeoutError < StandardError
end
