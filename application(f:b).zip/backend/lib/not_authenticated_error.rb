class NotAuthenticatedError < StandardError
end


