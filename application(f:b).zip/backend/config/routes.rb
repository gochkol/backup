Rails.application.routes.draw do
  root to: "sessions#new"
  mount RailsAdmin::Engine => '/admin', as: 'rails_admin'
  resources :sessions, only: [:new, :create, :destroy]
  get "login" => "sessions#new", as: :login
  delete "logout" => "sessions#destroy", as: :logout
  get "signin" => redirect("/login")
  delete "sign_out" => redirect("/logout")
  namespace :api, defaults: {format: :json}  do
    namespace :v1 do
      post  'auth'        => 'auth#authenticate'

      # global (cached)
      get   'body_areas'        => 'body_areas#index'
      get   'categories'        => 'categories#index'
      get   'equipments'        => 'equipments#index'
      get   'exercises'         => 'exercises#index'
      get   'messages'          => 'messages#index'
      get   'spaces'            => 'spaces#index'
      get   'usages'            => 'usages#index'
      get   'quick_activities'  => 'quick_activities#index'

      namespace :users do
        # user (cached)
        get     'events'                  => 'events#index'
        get     'points'                  => 'points#index'
        get     'body_stats'              => 'body_stats#index'
        patch   'body_stats'              => 'body_stats#update'
        get     'body_stats_stream'       => 'body_stats#stream'
        get     'body_part_stats'         => 'body_part_stats#index'
        patch   'body_part_stats'         => 'body_part_stats#update'
        get     'body_part_stats_stream'  => 'body_part_stats#stream'
        get     'company'                 => 'companies#show'
        post    'join_company'            => 'companies#join_company'
        delete  'leave_company'           => 'companies#leave_company'
        get     'favorites'               => 'favorites#index'
        post    'favorites'               => 'favorites#create'
        delete  'favorites'               => 'favorites#destroy'
        get     'friend_requests'         => 'friend_requests#index'
        get     'friends'                 => 'friendships#index'
        delete  'friends'                 => 'friendships#destroy'
        get     'friends_search'          => 'friendships#search'
        get     'friend'                  => 'friendships#show'
        post    'friend_requests'         => 'friend_requests#create'
        delete  'friend_requests'         => 'friend_requests#destroy'
        post    'friend_requests_accept'  => 'friend_requests#accept'
        delete  'friend_requests_decline' => 'friend_requests#decline'
        post    'event_comments'          => 'event_comments#create'
        get     'event_comments'          => 'event_comments#index'
        delete  'event_comments'          => 'event_comments#destroy'
        get     'history'                 => 'history#show'
        get     'locations'               => 'locations#index'
        patch   'locations'               => 'locations#update'
        post    'quick_logs'              => 'quick_logs#create'
      end
      # stats
      patch 'stats'                   => 'stats#update'
      get   'body_stats_stream'       => 'stats#body_stats_stream'
      get   'body_part_stats_stream'  => 'stats#body_part_stats_stream'


      # users
      post  'user'           => 'users#create'
      get   'user'           => 'users#show'
      patch 'user'           => 'users#update'

      # workout
      post  'quick_workout'     => 'workout#quick_create'
      post  'custom_workout'    => 'workout#custom_create'
      post  'favorite_workout'  => 'workout#favorite_create'
      patch 'workout'           => 'workout#update'
      get   'workout'           => 'workout#show'


      # resets
      post  'password'    => 'resets#create'
      patch 'password'    => 'resets#update'

      # blocks
      delete  'block'               => 'blocks#destroy'
      patch   'block'               => 'blocks#update'
      post    'swap'                => 'blocks#swap'
      post    'duplicate'           => 'blocks#duplicate'
      post    'random'              => 'blocks#random'
      post    'add_exercises'       => 'blocks#add_exercises'

      # exercises
      get   'exercise_search'   => 'exercises#search'

      get   'version' => 'version#check'
    end


    namespace :v2 do
      post  'auth'        => 'auth#authenticate'

      # global (cached)
      get   'body_areas'        => 'body_areas#index'
      get   'categories'        => 'categories#index'
      get   'equipments'        => 'equipments#index'
      get   'exercises'         => 'exercises#index'
      get   'messages'          => 'messages#index'
      get   'spaces'            => 'spaces#index'
      get   'usages'            => 'usages#index'
      get   'quick_activities'  => 'quick_activities#index'
      get   'levels'            => 'levels#index'
      get   'billing_plans'     => 'billing_plans#index'

      namespace :users do
        # user (cached)
        get     'events'                  => 'events#index'
        get     'points'                  => 'points#index'
        get     'body_stats'              => 'body_stats#index'
        patch   'body_stats'              => 'body_stats#update'
        get     'body_stats_stream'       => 'body_stats#stream'
        get     'body_part_stats'         => 'body_part_stats#index'
        patch   'body_part_stats'         => 'body_part_stats#update'
        get     'body_part_stats_stream'  => 'body_part_stats#stream'
        get     'company'                 => 'companies#show'
        post    'join_company'            => 'companies#join_company'
        delete  'leave_company'           => 'companies#leave_company'
        get     'favorites'               => 'favorites#index'
        post    'favorites'               => 'favorites#create'
        delete  'favorites'               => 'favorites#destroy'
        get     'friend_requests'         => 'friend_requests#index'
        get     'friends'                 => 'friendships#index'
        delete  'friends'                 => 'friendships#destroy'
        get     'friends_search'          => 'friendships#search'
        get     'friend'                  => 'friendships#show'
        post    'friend_requests'         => 'friend_requests#create'
        delete  'friend_requests'         => 'friend_requests#destroy'
        post    'friend_requests_accept'  => 'friend_requests#accept'
        delete  'friend_requests_decline' => 'friend_requests#decline'
        post    'event_comments'          => 'event_comments#create'
        get     'event_comments'          => 'event_comments#index'
        delete  'event_comments'          => 'event_comments#destroy'
        get     'history'                 => 'history#show'
        get     'locations'               => 'locations#index'
        patch   'locations'               => 'locations#update'
        post    'quick_logs'              => 'quick_logs#create'
        get     'payment_token'           => 'money#payment_token'
        post    'payment_transaction'     => 'money#payment_transaction'
        post    'payment_update'          => 'money#payment_update'
        get     'subscription'            => 'subscriptions#show'
        post    'cancel_subscription'     => 'money#cancel_subscription'
      end
      # stats
      patch 'stats'                   => 'stats#update'
      get   'body_stats_stream'       => 'stats#body_stats_stream'
      get   'body_part_stats_stream'  => 'stats#body_part_stats_stream'


      # users
      post  'user'           => 'users#create'
      get   'user'           => 'users#show'
      patch 'user'           => 'users#update'

      # workout
      post  'quick_workout'     => 'workout#quick_create'
      post  'custom_workout'    => 'workout#custom_create'
      post  'favorite_workout'  => 'workout#favorite_create'
      patch 'workout'           => 'workout#update'
      get   'workout'           => 'workout#show'


      # resets
      post  'password'    => 'resets#create'
      patch 'password'    => 'resets#update'

      # blocks
      delete  'block'               => 'blocks#destroy'
      patch   'block'               => 'blocks#update'
      post    'swap'                => 'blocks#swap'
      post    'duplicate'           => 'blocks#duplicate'
      post    'random'              => 'blocks#random'
      post    'add_exercises'       => 'blocks#add_exercises'

      # exercises
      get   'exercise_search'   => 'exercises#search'
      get   'version' => 'version#check'
    end
  end
end
