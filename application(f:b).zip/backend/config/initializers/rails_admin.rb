RailsAdmin.config do |config|

  config.authorize_with do
    unless current_user && current_user.admin?
      redirect_to(
        main_app.root_path,
        alert: "You are not permitted to view this page"
      )
    end
  end

  config.current_user_method { current_user }
  config.model Exercise do
    list do
      field :id
      field :name
      field :animation_sequence
      field :equipments
      field :categories
      field :mode
      field :experience
      field :alt_name
      field :link
      field :alternation
      field :space
      field :updated_at
      field :base
      field :inc
      field :rate
      field :popularity
      field :technique
      field :primary_body_area
      field :met
      field :base_weight
      field :body_areas
      field :muscles
      items_per_page 40
    end
  end

  config.actions do
    dashboard                     
    index                         
    new
    export
    bulk_delete
    show
    edit
    delete
    show_in_app

    #config.included_models = [
  end
end
