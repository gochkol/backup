class WorkoutUpdateService

  attr_accessor :user, :workout, :params, :intensity

  def initialize(user, params)
    @user = user
    @params = params
    @workout = Workout.find(params[:id])
    @intensity = user.intensity - 1
    @finished = params[:finished] ||= false
    @touched_ba = {}
  end

  def update
    old_block_ids = workout.block_ids
    new_block_ids = []
    params[:blocks].each do |block|
      new_block_ids.push block[:id]
      b = Block.find(block[:id])
      b.update_attributes(block_data: {block_sets: block["block_sets"]}, rank: block[:rank])
      first_set = true
      block[:block_sets].each do |block_set|
        e = Exercise.find(block_set[:exercise_id])
        h1 = block_set[:criterion]
        if @finished
          update_body_area_factors(e, h1, first_set)
        end
        first_set = false
      end
    end
    Block.find(old_block_ids - new_block_ids).each(&:destroy)
    if @finished
      params[:calories_burned] ||= 0
      workout.update_attribute(:calories_burned, params[:calories_burned])
      params[:workout_total_time] ||= 0
      workout.update_attribute(:workout_total_time_seconds, params[:workout_total_time])
      workout.update_attribute(:finished_at, DateTime.now)
      ps = PointsService.new(user)
      ps.finish_workout(workout)
      es = EventService.new(user)
      es.finish_workout(workout)
    end
  end

  def say(s, v)
    puts (s + v.to_s)
  end

  def list_events(workout)
#create two arrays for each body area worked of the format
#array of events= [[reps, weight, duration],[reps, weight, duration],[reps, weight, duration],...,[reps, weight, duration]]
#array of rests = [time, time, time,..., time]
  end

  def fatigue_generate
#based on curves determine how much fatigue was generated from each set and set it to an array
#move from last set back to first set to determine fatigue levels between sets
  end

  def recovery_generate
#based on curves determine how much fatigue was recovered from each rest and set it to an array
#move from last set backe to first set to determine fatigue levels between sets
  end

  def calc_w_at_r(w1, r1, w2, r2, r)
    x = Math.sqrt(((Math.log(r)*((w2**2) - (w1**2))) - (Math.log(r1)*(w2**2)) + (Math.log(r2)*(w1**2)))/(Math.log(r2/r1)))
    x
  end

  def calc_r_at_w(w1, r1, w2, r2, w)
    y = (r1**(((w2**2) - (w**2))/((w2**2) - (w1**1))))*(r2**(((w**2) - (w1**2))/((w2**2) - (w1**2))))
    y
  end

  def inflection_r(emw, emr, inf_w)
    inf_r = calc_r_at_w(0.0, emr, emw, 1.0, inf_w)
    inf_r
  end

  def inflection_w(emw, emr)
    inf_w = Math.sqrt((emw**2)/(2*Math.log(emr)))
    inf_w
  end

  def inflection_line_slope(emw, emr, inf_w)
    slope = Math.log(emr) * ((-2.0 * inf_w)/(emw**2)) * (calc_r_at_w(0.0, emr, emw, 1.0, inf_w))
    slope
  end

  def inflection_line_get_r(emw, emr, inf_w, inf_r, w)
    # y = m*x + b given (x1, y1) is a point on line
    # y1 = m*x1 + b
    # b = y1 - m*x1
    # y = m*x + y1 - m*x1 by substitution
    m = inflection_line_slope(emr, emw, inf_w)
    #y = m*x
    i_l_r_at_w = m * w
    #y = m*x + y1
    i_l_r_at_w += inf_r
    #y = m*x + y1 - m*x1
    i_l_r_at_w -= m * inf_w

    i_l_r_at_w
  end

  def zone_find(emw, emr, w, r)
    zone = nil

    inf_w = inflection_w(emw, emr)
    inf_r = inflection_r(emw, emr, inf_w)
    i_l_r = inflection_line_get_r(emw, emr, inf_w, inf_r, w)

    if r >= inf_r
      if w >= inf_w
        #region u
        zone = 'u'
      else
        #region r
        zone = 'r'
      end
    else
      if w >= inf_w
        zone = 'w'
      else
        #region d
        zone = 'd'
      end
    end
puts zone
    zone
  end

  def above(emw, emr, w, r)
    a = nil
    if calc_r_at_w(0, emr, emw, 1, w) <= r
      a = true
    else
      a = false
    end
    a
  end

  def in_range_above(emw, emr, w, r, i_w, i_r)
    inside = nil
    inside_w_range = nil
    inside_r_range = (r >= calc_r_at_w(0.0, emr, emw, 1.0, w)) && (r <= (i_r + calc_r_at_w(0.0, emr, emw, 1.0, w)))

    if (r <= emr) && (w >= i_w)
      inside_w_range = (w >= calc_w_at_r(0.0, emr, emw, 1.0, r)) && (w <= (i_w + calc_w_at_r(0.0, emr, emw, 1.0, r)))
      if inside_r_range || inside_w_range
        inside = true
      else
        inside = false
      end
    else
      if inside_r_range
        inside = true
      else
        inside = false
      end
    end
  end

  def in_range_below(emw, emr, w, r, i_w, i_r)
    inside = nil
    inside_w_range = nil
    inside_r_range = (r <= calc_r_at_w(0.0, emr, emw, 1.0, w)) && (r >= ((-1.0*i_r) + calc_r_at_w(0.0, emr, emw, 1.0, w)))

    if (r <= emr) && (w >= i_w)
      inside_w_range = (w <= calc_w_at_r(0.0, emr, emw, 1.0, r)) && (w >= (-1.0*i_w + calc_w_at_r(0.0, emr, emw, 1.0, r)))
      if inside_r_range || inside_w_range
        inside = true
      else
        inside = false
      end
    else
      if inside_r_range
        inside = true
      else
        inside = false
      end
    end
  end

  def update_body_area_factors(e, h, first)
    usage = user.usage.value
    mode = e.mode.value
    baf = user.factors_for_body_area_id(e.primary_body_area.id)
    @touched_ba[e.primary_body_area.id] ||= 0
    @touched_ba[e.primary_body_area.id] += 1
    ba_cnt = @touched_ba[e.primary_body_area.id]
    mr = baf.mr
    mw = baf.mw
    t = e.technique
    i = @intensity.to_i
    emw = mw * t * (0.75 + (0.025 * i))
    emr = mr * t * (0.75 + (0.025 * i))

    if (mode.include?("repetition") || mode.include?("pattern") || mode.include?("breath"))
      reps = nil
      weight = nil

      if mode.include?("repetition")
#set weight and reps values
        if mode.include?("weight")
          #given reps and weight
          weight = h["weight"]
        else
          #given just reps
          weight = 0;
        end
        reps = h["reps"]

        shift_emw = 1.0
        shift_emr = 1.0
        shift_inc = 0.001
#check for values in range or cancel shift
        if (reps <= 0.0) || (weight < 0.0)

          mw = mw
          mr = mr
#begin shift
        else
          #check if this is the first time you are editing a body area
          if (ba_cnt === 1)
            #small incriment up if in range
            if in_range_above(emw, emr, weight, reps, 5.0, 1.0) || in_range_below(emw, emr, weight, reps, 5.0, 1.0)
              zone = zone_find(emw, emr, weight, reps)

              case zone
                when 'u'
                  #scale both emw and emr evenly up
                  shift_emw += 10*shift_inc * t * (0.75 + (0.025 * i))
                  shift_emr += 10*shift_inc * t * (0.75 + (0.025 * i))
                when 'd'
                  #scale both emw and emr evenly down
                  shift_emw += 10*shift_inc * t * (0.75 + (0.025 * i))
                  shift_emr += 10*shift_inc * t * (0.75 + (0.025 * i))
                when 'w'
                  #scale only emw
                  shift_emw += 10*shift_inc * t * (0.75 + (0.025 * i))
                when 'r'
                  #scale only emr
                  shift_emr += 10*shift_inc * t * (0.75 + (0.025 * i))
              end
            #shift function if out of range
            else
              while !(in_range_above(emw*shift_emw, emr*shift_emr, weight, reps, 5.0, 1.0) || in_range_below(emw*shift_emw, emr*shift_emr, weight, reps, 5.0, 1.0))

                zone = zone_find(emw*shift_emw, emr*shift_emr, weight, reps)

                case zone
                  when 'u'
                    #scale both emw and emr evenly up
                    shift_emw += shift_inc
                    shift_emr += shift_inc
                  when 'd'
                    #scale both emw and emr evenly down
                    shift_emw -= shift_inc
                    shift_emr -= shift_inc
                  when 'w'
                    #scale only emw
                    if above(emw, emr, weight, reps)
                      shift_emw += shift_inc
                    else
                      shift_emw -= shift_inc
                    end
                  when 'r'
                    #scale only emr
                    if above(emw, emr, weight, reps)
                      shift_emr += shift_inc
                    else
                      shift_emr -= shift_inc
                    end
                end
              end
            end
          #if this is not the first time editing a body area but it is the first set in a block
          elsif first
            #small incriment up if in range
            if in_range_above(emw, emr, weight, reps, 5.0, 1.0) || in_range_below(emw, emr, weight, reps, 5.0, 1.0)
              zone = zone_find(emw, emr, weight, reps)

              case zone
                when 'u'
                  #scale both emw and emr evenly up
                  shift_emw += (10*shift_inc * t * (0.75 + (0.025 * i)))/ba_cnt
                  shift_emr += (10*shift_inc * t * (0.75 + (0.025 * i)))/ba_cnt
                when 'd'
                  #scale both emw and emr evenly down
                  shift_emw += (10*shift_inc * t * (0.75 + (0.025 * i)))/ba_cnt
                  shift_emr += (10*shift_inc * t * (0.75 + (0.025 * i)))/ba_cnt
                when 'w'
                  #scale only emw
                  shift_emw += (10*shift_inc * t * (0.75 + (0.025 * i)))/ba_cnt
                when 'r'
                  #scale only emr
                  shift_emr += (10*shift_inc * t * (0.75 + (0.025 * i)))/ba_cnt
              end
            #shift function if out of range
            else
              while !(in_range_above(emw*shift_emw, emr*shift_emr, weight, reps, 5.0, 1.0) || in_range_below(emw*shift_emw, emr*shift_emr, weight, reps, 5.0, 1.0))

                zone = zone_find(emw*shift_emw, emr*shift_emr, weight, reps)

                case zone
                  when 'u'
                    #scale both emw and emr evenly up
                    shift_emw += shift_inc
                    shift_emr += shift_inc
                  when 'd'
                    #scale both emw and emr evenly down
                    shift_emw -= shift_inc
                    shift_emr -= shift_inc
                  when 'w'
                    #scale only emw
                    if above(emw, emr, weight, reps)
                      shift_emw += shift_inc
                    else
                      shift_emw -= shift_inc
                    end
                  when 'r'
                    #scale only emr
                    if above(emw, emr, weight, reps)
                      shift_emr += shift_inc
                    else
                      shift_emr -= shift_inc
                    end
                end
              end
            end
          #if this is not the first time editing a body area and not the first set in a block
          else
            zone = zone_find(emw, emr, weight, reps)

            case zone
              when 'u'
                #scale both emw and emr evenly up
                if (calc_w_at_r(0.0, emr, emw, 1.0, reps)/5).floor*5 > 0
                  shift_emw += (10*shift_inc * t * (0.75 + (0.025 * i))*(weight/((calc_w_at_r(0.0, emr, emw, 1.0, reps)/5).floor*5)))/ba_cnt
                else
                  shift_emw += (10*shift_inc * t * (0.75 + (0.025 * i)))/ba_cnt
                end
                if (calc_r_at_w(0.0, emr, emw, 1.0, reps).floor) > 0
                  shift_emr += (10*shift_inc * t * (0.75 + (0.025 * i))*(reps/(calc_r_at_w(0.0, emr, emw, 1.0, reps).floor)))/ba_cnt
                else
                  shift_emr += (10*shift_inc * t * (0.75 + (0.025 * i)))/ba_cnt
                end
              when 'd'
                #scale both emw and emr evenly down
                if (calc_w_at_r(0.0, emr, emw, 1.0, reps)/5).floor*5 > 0
                  shift_emw += (10*shift_inc * t * (0.75 + (0.025 * i))*(weight/((calc_w_at_r(0.0, emr, emw, 1.0, reps)/5).floor*5)))/ba_cnt
                else
                  shift_emw += (10*shift_inc * t * (0.75 + (0.025 * i)))/ba_cnt
                end
                if (calc_r_at_w(0.0, emr, emw, 1.0, reps).floor) > 0
                  shift_emr += (10*shift_inc * t * (0.75 + (0.025 * i)) *(reps/(calc_r_at_w(0.0, emr, emw, 1.0, reps).floor)))/ba_cnt
                else
                  shift_emr += (10*shift_inc * t * (0.75 + (0.025 * i)))/ba_cnt
                end
              when 'w'
                #scale only emw
                shift_emw += (10*shift_inc * t * (0.75 + (0.025 * i))*(weight/((calc_w_at_r(0.0, emr, emw, 1.0, reps)/5).floor*5)))/ba_cnt
              when 'r'
                #scale only emr
                if (calc_r_at_w(0.0, emr, emw, 1.0, reps).floor) > 0
                  shift_emr += (10*shift_inc * t * (0.75 + (0.025 * i))*(reps/(calc_r_at_w(0.0, emr, emw, 1.0, reps).floor)))/ba_cnt
                else
                  shift_emr += (10*shift_inc * t * (0.75 + (0.025 * i)))/ba_cnt
                end
            end
          end
        end
#end shift
        emw *= shift_emw
        emr *= shift_emr
        #Set new Mr and Mw values
        mw = emw / (t * (0.75 + (0.025 * i)))
        mr = emr / (t * (0.75 + (0.025 * i)))
      end
    end
    UserBodyAreaFactor.create(user: user, body_area: e.primary_body_area, mr: mr, mw: mw)
  end
end
