class WorkoutUpdateServiceOld

  attr_accessor :user, :workout, :params, :intensity

  def initialize(user, params)
    @user = user
    @params = params
    @workout = Workout.find(params[:id])
    @intensity = workout.request_params["intensity"]
    @finished = params[:finished] ||= false
  end

  def update
    params[:blocks].each do |block|
      block[:block_sets].each do |block_set|
        bsvs = workout.block_set_value_sets.where(block_set_id: block_set[:id]).first
        h1 = block_set[:exercise][:criterion]
        vs = ValueSet.create(values: h1, block_set_value_set: bsvs)
        bsvs.value_set = vs
        bsvs.save
        if @finished
          update_body_area_factors(bsvs.block_set.exercise, h1)
        end
      end
    end
#    if @finished
#      ps = PointsService.new(@current_user, workout)
#      ps.finish_workout
#    end
  end

  def calc_Mw(r1, w1, r2, w2, y)
    x = Math.sqrt(((Math.log(y)*((w2**2) - (w1**2))) - (Math.log(r1)*(w2**2)) + (Math.log(r2)*(w1**2)))/(Math.log(r2/r1)))
    x
  end

  def calc_Mr(r1, w1, r2, w2, x)
    y = (r1**(((w2**2) - (x**2))/((w2**2) - (w1**1))))*(r2**(((x**2) - (w1**2))/((w2**2) - (w1**2))))
    y
  end

  def inflection_r(emw, emr, inf_w)
    inf_r = emr**(((emw**2)-(inf_w**2))/(emw**2))
    inf_r
  end

  def inflection_w(emw, emr)
    inf_w = Math.sqrt((emw**2)/(2*Math.log(emr)))
    inf_w
  end

  def update_body_area_factors(e, h)
    usage = user.usage.value
    mode = e.mode.value
    baf = user.factors_for_body_area_id(e.primary_body_area.id)
    mr = baf.mr
    mw = baf.mw
    t = e.technique
    i = @intensity.to_i
puts "Mr: #{mr}"
puts "Mw: #{mw}"
puts "Tech: #{t}"
puts "Intense: #{i}"


    if (mode.include?("repetition") || mode.include?("pattern") || mode.include?("breath"))
      reps = nil
      weight = nil

      if mode.include?("repetition")
        #set weight and reps values
        if mode.include?("weight")
          #given reps and weight
          weight = h["weight"]
        else
          #given just reps
          weight = 0;
        end
        reps = h["reps"]
        
puts "Weight: #{weight}"
puts "Reps: #{reps}"

        #calculate Mr and Mw for the exercise
        emr = mr * t * (0.75 + (i * 0.025)) 
        emw = mw * t * (0.75 + (i * 0.025))
puts "ExMr: #{emr}"
puts "ExMw: #{emw}"


        #calculate boundry values
        lbmr = 0.9 * emr
        ubmr = 1.1 * emr
        lbmw = 0.9 * emw
        ubmw = 1.1 * emw
        #if new criteria out of bounds rescale function
        if (reps >= (ubmr**(((ubmw**2)-(weight**2))/(ubmw**2)))) || (reps <= (lbmr**(((lbmw**2)-(weight**2))/(lbmw**2))))
          shift_inc = 0.1
          total_shift = 1.0

          while shift_inc > 0.0008 do
puts "\n"
puts "Shift Inc: #{shift_inc}"
puts "Total Shift: #{total_shift}"
            #calc y
            shift_mr = emr * total_shift
            shift_mw = emw * total_shift
puts "ShiftMr: #{emr}"
puts "ShiftMw: #{emw}"
            y = (shift_mr**(((shift_mw**2)-(weight**2))/(shift_mw**2)))
puts "Reps: #{reps}"
puts "Y(reps): #{y}"
            if reps > y
              while reps > y do
                total_shift += shift_inc
puts "\n"
puts "Total Shift: #{total_shift}"
                #calc y
                shift_mr = emr * total_shift
                shift_mw = emw * total_shift
puts "ShiftMr: #{emr}"
puts "ShiftMw: #{emw}"
                y = (shift_mr**(((shift_mw**2)-(weight**2))/(shift_mw**2)))
puts "Reps: #{reps}"
puts "Y(reps): #{y}"
              end
            elsif reps < y
              while reps < y do
                total_shift -= shift_inc
puts "\n"
puts "Total Shift: #{total_shift}"
                #calc y
                shift_mr = emr * total_shift
                shift_mw = emw * total_shift
puts "ShiftMr: #{emr}"
puts "ShiftMw: #{emw}"
                y = (shift_mr**(((shift_mw**2)-(weight**2))/(shift_mw**2)))
puts "Reps: #{reps}"
puts "Y(reps): #{y}"
              end
            end
            shift_inc *= 0.5
          end
          
puts "Old Mr: #{mr}"
puts "Old Mw: #{mw}"
          mr = (emr * total_shift)/(t * (0.75 + (i * 0.025))) 
          mw = (emw * total_shift)/(t * (0.75 + (i * 0.025)))
puts "New Mr: #{mr}"
puts "New Mw: #{mw}"
        #if new criteria in bounds adjust function
        else
          #calculate inflection point
puts "Weight: #{weight}"
puts "Reps: #{reps}"
        
          inf_w = Math.sqrt((emw**2)/(2*Math.log(emr)))
          inf_r = emr**(((emw**2)-(inf_w**2))/(emw**2))
puts "Inflection Point Weight: #{inf_w}"
puts "Inflection Point Reps: #{inf_r}"

          inf_upper_w = inf_w +5.0
          inf_upper_r = inf_r +1.0
          emr_upper = emr +1.0
          emw_upper = emw +5.0
          upper_r = reps+1.0
          upper_w = weight+5.0
          mw_vals = Array.new
          mr_vals = Array.new

          inf_r_bound_up = inf_r + 2
          inf_r_bound_down = inf_r - 2
          inf_w_bound_up = inf_w + 10
          inf_w_bound_down = inf_w - 10
          rirbu = reps <= inf_r_bound_up
          wiwbu = weight <= inf_w_bound_up
          rirbd = reps >= inf_r_bound_down
          wiwbd = weight >= inf_w_bound_down
          a = rirbu && wiwbu
          b = rirbd && wiwbd
          c = !rirbd && !wiwbu
          d = !rirbu && !wiwbd
puts a
puts b
puts c
puts d
          if a || b
          #near inflection point
            mw_vals.push(emw)
puts "Weight: #{emw}"
puts "Reps: #{reps}"
puts "EMR: #{emr}"
puts "EMW: #{emw}"
puts "MW_VALS BASE: #{emw}"
            mw_vals.push(Math.sqrt((-1*(((weight)**2)*(Math.log(emr))))/(Math.log(reps/emr))))
puts "MW_VALS #1: #{mw_vals[1]}"
            mw_vals.push(Math.sqrt((-1*(((weight)**2)*(Math.log(emr))))/(Math.log(upper_r/emr))))
puts "MW_VALS #2: #{mw_vals[2]}"
            mw_vals.push(Math.sqrt((-1*(((upper_w)**2)*(Math.log(emr))))/(Math.log(reps/emr))))
puts "MW_VALS #3: #{mw_vals[3]}"
            mw_vals.push(Math.sqrt((-1*(((upper_w)**2)*(Math.log(emr))))/(Math.log(upper_r/emr))))
puts "MW_VALS #4: #{mw_vals[4]}"

            mw_vals.push(Math.sqrt((-1*(((weight)**2)*(Math.log(emr_upper))))/(Math.log(reps/emr_upper))))
puts "MW_VALS #5: #{mw_vals[5]}"
            mw_vals.push(Math.sqrt((-1*(((weight)**2)*(Math.log(emr_upper))))/(Math.log(upper_r/emr_upper))))
puts "MW_VALS #6: #{mw_vals[6]}"
            mw_vals.push(Math.sqrt((-1*(((upper_w)**2)*(Math.log(emr_upper))))/(Math.log(reps/emr_upper))))
puts "MW_VALS #7: #{mw_vals[7]}"
            mw_vals.push(Math.sqrt((-1*(((upper_w)**2)*(Math.log(emr_upper))))/(Math.log(upper_r/emr_upper))))
puts "MW_VALS #8: #{mw_vals[8]}"

            mr_vals.push(emr)
puts "MR_VALS BASE: #{emr}"
            mr_vals.push((reps)**(((emw)**2)/(((emw)**2) - ((weight)**2))))
puts "MR_VALS #1: #{mr_vals[1]}"
#            mr_vals.push((upper_r)**(((emw)**2)/(((emw)**2) - ((weight)**2))))  
#puts "MR_VALS #2: #{mr_vals[2]}"
#            mr_vals.push((reps)**(((emw)**2)/(((emw)**2) - ((upper_w)**2))))  
#puts "MR_VALS #3: #{mr_vals[3]}"
#            mr_vals.push((upper_r)**(((emw)**2)/(((emw)**2) - ((upper_w)**2))))  
#puts "MR_VALS #4: #{mr_vals[4]}"

#            mr_vals.push((reps)**(((emw_upper)**2)/(((emw_upper)**2) - ((weight)**2))))
#puts "MR_VALS #5: #{mr_vals[5]}"
#            mr_vals.push((upper_r)**(((emw_upper)**2)/(((emw_upper)**2) - ((weight)**2))))  
#puts "MR_VALS #6: #{mr_vals[6]}"
#            mr_vals.push((reps)**(((emw_upper)**2)/(((emw_upper)**2) - ((upper_w)**2))))  
#puts "MR_VALS #7: #{mr_vals[7]}"
            mr_vals.push((upper_r)**(((emw_upper)**2)/(((emw_upper)**2) - ((upper_w)**2))))
puts "MR_VALS #8: #{mr_vals[8]}"
    
          elsif c
          #near mw
            #calc mw using mr
puts "Calc Mw using Mr"
            mw_vals.push(emw)
puts "Mw Base: #{mw_vals[0]}"

#            mw_vals.push(Math.sqrt((-1*(((weight)**2)*(Math.log(emr))))/(Math.log(reps/emr))))
#puts "  Mw 01: #{mw_vals[1]}"
            mw_vals.push(Math.sqrt((-1*(((weight)**2)*(Math.log(emr))))/(Math.log(upper_r/emr))))
puts "  Mw 02: #{mw_vals[1]}"
            mw_vals.push(Math.sqrt((-1*(((upper_w)**2)*(Math.log(emr))))/(Math.log(reps/emr))))
puts "  Mw 03: #{mw_vals[2]}"
            mw_vals.push(Math.sqrt((-1*(((upper_w)**2)*(Math.log(emr))))/(Math.log(upper_r/emr))))
puts "  Mw 04: #{mw_vals[3]}"

#            mw_vals.push(Math.sqrt((-1*(((weight)**2)*(Math.log(emr_upper))))/(Math.log(reps/emr_upper))))
#puts "  Mw 05: #{mw_vals[5]}"
            mw_vals.push(Math.sqrt((-1*(((weight)**2)*(Math.log(emr_upper))))/(Math.log(upper_r/emr_upper))))
puts "  Mw 06: #{mw_vals[4]}"
            mw_vals.push(Math.sqrt((-1*(((upper_w)**2)*(Math.log(emr_upper))))/(Math.log(reps/emr_upper))))
puts "  Mw 07: #{mw_vals[5]}"            
            mw_vals.push(Math.sqrt((-1*(((upper_w)**2)*(Math.log(emr_upper))))/(Math.log(upper_r/emr_upper))))
puts "  Mw 08: #{mw_vals[6]}"

            #calc mw using I
puts "Calc Mw using I:"

#puts "01  IRL: #{inf_r}\n    IWL: #{inf_w}\n    RL: #{reps}\n    WL: #{weight}"
#puts "      #{Math.sqrt(((((inf_w)**2)*(Math.log(reps)))-(((weight)**2)*(Math.log(inf_r))))/(Math.log(reps/inf_r)))}"
#            mw_vals.push(Math.sqrt(((((inf_w)**2)*(Math.log(reps)))-(((weight)**2)*(Math.log(inf_r))))/(Math.log(reps/inf_r))))

puts "02  IRL: #{inf_r}\n    IWL: #{inf_w}\n    RL: #{reps}\n    WU: #{upper_w}"
puts "      #{Math.sqrt(((((inf_w)**2)*(Math.log(reps)))-(((upper_w)**2)*(Math.log(inf_r))))/(Math.log(reps/inf_r)))}"
            mw_vals.push(Math.sqrt(((((inf_w)**2)*(Math.log(reps)))-(((upper_w)**2)*(Math.log(inf_r))))/(Math.log(reps/inf_r))))

puts "03  IRL: #{inf_r}\n    IWL: #{inf_w}\n    RU: #{upper_r}\n    WL: #{weight}"
puts "      #{Math.sqrt(((((inf_w)**2)*(Math.log(upper_r)))-(((weight)**2)*(Math.log(inf_r))))/(Math.log(upper_r/inf_r)))}"
            mw_vals.push(Math.sqrt(((((inf_w)**2)*(Math.log(upper_r)))-(((weight)**2)*(Math.log(inf_r))))/(Math.log(upper_r/inf_r))))

#puts "04  IRL: #{inf_r}\n    IWL: #{inf_w}\n    RU: #{upper_r}\n    WU: #{upper_w}"
#puts "      #{Math.sqrt(((((inf_w)**2)*(Math.log(upper_r)))-(((upper_w)**2)*(Math.log(inf_r))))/(Math.log(upper_r/inf_r)))}"
#            mw_vals.push(Math.sqrt(((((inf_w)**2)*(Math.log(upper_r)))-(((upper_w)**2)*(Math.log(inf_r))))/(Math.log(upper_r/inf_r))))

#puts "05  IRL: #{inf_r}\n    IWU: #{inf_upper_w}\n    RL: #{reps}\n    WL: #{weight}"
#puts "      #{Math.sqrt(((((inf_upper_w)**2)*(Math.log(reps)))-(((weight)**2)*(Math.log(inf_r))))/(Math.log(reps/inf_r)))}"
#            mw_vals.push(Math.sqrt(((((inf_upper_w)**2)*(Math.log(reps)))-(((weight)**2)*(Math.log(inf_r))))/(Math.log(reps/inf_r))))

puts "06  IRL: #{inf_r}\n    IWU: #{inf_upper_w}\n    RL: #{reps}\n    WU: #{upper_w}"
puts "      #{Math.sqrt(((((inf_upper_w)**2)*(Math.log(reps)))-(((upper_w)**2)*(Math.log(inf_r))))/(Math.log(reps/inf_r)))}"
            mw_vals.push(Math.sqrt(((((inf_upper_w)**2)*(Math.log(reps)))-(((upper_w)**2)*(Math.log(inf_r))))/(Math.log(reps/inf_r))))

puts "07  IRL: #{inf_r}\n    IWU: #{inf_upper_w}\n    RU: #{upper_r}\n    WL: #{weight}"
puts "      #{Math.sqrt(((((inf_upper_w)**2)*(Math.log(upper_r)))-(((weight)**2)*(Math.log(inf_r))))/(Math.log(upper_r/inf_r)))}"
            mw_vals.push(Math.sqrt(((((inf_upper_w)**2)*(Math.log(upper_r)))-(((weight)**2)*(Math.log(inf_r))))/(Math.log(upper_r/inf_r))))

#puts "08  IRL: #{inf_r}\n    IWU: #{inf_upper_w}\n    RU: #{upper_r}\n    WU: #{upper_w}"
#puts "      #{Math.sqrt(((((inf_upper_w)**2)*(Math.log(upper_r)))-(((upper_w)**2)*(Math.log(inf_r))))/(Math.log(upper_r/inf_r)))}"
#            mw_vals.push(Math.sqrt(((((inf_upper_w)**2)*(Math.log(upper_r)))-(((upper_w)**2)*(Math.log(inf_r))))/(Math.log(upper_r/inf_r))))

#puts "09  IRU: #{inf_upper_r}\n    IWL: #{inf_w}\n    RL: #{reps}\n    WL: #{weight}"
#puts "      #{Math.sqrt(((((inf_w)**2)*(Math.log(reps)))-(((weight)**2)*(Math.log(inf_upper_r))))/(Math.log(reps/inf_upper_r)))}"
#            mw_vals.push(Math.sqrt(((((inf_w)**2)*(Math.log(reps)))-(((weight)**2)*(Math.log(inf_upper_r))))/(Math.log(reps/inf_upper_r))))

puts "10  IRU: #{inf_upper_r}\n    IWL: #{inf_w}\n    RL: #{reps}\n    WU: #{upper_w}"
puts "      #{Math.sqrt(((((inf_w)**2)*(Math.log(reps)))-(((upper_w)**2)*(Math.log(inf_upper_r))))/(Math.log(reps/inf_upper_r)))}"
            mw_vals.push(Math.sqrt(((((inf_w)**2)*(Math.log(reps)))-(((upper_w)**2)*(Math.log(inf_upper_r))))/(Math.log(reps/inf_upper_r))))

puts "11  IRU: #{inf_upper_r}\n    IWL: #{inf_w}\n    RU: #{upper_r}\n    WL: #{weight}"
puts "      #{Math.sqrt(((((inf_w)**2)*(Math.log(upper_r)))-(((weight)**2)*(Math.log(inf_upper_r))))/(Math.log(upper_r/inf_upper_r)))}"
            mw_vals.push(Math.sqrt(((((inf_w)**2)*(Math.log(upper_r)))-(((weight)**2)*(Math.log(inf_upper_r))))/(Math.log(upper_r/inf_upper_r))))

#puts "12  IRU: #{inf_upper_r}\n    IWL: #{inf_w}\n    RU: #{upper_r}\n    WU: #{upper_w}"
#puts "      #{Math.sqrt(((((inf_w)**2)*(Math.log(upper_r)))-(((upper_w)**2)*(Math.log(inf_upper_r))))/(Math.log(upper_r/inf_upper_r)))}"
#            mw_vals.push(Math.sqrt(((((inf_w)**2)*(Math.log(upper_r)))-(((upper_w)**2)*(Math.log(inf_upper_r))))/(Math.log(upper_r/inf_upper_r))))

#puts "13  IRU: #{inf_upper_r}\n    IWU: #{inf_upper_w}\n    RL: #{reps}\n    WL: #{weight}"
#puts "      #{Math.sqrt(((((inf_upper_w)**2)*(Math.log(reps)))-(((weight)**2)*(Math.log(inf_upper_r))))/(Math.log(reps/inf_upper_r)))}"
#            mw_vals.push(Math.sqrt(((((inf_upper_w)**2)*(Math.log(reps)))-(((weight)**2)*(Math.log(inf_upper_r))))/(Math.log(reps/inf_upper_r))))

puts "14  IRU: #{inf_upper_r}\n    IWU: #{inf_upper_w}\n    RL: #{reps}\n    WU: #{upper_w}"
puts "      #{Math.sqrt(((((inf_upper_w)**2)*(Math.log(reps)))-(((upper_w)**2)*(Math.log(inf_upper_r))))/(Math.log(reps/inf_upper_r)))}"
            mw_vals.push(Math.sqrt(((((inf_upper_w)**2)*(Math.log(reps)))-(((upper_w)**2)*(Math.log(inf_upper_r))))/(Math.log(reps/inf_upper_r))))

puts "15  IRU: #{inf_upper_r}\n    IWU: #{inf_upper_w}\n    RU: #{upper_r}\n    WL: #{weight}"
puts "      #{Math.sqrt(((((inf_upper_w)**2)*(Math.log(upper_r)))-(((weight)**2)*(Math.log(inf_upper_r))))/(Math.log(upper_r/inf_upper_r)))}"
            mw_vals.push(Math.sqrt(((((inf_upper_w)**2)*(Math.log(upper_r)))-(((weight)**2)*(Math.log(inf_upper_r))))/(Math.log(upper_r/inf_upper_r))))

#puts "16  IRU: #{inf_upper_r}\n    IWU: #{inf_upper_w}\n    RU: #{upper_r}\n    WU: #{upper_w}"
#puts "      #{Math.sqrt(((((inf_upper_w)**2)*(Math.log(upper_r)))-(((upper_w)**2)*(Math.log(inf_upper_r))))/(Math.log(upper_r/inf_upper_r)))}"
#            mw_vals.push(Math.sqrt(((((inf_upper_w)**2)*(Math.log(upper_r)))-(((upper_w)**2)*(Math.log(inf_upper_r))))/(Math.log(upper_r/inf_upper_r))))


            #calc mr using I
            mr_vals.push(emr)
puts "Mr Base: #{emr}"
puts "Calc Mr using I:"

puts "01  IRL: #{inf_r}\n    IWL: #{inf_w}\n    RL: #{reps}\n    WL: #{weight}"
puts "      #{((inf_r)**(((weight)**2)/(((weight)**2) - ((inf_w)**2)))) * ((reps)**((-1*((inf_w)**2))/(((weight)**2) - ((inf_w)**2))))}"
            mr_vals.push(((inf_r)**(((weight)**2)/(((weight)**2) - ((inf_w)**2)))) * ((reps)**((-1*((inf_w)**2))/(((weight)**2) - ((inf_w)**2)))))

puts "02  IRL: #{inf_r}\n    IWL: #{inf_w}\n    RL: #{reps}\n    WU: #{upper_w}"
puts "      #{((inf_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_w)**2)))) * ((reps)**((-1*((inf_w)**2))/(((upper_w)**2) - ((inf_w)**2))))}"
            mr_vals.push(((inf_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_w)**2)))) * ((reps)**((-1*((inf_w)**2))/(((upper_w)**2) - ((inf_w)**2)))))

puts "03  IRL: #{inf_r}\n    IWL: #{inf_w}\n    RU: #{upper_r}\n    WL: #{weight}"
puts "      #{((inf_r)**(((weight)**2)/(((weight)**2) - ((inf_w)**2)))) * ((upper_r)**((-1*((inf_w)**2))/(((weight)**2) - ((inf_w)**2))))}"
            mr_vals.push(((inf_r)**(((weight)**2)/(((weight)**2) - ((inf_w)**2)))) * ((upper_r)**((-1*((inf_w)**2))/(((weight)**2) - ((inf_w)**2)))))

#puts "04  IRL: #{inf_r}\n    IWL: #{inf_w}\n    RU: #{upper_r}\n    WU: #{upper_w}"
#puts "      #{((inf_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_w)**2)))) * ((upper_r)**((-1*((inf_w)**2))/(((upper_w)**2) - ((inf_w)**2))))}"
#            mr_vals.push(((inf_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_w)**2)))) * ((upper_r)**((-1*((inf_w)**2))/(((upper_w)**2) - ((inf_w)**2)))))

#puts "05  IRL: #{inf_r}\n    IWU: #{inf_upper_w}\n    RL: #{reps}\n    WL: #{weight}"
#puts "      #{((inf_r)**(((weight)**2)/(((weight)**2) - ((inf_upper_w)**2)))) * ((reps)**((-1*((inf_upper_w)**2))/(((weight)**2) - ((inf_upper_w)**2))))}"
#            mr_vals.push(((inf_r)**(((weight)**2)/(((weight)**2) - ((inf_upper_w)**2)))) * ((reps)**((-1*((inf_upper_w)**2))/(((weight)**2) - ((inf_upper_w)**2)))))

#puts "06  IRL: #{inf_r}\n    IWU: #{inf_upper_w}\n    RL: #{reps}\n    WU: #{upper_w}"
#puts "      #{((inf_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_upper_w)**2)))) * ((reps)**((-1*((inf_upper_w)**2))/(((upper_w)**2) - ((inf_upper_w)**2))))}"
#            mr_vals.push(((inf_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_upper_w)**2)))) * ((reps)**((-1*((inf_upper_w)**2))/(((upper_w)**2) - ((inf_upper_w)**2)))))

#puts "07  IRL: #{inf_r}\n    IWU: #{inf_upper_w}\n    RU: #{upper_r}\n    WL: #{weight}"
#puts "      #{((inf_r)**(((weight)**2)/(((weight)**2) - ((inf_upper_w)**2)))) * ((upper_r)**((-1*((inf_upper_w)**2))/(((weight)**2) - ((inf_upper_w)**2))))}"
#            mr_vals.push(((inf_r)**(((weight)**2)/(((weight)**2) - ((inf_upper_w)**2)))) * ((upper_r)**((-1*((inf_upper_w)**2))/(((weight)**2) - ((inf_upper_w)**2)))))

puts "08  IRL: #{inf_r}\n    IWU: #{inf_upper_w}\n    RU: #{upper_r}\n    WU: #{upper_w}"
puts "      #{((inf_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_upper_w)**2)))) * ((upper_r)**((-1*((inf_upper_w)**2))/(((upper_w)**2) - ((inf_upper_w)**2))))}"
            mr_vals.push(((inf_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_upper_w)**2)))) * ((upper_r)**((-1*((inf_upper_w)**2))/(((upper_w)**2) - ((inf_upper_w)**2)))))

#puts "09  IRU: #{inf_upper_r}\n    IWL: #{inf_w}\n    RL: #{reps}\n    WL: #{weight}"
#puts "      #{((inf_upper_r)**(((weight)**2)/(((weight)**2) - ((inf_w)**2)))) * ((reps)**((-1*((inf_w)**2))/(((weight)**2) - ((inf_w)**2))))}"
#            mr_vals.push(((inf_upper_r)**(((weight)**2)/(((weight)**2) - ((inf_w)**2)))) * ((reps)**((-1*((inf_w)**2))/(((weight)**2) - ((inf_w)**2)))))

#puts "10  IRU: #{inf_upper_r}\n    IWL: #{inf_w}\n    RL: #{reps}\n    WU: #{upper_w}"
#puts "      #{((inf_upper_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_w)**2)))) * ((reps)**((-1*((inf_w)**2))/(((upper_w)**2) - ((inf_w)**2))))}"
#            mr_vals.push(((inf_upper_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_w)**2)))) * ((reps)**((-1*((inf_w)**2))/(((upper_w)**2) - ((inf_w)**2)))))

#puts "11  IRU: #{inf_upper_r}\n    IWL: #{inf_w}\n    RU: #{upper_r}\n    WL: #{weight}"
#puts "      #{((inf_upper_r)**(((weight)**2)/(((weight)**2) - ((inf_w)**2)))) * ((upper_r)**((-1*((inf_w)**2))/(((weight)**2) - ((inf_w)**2))))}"
#            mr_vals.push(((inf_upper_r)**(((weight)**2)/(((weight)**2) - ((inf_w)**2)))) * ((upper_r)**((-1*((inf_w)**2))/(((weight)**2) - ((inf_w)**2)))))

puts "12  IRU: #{inf_upper_r}\n    IWL: #{inf_w}\n    RU: #{upper_r}\n    WU: #{upper_w}"
puts "      #{((inf_upper_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_w)**2)))) * ((upper_r)**((-1*((inf_w)**2))/(((upper_w)**2) - ((inf_w)**2))))}"
            mr_vals.push(((inf_upper_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_w)**2)))) * ((upper_r)**((-1*((inf_w)**2))/(((upper_w)**2) - ((inf_w)**2)))))

#puts "13  IRU: #{inf_upper_r}\n    IWU: #{inf_upper_w}\n    RL: #{reps}\n    WL: #{weight}"
#puts "      #{((inf_upper_r)**(((weight)**2)/(((weight)**2) - ((inf_upper_w)**2)))) * ((reps)**((-1*((inf_upper_w)**2))/(((weight)**2) - ((inf_upper_w)**2))))}"
#            mr_vals.push(((inf_upper_r)**(((weight)**2)/(((weight)**2) - ((inf_upper_w)**2)))) * ((reps)**((-1*((inf_upper_w)**2))/(((weight)**2) - ((inf_upper_w)**2)))))

#puts "14  IRU: #{inf_upper_r}\n    IWU: #{inf_upper_w}\n    RL: #{reps}\n    WU: #{upper_w}"
#puts "      #{((inf_upper_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_upper_w)**2)))) * ((reps)**((-1*((inf_upper_w)**2))/(((upper_w)**2) - ((inf_upper_w)**2))))}"
#            mr_vals.push(((inf_upper_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_upper_w)**2)))) * ((reps)**((-1*((inf_upper_w)**2))/(((upper_w)**2) - ((inf_upper_w)**2)))))

#puts "15  IRU: #{inf_upper_r}\n    IWU: #{inf_upper_w}\n    RU: #{upper_r}\n    WL: #{weight}"
#puts "      #{((inf_upper_r)**(((weight)**2)/(((weight)**2) - ((inf_upper_w)**2)))) * ((upper_r)**((-1*((inf_upper_w)**2))/(((weight)**2) - ((inf_upper_w)**2))))}"
#            mr_vals.push(((inf_upper_r)**(((weight)**2)/(((weight)**2) - ((inf_upper_w)**2)))) * ((upper_r)**((-1*((inf_upper_w)**2))/(((weight)**2) - ((inf_upper_w)**2)))))

#puts "16  IRU: #{inf_upper_r}\n    IWU: #{inf_upper_w}\n    RU: #{upper_r}\n    WU: #{upper_w}"
#puts "      #{((inf_upper_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_upper_w)**2)))) * ((upper_r)**((-1*((inf_upper_w)**2))/(((upper_w)**2) - ((inf_upper_w)**2))))}"
#            mr_vals.push(((inf_upper_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_upper_w)**2)))) * ((upper_r)**((-1*((inf_upper_w)**2))/(((upper_w)**2) - ((inf_upper_w)**2)))))

          elsif d
          #near mr
            #calc mr using mw     
puts "Calc Mr using Mw"       
            mr_vals.push(emr)
puts "Mr Base: #{mr_vals[0]}"
#            mr_vals.push((reps)**(((emw)**2)/(((emw)**2) - ((weight)**2))))
#puts "  Mr 01: #{mr_vals[1]}"
#            mr_vals.push((upper_r)**(((emw)**2)/(((emw)**2) - ((weight)**2))))  
#puts "  Mr 02: #{mr_vals[2]}"
            mr_vals.push((reps)**(((emw)**2)/(((emw)**2) - ((upper_w)**2))))  
puts "  Mr 03: #{mr_vals[1]}"
            mr_vals.push((upper_r)**(((emw)**2)/(((emw)**2) - ((upper_w)**2))))  
puts "  Mr 04: #{mr_vals[2]}"

#            mr_vals.push((reps)**(((emw_upper)**2)/(((emw_upper)**2) - ((weight)**2))))
#puts "  Mr 05: #{mr_vals[5]}"
#            mr_vals.push((upper_r)**(((emw_upper)**2)/(((emw_upper)**2) - ((weight)**2))))  
#puts "  Mr 06: #{mr_vals[6]}"
            mr_vals.push((reps)**(((emw_upper)**2)/(((emw_upper)**2) - ((upper_w)**2))))  
puts "  Mr 07: #{mr_vals[3]}"
            mr_vals.push((upper_r)**(((emw_upper)**2)/(((emw_upper)**2) - ((upper_w)**2)))) 
puts "  Mr 08: #{mr_vals[4]}"

            #calc mw,mr using I
            #calc mw using I
            mw_vals.push(emw)
puts "Mw Base: #{emw}"
puts "Calc Mw using I:"

puts "01  IRL: #{inf_r}\n    IWL: #{inf_w}\n    RL: #{reps}\n    WL: #{weight}"
temp_irl = inf_r
temp_iwl = inf_w
temp_rl = reps
temp_wl = weight
inf_r = temp_rl
inf_w = temp_wl
reps = temp_irl
weight = temp_iwl
puts "      #{Math.sqrt(((((inf_w)**2)*(Math.log(reps)))-(((weight)**2)*(Math.log(inf_r))))/(Math.log(reps/inf_r)))}"
            mw_vals.push(Math.sqrt(((((inf_w)**2)*(Math.log(reps)))-(((weight)**2)*(Math.log(inf_r))))/(Math.log(reps/inf_r))))
temp_irl = inf_r
temp_iwl = inf_w
temp_rl = reps
temp_wl = weight
inf_r = temp_rl
inf_w = temp_wl
reps = temp_irl
weight = temp_iwl


puts "02  IRL: #{inf_r}\n    IWL: #{inf_w}\n    RL: #{reps}\n    WU: #{upper_w}"
temp_irl = inf_r
temp_iwl = inf_w
temp_rl = reps
temp_wl = upper_w
inf_r = temp_rl
inf_w = temp_wl
reps = temp_irl
upper_w = temp_iwl
puts "      #{Math.sqrt(((((inf_w)**2)*(Math.log(reps)))-(((upper_w)**2)*(Math.log(inf_r))))/(Math.log(reps/inf_r)))}"
            mw_vals.push(Math.sqrt(((((inf_w)**2)*(Math.log(reps)))-(((upper_w)**2)*(Math.log(inf_r))))/(Math.log(reps/inf_r))))
temp_irl = inf_r
temp_iwl = inf_w
temp_rl = reps
temp_wl = upper_w
inf_r = temp_rl
inf_w = temp_wl
reps = temp_irl
upper_w = temp_iwl

puts "03  IRL: #{inf_r}\n    IWL: #{inf_w}\n    RU: #{upper_r}\n    WL: #{weight}"
temp_irl = inf_r
temp_iwl = inf_w
temp_rl = upper_r
temp_wl = weight
inf_r = temp_rl
inf_w = temp_wl
upper_r = temp_irl
weight = temp_iwl
puts "      #{Math.sqrt(((((inf_w)**2)*(Math.log(upper_r)))-(((weight)**2)*(Math.log(inf_r))))/(Math.log(upper_r/inf_r)))}"
            mw_vals.push(Math.sqrt(((((inf_w)**2)*(Math.log(upper_r)))-(((weight)**2)*(Math.log(inf_r))))/(Math.log(upper_r/inf_r))))
temp_irl = inf_r
temp_iwl = inf_w
temp_rl = upper_r
temp_wl = weight
inf_r = temp_rl
inf_w = temp_wl
upper_r = temp_irl
weight = temp_iwl

puts "04  IRL: #{inf_r}\n    IWL: #{inf_w}\n    RU: #{upper_r}\n    WU: #{upper_w}"
temp_irl = inf_r
temp_iwl = inf_w
temp_rl = upper_r
temp_wl = upper_w
inf_r = temp_rl
inf_w = temp_wl
upper_r = temp_irl
upper_w = temp_iwl
puts "      #{Math.sqrt(((((inf_w)**2)*(Math.log(upper_r)))-(((upper_w)**2)*(Math.log(inf_r))))/(Math.log(upper_r/inf_r)))}"
            mw_vals.push(Math.sqrt(((((inf_w)**2)*(Math.log(upper_r)))-(((upper_w)**2)*(Math.log(inf_r))))/(Math.log(upper_r/inf_r))))
temp_irl = inf_r
temp_iwl = inf_w
temp_rl = upper_r
temp_wl = upper_w
inf_r = temp_rl
inf_w = temp_wl
upper_r = temp_irl
upper_w = temp_iwl

#puts "05  IRL: #{inf_r}\n    IWU: #{inf_upper_w}\n    RL: #{reps}\n    WL: #{weight}"
#temp_irl = inf_r
#temp_iwl = inf_upper_w
#temp_rl = reps
#temp_wl = weight
#inf_r = temp_rl
#inf_upper_w = temp_wl
#reps = temp_irl
#weight = temp_iwl
#puts "      #{Math.sqrt(((((inf_upper_w)**2)*(Math.log(reps)))-(((weight)**2)*(Math.log(inf_r))))/(Math.log(reps/inf_r)))}"
#            mw_vals.push(Math.sqrt(((((inf_upper_w)**2)*(Math.log(reps)))-(((weight)**2)*(Math.log(inf_r))))/(Math.log(reps/inf_r))))
#temp_irl = inf_r
#temp_iwl = inf_upper_w
#temp_rl = reps
#temp_wl = weight
#inf_r = temp_rl
#inf_upper_w = temp_wl
#reps = temp_irl
#weight = temp_iwl

#puts "06  IRL: #{inf_r}\n    IWU: #{inf_upper_w}\n    RL: #{reps}\n    WU: #{upper_w}"
#temp_irl = inf_r
#temp_iwl = inf_upper_w
#temp_rl = reps
#temp_wl = upper_w
#inf_r = temp_rl
#inf_upper_w = temp_wl
#reps = temp_irl
#upper_w = temp_iwl
#puts "      #{Math.sqrt(((((inf_upper_w)**2)*(Math.log(reps)))-(((upper_w)**2)*(Math.log(inf_r))))/(Math.log(reps/inf_r)))}"
#            mw_vals.push(Math.sqrt(((((inf_upper_w)**2)*(Math.log(reps)))-(((upper_w)**2)*(Math.log(inf_r))))/(Math.log(reps/inf_r))))
#temp_irl = inf_r
#temp_iwl = inf_upper_w
#temp_rl = reps
#temp_wl = upper_w
#inf_r = temp_rl
#inf_upper_w = temp_wl
#reps = temp_irl
#upper_w = temp_iwl

#puts "07  IRL: #{inf_r}\n    IWU: #{inf_upper_w}\n    RU: #{upper_r}\n    WL: #{weight}"
#temp_irl = inf_r
#temp_iwl = inf_upper_w
#temp_rl = upper_r
#temp_wl = weight
#inf_r = temp_rl
#inf_upper_w = temp_wl
#upper_r = temp_irl
#weight = temp_iwl
#puts "      #{Math.sqrt(((((inf_upper_w)**2)*(Math.log(upper_r)))-(((weight)**2)*(Math.log(inf_r))))/(Math.log(upper_r/inf_r)))}"
#            mw_vals.push(Math.sqrt(((((inf_upper_w)**2)*(Math.log(upper_r)))-(((weight)**2)*(Math.log(inf_r))))/(Math.log(upper_r/inf_r))))
#temp_irl = inf_r
#temp_iwl = inf_upper_w
#temp_rl = upper_r
#temp_wl = weight
#inf_r = temp_rl
#inf_upper_w = temp_wl
#upper_r = temp_irl
#weight = temp_iwl

#puts "08  IRL: #{inf_r}\n    IWU: #{inf_upper_w}\n    RU: #{upper_r}\n    WU: #{upper_w}"
#temp_irl = inf_r
#temp_iwl = inf_upper_w
#temp_rl = upper_r
#temp_wl = upper_w
#inf_r = temp_rl
#inf_upper_w = temp_wl
#upper_r = temp_irl
#upper_w = temp_iwl
#puts "      #{Math.sqrt(((((inf_upper_w)**2)*(Math.log(upper_r)))-(((upper_w)**2)*(Math.log(inf_r))))/(Math.log(upper_r/inf_r)))}"
#            mw_vals.push(Math.sqrt(((((inf_upper_w)**2)*(Math.log(upper_r)))-(((upper_w)**2)*(Math.log(inf_r))))/(Math.log(upper_r/inf_r))))
#temp_irl = inf_r
#temp_iwl = inf_upper_w
#temp_rl = upper_r
#temp_wl = upper_w
#inf_r = temp_rl
#inf_upper_w = temp_wl
#upper_r = temp_irl
#upper_w = temp_iwl

#puts "09  IRU: #{inf_upper_r}\n    IWL: #{inf_w}\n    RL: #{reps}\n    WL: #{weight}"
#temp_irl = inf_upper_r
#temp_iwl = inf_w
#temp_rl = reps
#temp_wl = weight
#inf_upper_r = temp_rl
#inf_w = temp_wl
#reps = temp_irl
#weight = temp_iwl
#puts "      #{Math.sqrt(((((inf_w)**2)*(Math.log(reps)))-(((weight)**2)*(Math.log(inf_upper_r))))/(Math.log(reps/inf_upper_r)))}"
#            mw_vals.push(Math.sqrt(((((inf_w)**2)*(Math.log(reps)))-(((weight)**2)*(Math.log(inf_upper_r))))/(Math.log(reps/inf_upper_r))))
#temp_irl = inf_upper_r
#temp_iwl = inf_w
#temp_rl = reps
#temp_wl = weight
#inf_upper_r = temp_rl
#inf_w = temp_wl
#reps = temp_irl
#weight = temp_iwl

#puts "10  IRU: #{inf_upper_r}\n    IWL: #{inf_w}\n    RL: #{reps}\n    WU: #{upper_w}"
#temp_irl = inf_upper_r
#temp_iwl = inf_w
#temp_rl = reps
#temp_wl = upper_w
#inf_upper_r = temp_rl
#inf_w = temp_wl
#reps = temp_irl
#upper_w = temp_iwl
#puts "      #{Math.sqrt(((((inf_w)**2)*(Math.log(reps)))-(((upper_w)**2)*(Math.log(inf_upper_r))))/(Math.log(reps/inf_upper_r)))}"
#            mw_vals.push(Math.sqrt(((((inf_w)**2)*(Math.log(reps)))-(((upper_w)**2)*(Math.log(inf_upper_r))))/(Math.log(reps/inf_upper_r))))
#temp_irl = inf_upper_r
#temp_iwl = inf_w
#temp_rl = reps
#temp_wl = upper_w
#inf_upper_r = temp_rl
#inf_w = temp_wl
#reps = temp_irl
#upper_w = temp_iwl

#puts "11  IRU: #{inf_upper_r}\n    IWL: #{inf_w}\n    RU: #{upper_r}\n    WL: #{weight}"
#temp_irl = inf_upper_r
#temp_iwl = inf_w
#temp_rl = upper_r
#temp_wl = weight
#inf_upper_r = temp_rl
#inf_w = temp_wl
#upper_r = temp_irl
#weight = temp_iwl
#puts "      #{Math.sqrt(((((inf_w)**2)*(Math.log(upper_r)))-(((weight)**2)*(Math.log(inf_upper_r))))/(Math.log(upper_r/inf_upper_r)))}"
#            mw_vals.push(Math.sqrt(((((inf_w)**2)*(Math.log(upper_r)))-(((weight)**2)*(Math.log(inf_upper_r))))/(Math.log(upper_r/inf_upper_r))))
#temp_irl = inf_upper_r
#temp_iwl = inf_w
#temp_rl = upper_r
#temp_wl = weight
#inf_upper_r = temp_rl
#inf_w = temp_wl
#upper_r = temp_irl
#weight = temp_iwl

#puts "12  IRU: #{inf_upper_r}\n    IWL: #{inf_w}\n    RU: #{upper_r}\n    WU: #{upper_w}"
#temp_irl = inf_upper_r
#temp_iwl = inf_w
#temp_rl = upper_r
#temp_wl = upper_w
#inf_upper_r = temp_rl
#inf_w = temp_wl
#upper_r = temp_irl
#upper_w = temp_iwl
#puts "      #{Math.sqrt(((((inf_w)**2)*(Math.log(upper_r)))-(((upper_w)**2)*(Math.log(inf_upper_r))))/(Math.log(upper_r/inf_upper_r)))}"
#            mw_vals.push(Math.sqrt(((((inf_w)**2)*(Math.log(upper_r)))-(((upper_w)**2)*(Math.log(inf_upper_r))))/(Math.log(upper_r/inf_upper_r))))
#temp_irl = inf_upper_r
#temp_iwl = inf_w
#temp_rl = upper_r
#temp_wl = upper_w
#inf_upper_r = temp_rl
#inf_w = temp_wl
#upper_r = temp_irl
#upper_w = temp_iwl

#puts "13  IRU: #{inf_upper_r}\n    IWU: #{inf_upper_w}\n    RL: #{reps}\n    WL: #{weight}"
#temp_irl = inf_upper_r
#temp_iwl = inf_upper_w
#temp_rl = reps
#temp_wl = weight
#inf_upper_r = temp_rl
#inf_upper_w = temp_wl
#reps = temp_irl
#weight = temp_iwl
#puts "      #{Math.sqrt(((((inf_upper_w)**2)*(Math.log(reps)))-(((weight)**2)*(Math.log(inf_upper_r))))/(Math.log(reps/inf_upper_r)))}"
#            mw_vals.push(Math.sqrt(((((inf_upper_w)**2)*(Math.log(reps)))-(((weight)**2)*(Math.log(inf_upper_r))))/(Math.log(reps/inf_upper_r))))
#temp_irl = inf_upper_r
#temp_iwl = inf_upper_w
#temp_rl = reps
#temp_wl = weight
#inf_upper_r = temp_rl
#inf_upper_w = temp_wl
#reps = temp_irl
#weight = temp_iwl

#puts "14  IRU: #inf_upper_r}\n    IWU: #{inf_upper_w}\n    RL: #{reps}\n    WU: #{upper_w}"
#temp_irl = inf_upper_r
#temp_iwl = inf_upper_w
#temp_rl = reps
#temp_wl = upper_w
#inf_upper_r = temp_rl
#inf_upper_w = temp_wl
#reps = temp_irl
#upper_w = temp_iwl
#puts "      #{Math.sqrt(((((inf_upper_w)**2)*(Math.log(reps)))-(((upper_w)**2)*(Math.log(inf_upper_r))))/(Math.log(reps/inf_upper_r)))}"
#            mw_vals.push(Math.sqrt(((((inf_upper_w)**2)*(Math.log(reps)))-(((upper_w)**2)*(Math.log(inf_upper_r))))/(Math.log(reps/inf_upper_r))))
#temp_irl = inf_upper_r
#temp_iwl = inf_upper_w
#temp_rl = reps
#temp_wl = upper_w
#inf_upper_r = temp_rl
#inf_upper_w = temp_wl
#reps = temp_irl
#upper_w = temp_iwl

#puts "15  IRU: #{inf_upper_r}\n    IWU: #{inf_upper_w}\n    RU: #{upper_r}\n    WL: #{weight}"
#temp_irl = inf_upper_r
#temp_iwl = inf_upper_w
#temp_rl = upper_r
#temp_wl = weight
#inf_upper_r = temp_rl
#inf_upper_w = temp_wl
#upper_r = temp_irl
#weight = temp_iwl
#puts "      #{Math.sqrt(((((inf_upper_w)**2)*(Math.log(upper_r)))-(((weight)**2)*(Math.log(inf_upper_r))))/(Math.log(upper_r/inf_upper_r)))}"
#            mw_vals.push(Math.sqrt(((((inf_upper_w)**2)*(Math.log(upper_r)))-(((weight)**2)*(Math.log(inf_upper_r))))/(Math.log(upper_r/inf_upper_r))))
#temp_irl = inf_upper_r
#temp_iwl = inf_upper_w
#temp_rl = upper_r
#temp_wl = weight
#inf_upper_r = temp_rl
#inf_upper_w = temp_wl
#upper_r = temp_irl
#weight = temp_iwl

#puts "16  IRU: #{inf_upper_r}\n    IWU: #{inf_upper_w}\n    RU: #{upper_r}\n    WU: #{upper_w}"
#temp_irl = inf_upper_r
#temp_iwl = inf_upper_w
#temp_rl = upper_r
#temp_wl = upper_w
#inf_upper_r = temp_rl
#inf_upper_w = temp_wl
#upper_r = temp_irl
#upper_w = temp_iwl
#puts "      #{Math.sqrt(((((inf_upper_w)**2)*(Math.log(upper_r)))-(((upper_w)**2)*(Math.log(inf_upper_r))))/(Math.log(upper_r/inf_upper_r)))}"
#            mw_vals.push(Math.sqrt(((((inf_upper_w)**2)*(Math.log(upper_r)))-(((upper_w)**2)*(Math.log(inf_upper_r))))/(Math.log(upper_r/inf_upper_r))))
#temp_irl = inf_upper_r
#temp_iwl = inf_upper_w
#temp_rl = upper_r
#temp_wl = upper_w
#inf_upper_r = temp_rl
#inf_upper_w = temp_wl
#upper_r = temp_irl
#upper_w = temp_iwl

            #calc mr using I
puts "Calc Mr using I:"

#puts "01  IRL: #{inf_r}\n    IWL: #{inf_w}\n    RL: #{reps}\n    WL: #{weight}"
#temp_irl = inf_r
#temp_iwl = inf_w
#temp_rl = reps
#temp_wl = weight
#inf_r = temp_rl
#inf_w = temp_wl
#reps = temp_irl
#weight = temp_iwl
#puts "      #{((inf_r)**(((weight)**2)/(((weight)**2) - ((inf_w)**2)))) * ((reps)**((-1*((inf_w)**2))/(((weight)**2) - ((inf_w)**2))))}"
#            mr_vals.push(((inf_r)**(((weight)**2)/(((weight)**2) - ((inf_w)**2)))) * ((reps)**((-1*((inf_w)**2))/(((weight)**2) - ((inf_w)**2)))))
#temp_irl = inf_r
#temp_iwl = inf_w
#temp_rl = reps
#temp_wl = weight
#inf_r = temp_rl
#inf_w = temp_wl
#reps = temp_irl
#weight = temp_iwl

puts "02  IRL: #{inf_r}\n    IWL: #{inf_w}\n    RL: #{reps}\n    WU: #{upper_w}"
temp_irl = inf_r
temp_iwl = inf_w
temp_rl = reps
temp_wl = upper_w
inf_r = temp_rl
inf_w = temp_wl
reps = temp_irl
upper_w = temp_iwl
puts "      #{((inf_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_w)**2)))) * ((reps)**((-1*((inf_w)**2))/(((upper_w)**2) - ((inf_w)**2))))}"
            mr_vals.push(((inf_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_w)**2)))) * ((reps)**((-1*((inf_w)**2))/(((upper_w)**2) - ((inf_w)**2)))))
temp_irl = inf_r
temp_iwl = inf_w
temp_rl = reps
temp_wl = upper_w
inf_r = temp_rl
inf_w = temp_wl
reps = temp_irl
upper_w = temp_iwl

#puts "03  IRL: #{inf_r}\n    IWL: #{inf_w}\n    RU: #{upper_r}\n    WL: #{weight}"
#temp_irl = inf_r
#temp_iwl = inf_w
#temp_rl = upper_r
#temp_wl = weight
#inf_r = temp_rl
#inf_w = temp_wl
#upper_r = temp_irl
#weight = temp_iwl
#puts "      #{((inf_r)**(((weight)**2)/(((weight)**2) - ((inf_w)**2)))) * ((upper_r)**((-1*((inf_w)**2))/(((weight)**2) - ((inf_w)**2))))}"
#            mr_vals.push(((inf_r)**(((weight)**2)/(((weight)**2) - ((inf_w)**2)))) * ((upper_r)**((-1*((inf_w)**2))/(((weight)**2) - ((inf_w)**2)))))
#temp_irl = inf_r
#temp_iwl = inf_w
#temp_rl = upper_r
#temp_wl = weight
#inf_r = temp_rl
#inf_w = temp_wl
#upper_r = temp_irl
#weight = temp_iwl

puts "04  IRL: #{inf_r}\n    IWL: #{inf_w}\n    RU: #{upper_r}\n    WU: #{upper_w}"
temp_irl = inf_r
temp_iwl = inf_w
temp_rl = upper_r
temp_wl = upper_w
inf_r = temp_rl
inf_w = temp_wl
upper_r = temp_irl
upper_w = temp_iwl
puts "      #{((inf_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_w)**2)))) * ((upper_r)**((-1*((inf_w)**2))/(((upper_w)**2) - ((inf_w)**2))))}"
            mr_vals.push(((inf_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_w)**2)))) * ((upper_r)**((-1*((inf_w)**2))/(((upper_w)**2) - ((inf_w)**2)))))
temp_irl = inf_r
temp_iwl = inf_w
temp_rl = upper_r
temp_wl = upper_w
inf_r = temp_rl
inf_w = temp_wl
upper_r = temp_irl
upper_w = temp_iwl

#puts "05  IRL: #{inf_r}\n    IWU: #{inf_upper_w}\n    RL: #{reps}\n    WL: #{weight}"
#temp_irl = inf_r
#temp_iwl = inf_upper_w
#temp_rl = reps
#temp_wl = weight
#inf_r = temp_rl
#inf_upper_w = temp_wl
#reps = temp_irl
#weight = temp_iwl
#puts "      #{((inf_r)**(((weight)**2)/(((weight)**2) - ((inf_upper_w)**2)))) * ((reps)**((-1*((inf_upper_w)**2))/(((weight)**2) - ((inf_upper_w)**2))))}"
#            mr_vals.push(((inf_r)**(((weight)**2)/(((weight)**2) - ((inf_upper_w)**2)))) * ((reps)**((-1*((inf_upper_w)**2))/(((weight)**2) - ((inf_upper_w)**2)))))
#temp_irl = inf_r
#temp_iwl = inf_upper_w
#temp_rl = reps
#temp_wl = weight
#inf_r = temp_rl
#inf_upper_w = temp_wl
#reps = temp_irl
#weight = temp_iwl

puts "06  IRL: #{inf_r}\n    IWU: #{inf_upper_w}\n    RL: #{reps}\n    WU: #{upper_w}"
temp_irl = inf_r
temp_iwl = inf_upper_w
temp_rl = reps
temp_wl = upper_w
inf_r = temp_rl
inf_upper_w = temp_wl
reps = temp_irl
upper_w = temp_iwl
puts "      #{((inf_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_upper_w)**2)))) * ((reps)**((-1*((inf_upper_w)**2))/(((upper_w)**2) - ((inf_upper_w)**2))))}"
            mr_vals.push(((inf_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_upper_w)**2)))) * ((reps)**((-1*((inf_upper_w)**2))/(((upper_w)**2) - ((inf_upper_w)**2)))))
temp_irl = inf_r
temp_iwl = inf_upper_w
temp_rl = reps
temp_wl = upper_w
inf_r = temp_rl
inf_upper_w = temp_wl
reps = temp_irl
upper_w = temp_iwl

#puts "07  IRL: #{inf_r}\n    IWU: #{inf_upper_w}\n    RU: #{upper_r}\n    WL: #{weight}"
#temp_irl = inf_r
#temp_iwl = inf_upper_w
#temp_rl = upper_r
#temp_wl = weight
#inf_r = temp_rl
#inf_upper_w = temp_wl
#upper_r = temp_irl
#weight = temp_iwl
#puts "      #{((inf_r)**(((weight)**2)/(((weight)**2) - ((inf_upper_w)**2)))) * ((upper_r)**((-1*((inf_upper_w)**2))/(((weight)**2) - ((inf_upper_w)**2))))}"
#            mr_vals.push(((inf_r)**(((weight)**2)/(((weight)**2) - ((inf_upper_w)**2)))) * ((upper_r)**((-1*((inf_upper_w)**2))/(((weight)**2) - ((inf_upper_w)**2)))))
#temp_irl = inf_r
#temp_iwl = inf_upper_w
#temp_rl = upper_r
#temp_wl = weight
#inf_r = temp_rl
#inf_upper_w = temp_wl
#upper_r = temp_irl
#weight = temp_iwl

puts "08  IRL: #{inf_r}\n    IWU: #{inf_upper_w}\n    RU: #{upper_r}\n    WU: #{upper_w}"
temp_irl = inf_r
temp_iwl = inf_upper_w
temp_rl = upper_r
temp_wl = upper_w
inf_r = temp_rl
inf_upper_w = temp_wl
upper_r = temp_irl
upper_w = temp_iwl
puts "      #{((inf_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_upper_w)**2)))) * ((upper_r)**((-1*((inf_upper_w)**2))/(((upper_w)**2) - ((inf_upper_w)**2))))}"
            mr_vals.push(((inf_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_upper_w)**2)))) * ((upper_r)**((-1*((inf_upper_w)**2))/(((upper_w)**2) - ((inf_upper_w)**2)))))
temp_irl = inf_r
temp_iwl = inf_upper_w
temp_rl = upper_r
temp_wl = upper_w
inf_r = temp_rl
inf_upper_w = temp_wl
upper_r = temp_irl
upper_w = temp_iwl

#puts "09  IRU: #{inf_upper_r}\n    IWL: #{inf_w}\n    RL: #{reps}\n    WL: #{weight}"
#temp_irl = inf_upper_r
#temp_iwl = inf_w
#temp_rl = reps
#temp_wl = weight
#inf_upper_r = temp_rl
#inf_w = temp_wl
#reps = temp_irl
#weight = temp_iwl
#puts "      #{((inf_upper_r)**(((weight)**2)/(((weight)**2) - ((inf_w)**2)))) * ((reps)**((-1*((inf_w)**2))/(((weight)**2) - ((inf_w)**2))))}"
#            mr_vals.push(((inf_upper_r)**(((weight)**2)/(((weight)**2) - ((inf_w)**2)))) * ((reps)**((-1*((inf_w)**2))/(((weight)**2) - ((inf_w)**2)))))
#temp_irl = inf_upper_r
#temp_iwl = inf_w
#temp_rl = reps
#temp_wl = weight
#inf_upper_r = temp_rl
#inf_w = temp_wl
#reps = temp_irl
#weight = temp_iwl

#puts "10  IRU: #{inf_upper_r}\n    IWL: #{inf_w}\n    RL: #{reps}\n    WU: #{upper_w}"
#temp_irl = inf_upper_r
#temp_iwl = inf_w
#temp_rl = reps
#temp_wl = upper_w
#inf_upper_r = temp_rl
#inf_w = temp_wl
#reps = temp_irl
#upper_w = temp_iwl
#puts "      #{((inf_upper_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_w)**2)))) * ((reps)**((-1*((inf_w)**2))/(((upper_w)**2) - ((inf_w)**2))))}"
#            mr_vals.push(((inf_upper_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_w)**2)))) * ((reps)**((-1*((inf_w)**2))/(((upper_w)**2) - ((inf_w)**2)))))
#temp_irl = inf_upper_r
#temp_iwl = inf_w
#temp_rl = reps
#temp_wl = upper_w
#inf_upper_r = temp_rl
#inf_w = temp_wl
#reps = temp_irl
#upper_w = temp_iwl

#puts "11  IRU: #{inf_upper_r}\n    IWL: #{inf_w}\n    RU: #{upper_r}\n    WL: #{weight}"
#temp_irl = inf_upper_r
#temp_iwl = inf_w
#temp_rl = upper_r
#temp_wl = weight
#inf_upper_r = temp_rl
#inf_w = temp_wl
#upper_r = temp_irl
#weight = temp_iwl
#puts "      #{((inf_upper_r)**(((weight)**2)/(((weight)**2) - ((inf_w)**2)))) * ((upper_r)**((-1*((inf_w)**2))/(((weight)**2) - ((inf_w)**2))))}"
#            mr_vals.push(((inf_upper_r)**(((weight)**2)/(((weight)**2) - ((inf_w)**2)))) * ((upper_r)**((-1*((inf_w)**2))/(((weight)**2) - ((inf_w)**2)))))
#temp_irl = inf_upper_r
#temp_iwl = inf_w
#temp_rl = upper_r
#temp_wl = weight
#inf_upper_r = temp_rl
#inf_w = temp_wl
#upper_r = temp_irl
#weight = temp_iwl

#puts "12  IRU: #{inf_upper_r}\n    IWL: #{inf_w}\n    RU: #{upper_r}\n    WU: #{upper_w}"
#temp_irl = inf_upper_r
#temp_iwl = inf_w
#temp_rl = upper_r
#temp_wl = upper_w
#inf_upper_r = temp_rl
#inf_w = temp_wl
#upper_r = temp_irl
#upper_w = temp_iwl
#puts "      #{((inf_upper_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_w)**2)))) * ((upper_r)**((-1*((inf_w)**2))/(((upper_w)**2) - ((inf_w)**2))))}"
#            mr_vals.push(((inf_upper_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_w)**2)))) * ((upper_r)**((-1*((inf_w)**2))/(((upper_w)**2) - ((inf_w)**2)))))
#temp_irl = inf_upper_r
#temp_iwl = inf_w
#temp_rl = upper_r
#temp_wl = upper_w
#inf_upper_r = temp_rl
#inf_w = temp_wl
#upper_r = temp_irl
#upper_w = temp_iwl

#puts "13  IRU: #{inf_upper_r}\n    IWU: #{inf_upper_w}\n    RL: #{reps}\n    WL: #{weight}"
#temp_irl = inf_upper_r
#temp_iwl = inf_upper_w
#temp_rl = reps
#temp_wl = weight
#inf_upper_r = temp_rl
#inf_upper_w = temp_wl
#reps = temp_irl
#weight = temp_iwl
#puts "      #{((inf_upper_r)**(((weight)**2)/(((weight)**2) - ((inf_upper_w)**2)))) * ((reps)**((-1*((inf_upper_w)**2))/(((weight)**2) - ((inf_upper_w)**2))))}"
#            mr_vals.push(((inf_upper_r)**(((weight)**2)/(((weight)**2) - ((inf_upper_w)**2)))) * ((reps)**((-1*((inf_upper_w)**2))/(((weight)**2) - ((inf_upper_w)**2)))))
#temp_irl = inf_upper_r
#temp_iwl = inf_upper_w
#temp_rl = reps
#temp_wl = weight
#inf_upper_r = temp_rl
#inf_upper_w = temp_wl
#reps = temp_irl
#weight = temp_iwl

#puts "14  IRU: #{inf_upper_r}\n    IWU: #{inf_upper_w}\n    RL: #{reps}\n    WU: #{upper_w}"
#temp_irl = inf_upper_r
#temp_iwl = inf_upper_w
#temp_rl = reps
#temp_wl = upper_w
#inf_upper_r = temp_rl
#inf_upper_w = temp_wl
#reps = temp_irl
#upper_w = temp_iwl
#puts "      #{((inf_upper_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_upper_w)**2)))) * ((reps)**((-1*((inf_upper_w)**2))/(((upper_w)**2) - ((inf_upper_w)**2))))}"
#            mr_vals.push(((inf_upper_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_upper_w)**2)))) * ((reps)**((-1*((inf_upper_w)**2))/(((upper_w)**2) - ((inf_upper_w)**2)))))
#temp_irl = inf_upper_r
#temp_iwl = inf_upper_w
#temp_rl = reps
#temp_wl = upper_w
#inf_upper_r = temp_rl
#inf_upper_w = temp_wl
#reps = temp_irl
#upper_w = temp_iwl

#puts "15  IRU: #{inf_upper_r}\n    IWU: #{inf_upper_w}\n    RU: #{upper_r}\n    WL: #{weight}"
#temp_irl = inf_upper_r
#temp_iwl = inf_upper_w
#temp_rl = upper_r
#temp_wl = weight
#inf_upper_r = temp_rl
#inf_upper_w = temp_wl
#upper_r = temp_irl
#weight = temp_iwl
#puts "      #{((inf_upper_r)**(((weight)**2)/(((weight)**2) - ((inf_upper_w)**2)))) * ((upper_r)**((-1*((inf_upper_w)**2))/(((weight)**2) - ((inf_upper_w)**2))))}"
#            mr_vals.push(((inf_upper_r)**(((weight)**2)/(((weight)**2) - ((inf_upper_w)**2)))) * ((upper_r)**((-1*((inf_upper_w)**2))/(((weight)**2) - ((inf_upper_w)**2)))))
#temp_irl = inf_upper_r
#temp_iwl = inf_upper_w
#temp_rl = upper_r
#temp_wl = weight
#inf_upper_r = temp_rl
#inf_upper_w = temp_wl
#upper_r = temp_irl
#weight = temp_iwl

#puts "16  IRU: #{inf_upper_r}\n    IWU: #{inf_upper_w}\n    RU: #{upper_r}\n    WU: #{upper_w}"
#temp_irl = inf_upper_r
#temp_iwl = inf_upper_w
#temp_rl = upper_r
#temp_wl = upper_w
#inf_upper_r = temp_rl
#inf_upper_w = temp_wl
#upper_r = temp_irl
#upper_w = temp_iwl
#puts "      #{((inf_upper_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_upper_w)**2)))) * ((upper_r)**((-1*((inf_upper_w)**2))/(((upper_w)**2) - ((inf_upper_w)**2))))}"
#            mr_vals.push(((inf_upper_r)**(((upper_w)**2)/(((upper_w)**2) - ((inf_upper_w)**2)))) * ((upper_r)**((-1*((inf_upper_w)**2))/(((upper_w)**2) - ((inf_upper_w)**2)))))
#temp_irl = inf_upper_r
#temp_iwl = inf_upper_w
#temp_rl = upper_r
#temp_wl = upper_w
#inf_upper_r = temp_rl
#inf_upper_w = temp_wl
#upper_r = temp_irl
#upper_w = temp_iwl

          end

          #average mw_vals
puts "Averaging Exercise Mw"
          mw_avg = 0.0
          mw_vals.each do |v|
puts "Mw value: #{v}"
            mw_avg += v
          end
          mw_avg = mw_avg/mw_vals.length
puts "Mw average: #{mw_avg}"

          #average mr_vals
puts "Averaging Exercise Mr"
          mr_avg = 0.0
          mr_vals.each do |v|
puts "Mr value: #{v}"
            mr_avg += v
          end
          mr_avg = mr_avg/mr_vals.length
puts "Mr average: #{mr_avg}"

          #set new values
puts "old mr: #{mr}"
puts "old mw: #{mw}"
          mr = (mr * 0.75) + (0.25 * ((mr_avg)/(t * (0.75 + (i * 0.025))))) 
          mw = (mw * 0.75) + (0.25 * ((mw_avg)/(t * (0.75 + (i * 0.025)))))
puts "new mr: #{mr}"
puts "new mw: #{mw}"
        end
      end      
    end
    UserBodyAreaFactor.create(user: user, body_area: e.primary_body_area, mr: mr, mw: mw)
  end
end
