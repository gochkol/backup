Given (0, Mr) && (Mw, 1)

y = ((Mr)**((((Mw)**2) - (x**2))/((Mw)**2)))

x = Math.sqrt(((Mw)**2)*(1 - ((Math.log(y))/(Math.log(Mr)))))

Given (w1, r1) && (w2, r2)

y = ((r1)**((((w2)**2) - ((x)**2))/(((w2)**2) - ((w1)**2)))) * ((r2)**((((x)**2) - ((w1)**2))/(((w2)**2) - ((w1)**2))))

x = Math.sqrt(((Math.log(y) * ((w2)**2 - (w1)**2))-(((w2)**2)*(Math.log(r1)))+(((w1)**2)*(Math.log(r2))))/(Math.log(r2/r1)))

       (Math.log(y) * ((w2)**2 - (w1)**2)) 
     - (((w2)**2)*(Math.log(r1)))
     + (((w1)**2)*(Math.log(r2)))

(Math.log(y) * ((w2)**2 - (w1)**2))-(((w2)**2)*(Math.log(r1)))+(((w1)**2)*(Math.log(r2)))




  r1 = [r1, r1+1]
  r2 = [r2, r2+1]
  w1 = [w1, w1+5]
  w2 = [w2, w2+5]

  r1.each do |r1v|
    w1.each do |w1v|
      r2.each do |r2v|
        w2.each do |w2v|
            mw_vals.push( Math.sqrt(((((w1v)**2)*(Math.log(r2v)))-(((w2v)**2)*(Math.log(r1v))))/(Math.log(r2v/r1v))) )
        end
      end
    end
  end

  r1.each do |r1v|
    w1.each do |w1v|
      r2.each do |r2v|
        w2.each do |w2v|
          mr_vals.push(((r1v)**(((w2v)**2)/(((w2v)**2) - ((w1v)**2)))) * ((r2v)**((-1*((w1v)**2))/(((w2v)**2) - ((w1v)**2)))))
        end
      end
    end
  end
