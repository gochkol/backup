(function(){
  'use strict';

  angular
    .module('app')
    .provider('stateConfig', stateConfigProvider);

  stateConfigProvider.$inject = ['$stateProvider', 'userDataProvider'];

  function stateConfigProvider($stateProvider, userDataProvider){
    var provider = {
      initialize: initialize,
      $get: stateHelperFactory
    }

    return provider;

    function getNavView(){
      return {
        controller: 'NavController',
        controllerAs: 'nav',
        resolve: {
          userDataSet: ['userData', function(userData){
            if (!userData.isLoggedIn()){
              return {};
            }
            else if (userData.isGuest()){
              return userData.getDataSet(['user']);
            }
            else{
              return userData.getDataSet(['user', 'friends', 'friendRequestsForMe', 'friendRequestsFromMe']);
            }
          }]
        }
      }
    };

    function initialize(){
      $stateProvider.state('login', {
        url: '/login',
        data: {loginNotRequired: true},
        views: {
          nav: getNavView(),
          content: {
            controller: 'LoginController',
            controllerAs: 'login',
            templateUrl: 'app/login/login.html'
          }
        }
      })

      $stateProvider.state('logout', {
        url: '/logout',
        data: {loginNotRequired: true},
        views: {
          content: {
            controller: 'LogoutController',
            controllerAs: 'logout'
          }
        }
      })

      $stateProvider.state('resetPassword', {
        url: '/password/reset',
        data: {loginNotRequired: true},
        views: {
          content: {
            controller: 'ResetController',
            controllerAs: 'reset',
            templateUrl: 'app/reset/reset.html'
          }
        }
      })

      $stateProvider.state('newPassword', {
        url: '/password/new',
        data: {loginNotRequired: true},
        views: {
          content: {
            controller: 'NewPasswordController',
            controllerAs: 'reset',
            templateUrl: 'app/reset/new.html'
          }
        }
      })

      $stateProvider.state('checkEmail', {
        url: '/checkEmail',
        data: {loginNotRequired: true},
        views: {
          content: {
            templateUrl: 'app/reset/checkEmail.html'
          }
        }
      })

      $stateProvider.state('home', {
        url: '/home',
        views: {
          nav: getNavView(),
          content: {
            controller: 'HomeController',
            controllerAs: 'home',
            templateUrl: 'app/home/home.html',
            resolve: {
              userDataSet: ['userData', function(userData){
                return userData.getDataSet(['user', 'events', 'friends'])
              }],
              globalDataSet: ['globalData', function(globalData){
                return globalData.getAll();
              }]
            }
          }
        }
      });

      $stateProvider.state('customizeWorkout', {
        url: '/workout/customize',
        data: {guestAccessOK: true},
        views: {
          nav: getNavView(),
          content: {
            controller: 'CustomizeWorkoutController',
            controllerAs: 'customize',
            templateUrl: 'app/workout/customize/customize.html',
            resolve: {
              globalDataSet: ['globalData', function(globalData){
                return globalData.getAll();
              }],
              userDataSet: ['userData', function(userData){
                return userData.getDataSet([
                  'user',
				  'userHistory',
				  'favorites'
                ]);
              }],
              workoutData: ['workout', function(workout){
                return workout.getWorkout();
              }]
            }
          }
        }
      });

      $stateProvider.state('quickWorkout', {
        url: '/workout/quick',
        data: {guestAccessOK: true},
        views: {
          nav: getNavView(),
          content: {
            controller: 'QuickWorkoutController',
            controllerAs: 'quick',
            templateUrl: 'app/workout/quick/quick.html',
            resolve: {
              userDataSet: ['userData', function(userData){
                return userData.getDataSet([
                  'user',
                  'locations',
				  'userHistory'
                ]);
              }],
              globalDataSet: ['globalData', function(globalData){
                return globalData.getAll();
              }]
            }
		  },
          "bodyAreas@quickWorkout": {
            templateUrl: 'app/workout/quick/bodyAreas.html'
          },
          "intensity@quickWorkout": {
            templateUrl: 'app/workout/quick/intensity.html'
          },
          "locale@quickWorkout": {
            templateUrl: 'app/workout/quick/locale.html'
          },
          "time@quickWorkout": {
            templateUrl: 'app/workout/quick/time.html'
          },
          "type@quickWorkout": {
            templateUrl: 'app/workout/quick/type.html'
          }
        }
      });

      $stateProvider.state('favorites', {
        url: '/favorites',
        views: {
          nav: getNavView(),
          content: {
            controller: 'FavoritesController',
            controllerAs: 'favorites',
            templateUrl: 'app/favorites/favorites.html',
            resolve: {
              userDataSet: ['userData', function(userData){
                return userData.getDataSet([
                  'user',
                  'favorites'
                ]);
              }]
            }
          }
        }
      });

      $stateProvider.state('profile', {
        url: '/profile',
        views: {
          nav: getNavView(),
          content: {
            controller: 'ProfileController',
            controllerAs: 'profile',
            templateUrl: 'app/profile/profile.html',
           resolve: {
             userDataSet: ['userData', function(userData){
                return userData.getDataSet([
                  'user',
				  'points',
                  'bodyStats',
                  'bodyPartStats',
                  'userHistory'
                ]);
              }],
              globalDataSet: ['globalData', function(globalData){
                return globalData.getAll();
              }]
            }
          }
        }
      });

      $stateProvider.state('settings', {
        url: '/settings',
        views: {
          nav: getNavView(),
          content: {
            controller: 'SettingsController',
            controllerAs: 'settings',
            templateUrl: 'app/settings/settings.html',
            resolve: {
              userDataSet: ['userData', function(userData){
                return userData.getDataSet(['user']);
              }],
              globalDataSet: ['globalData', function(globalData){
                return globalData.getAll();
              }]
            }
          }
        }
      });

      $stateProvider.state('stats', {
        url: '/stats',
        views: {
          nav: getNavView(),
          content: {
            controller: 'StatsController',
            controllerAs: 'stats',
            templateUrl: 'app/stats/stats.html',
            resolve: {
              userDataSet: ['userData', function(userData){
                return userData.getDataSet(['user', 'blockStats']);
              }],
              globalDataSet: ['globalData', function(globalData){
                return globalData.getAll();
              }]
            }
          }
        }
      });

      $stateProvider.state('company', {
        url: '/company',
        views: {
          nav: getNavView(),
          content: {
            controller: 'CompanyController',
            controllerAs: 'company',
            templateUrl: 'app/company/company.html',
            resolve: {
              userDataSet: ['userData', function(userData){
                return userData.getDataSet([
                  'user',
                  'company'
                ]);
              }],
              globalDataSet: ['globalData', function(globalData){
                return globalData.getAll();
              }]
            }
          }
        }
      });

      $stateProvider.state('friend', {
        url: '/friend',
        views: {
          nav: getNavView(),
          content: {
            controller: 'FriendController',
            controllerAs: 'friend',
            templateUrl: 'app/friend/friend.html',
            resolve: {
              globalDataSet: ['globalData', function(globalData){
                return globalData.getAll();
              }],
              userDataSet: ['userData', function(userData){
                return userData.getDataSet([
                  'user',
				  'favorites',
                  'friends',
                  'friendRequestsForMe',
                  'friendRequestsFromMe'
                ]);
              }],
              friendData: ['userData', function(userData){
                return userData.getFriend();
              }]
            }
          }
        }
      });

      $stateProvider.state('friends', {
        url: '/friends',
        views: {
          nav: getNavView(),
          content: {
            controller: 'FriendsController',
            controllerAs: 'friends',
            templateUrl: 'app/friends/friends.html',
            resolve: {
			  globalDataSet: ['globalData', function(globalData){
                return globalData.getAll();
              }],
              userDataSet: ['userData', function(userData){
                return userData.getDataSet([
                  'user',
                  'friends',
                  'friendRequestsForMe',
                  'friendRequestsFromMe'
                ]);
              }]
            }
          }
        }
      });

      $stateProvider.state('quickLog', {
        url: '/quickLog',
        views: {
          nav: getNavView(),
          content: {
            controller: 'QuickLogController',
            controllerAs: 'quickLog',
            templateUrl: 'app/quicklog/quicklog.html',
            resolve: {
              userDataSet: ['userData', function(userData){
                return userData.getDataSet(['user']);
              }],
              globalDataSet: ['globalData', function(globalData){
                return globalData.getAll();
              }]
            }
          }
        }
      });

      $stateProvider.state('locations', {
        url: '/locations',
        views: {
          nav: getNavView(),
          content: {
            controller: 'LocationsController',
            controllerAs: 'locations',
            templateUrl: 'app/locations/locations.html',
            resolve: {
              userDataSet: ['userData', function(userData){
                return userData.getDataSet(['user', 'locations']);
              }],
              globalDataSet: ['globalData', function(globalData){
                return globalData.getAll();
              }]
            }
          }
        }
      });

      $stateProvider.state('guest', {
        url: '/guest',
        data: {loginNotRequired: true},
        views: {
          nav: getNavView(),
          content: {
            controller: 'GuestController',
            controllerAs: 'guest',
            templateUrl: 'app/guest/guest.html',
            resolve: {
              globalDataSet: ['globalData', function(globalData){
                return globalData.getAll();
              }]
            }
          }
        }
      });

      $stateProvider.state('signup', {
        url: '/signup',
        data: {loginNotRequired: true},
        views: {
          content: {
            controller: 'SignupController',
            controllerAs: 'signup',
            templateUrl: 'app/signup/signup.html',
            resolve: {
              globalDataSet: ['globalData', function(globalData){
                return globalData.getAll();
              }]
            }
          }
        }
      });

      $stateProvider.state('exercise', {
        url: '/workout/exercise',
        data: {guestAccessOK: true},
        views: {
          nav: getNavView(),
          content: {
            controller: 'ExerciseController',
            controllerAs: 'exercise',
            templateUrl: 'app/exercise/exercise.html',
            resolve: {
              userDataSet: ['userData', function(userData){
               return userData.getDataSet([
                 'user',
                 'events',
                 'bodyStats',
				 'userHistory'
               ]);
              }],
              globalDataSet: ['globalData', function(globalData){
                return globalData.getAll();
              }],
              workoutData: ['workout', function(workout){
                return workout.getWorkout();
              }]
            }
          }
        }
      });

      $stateProvider.state('summary', {
        url: '/workout/summary',
        data: {guestAccessOK: true},
        views: {
          content: {
            controller: 'SummaryController',
            controllerAs: 'summary',
            templateUrl: 'app/workout/summary/summary.html',
            resolve: {
              globalDataSet: ['globalData', function(globalData){
                return globalData.getAll();
              }],
              userDataSet: ['userData', function(userData){
                return userData.getDataSet([
                  'user',
				  'userHistory',
				  'favorites'
                ]);
              }],
              workoutData: ['workout', function(workout){
                return workout.getWorkout();
              }]
            }
          }
        }
      });


    }

    stateHelperFactory.$inject = ['$rootScope', '$http', '$location', 'globalData', 'userData'];

    function stateHelperFactory($rootScope, $http, $location, globalData, userData){
      var factory = {
        initialize: initialize
      }
      return factory;

      function initialize(){
        $rootScope.$on('$stateChangeSuccess', stateChanged);
      }

      function stateChanged(event, toState, toParams, fromState, fromParams){
        // this is where the state is looked at and preloading of stuff is done
        if (toState.name == 'login'){
          userData.clearData();
          globalData.getAll(true);
        }
      }


    }
  }
})();


