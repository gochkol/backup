(function(){
  'use strict';

  angular
    .module('app')
    .run(appRun);

  appRun.$inject = ['$rootScope', '$state', '$window', 'store', 'jwtHelper', 'config', 'globalData', 'stateConfig', 'userData', 'angularFilepicker', 'workout', 'modalUtils', 'exerciser'];

  function appRun($rootScope, $state, $window, store, jwtHelper, config, globalData, stateConfig, userData, angularFilepicker, workout, modalUtils, exerciser){
    var statesThatDontRequireAuth = ['login', 'signup', 'reset', 'misfire'];
    $rootScope.isLoggedIn = userData.isLoggedIn;
    $rootScope.isGuest = userData.isGuest;
    $rootScope.isInTransition = false;
    $rootScope.facebookAppId = '[1047666361934320]';

    $rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams){
      var loginRequired = (!toState.data || !toState.data.loginNotRequired);
      var guestAllowed = (toState.data && toState.data.guestAccessOK);
      var guestNotAllowed = (loginRequired && !guestAllowed);
      var isLoggedIn = userData.isLoggedIn();
      var isGuest = userData.isGuest();

      // HANDLE ui-router view based on guest state
      if (toState && toState.views && toState.views.nav){
        if (isGuest){
          toState.views.nav.templateUrl = 'app/nav/guestNav.html';
        }
        else{
          toState.views.nav.templateUrl = 'app/nav/userNav.html';
        }
      }

      if (fromState.name == 'login' && loginRequired){
        return;
      }

      if(toState.name == 'login' && isLoggedIn){
        event.preventDefault();
        $state.go('logout');
        return;
      }

      // HANDLE ui-router state policy
      if ((loginRequired && !isLoggedIn) || (isLoggedIn && isGuest && guestNotAllowed)){
        event.preventDefault();
        $state.go('login');
        return;
      }

      if (isGuest && toState.name != 'login' && fromState.name == 'summary'){
        if(toState.name != 'logout'){
          event.preventDefault();
          $state.go('login');
        }
        return;
      }

      if (!isGuest){
        if ((fromState.name == 'customizeWorkout' && toState.name != 'exercise') ||
                 (fromState.name == 'exercise' && toState.name != 'summary') ||
                 (fromState.name == 'summary' && toState.name != 'home')){
          if ($rootScope.isInTransition){
            $rootScope.isInTransition = false;
          }
          else{
            event.preventDefault();
            modalUtils.launch('youSure', function(){
              $rootScope.isInTransition = true;
              workout.clear();
              exerciser.clear();
              if (toState.name == 'customizeWorkout' || toState.name == 'exercise'){
                $state.go('home');
              }
              else{
                $state.go(toState.name);
              }
            });
          };
        }
      }
    });

    $rootScope.$on('$stateChangeError', function(event, toState, toParams, fromState, fromParams, errorText){
      event.preventDefault();
      errorText = errorText || "Could not transition to desired page.";
      modalUtils.launch('error', errorText);
      // WARNING!
      // do not go to a state from here since this can lead to infinite loop that would freeze the browser or
      // mobile device and our users would hate us
      // $state.go('home'); <------- BAD
    });

    $window.onbeforeunload = function(event){

      var states = ['customizeWorkout', 'exercise', 'summary'];

      if (states.indexOf($state.current.name) >= 0){
        return "Are you sure you want to leave?  If so, changes will be lost.";
      }
    };

    angularFilepicker.setKey('Ap4XIwSo4SZuHDiHiSFrjz');

    config.initialize();
    globalData.initialize();
    userData.initialize();
    stateConfig.initialize();
    workout.initialize();
  }

  function getNavView(isGuest){
    var template =  'nav';
    return {
      controller: 'NavController',
      controllerAs: 'nav',
      templateUrl: 'app/nav/' + template + '.html',
      resolve: {
        userDataSet: ['userData', function(userData){
          return userData.getDataSet([
            'user',
            'friends',
            'friendRequestsForMe',
            'friendRequestsFromMe'
          ]);
        }]
      }
    };
  }

})();
