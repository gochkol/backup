(function(){
  'use strict';

  angular
    .module('app.guest')
    .controller('GuestController', GuestController);

  GuestController.$inject = ['globalDataSet', 'globalData', '$modal', 'auth', 'config', 'constants'];

  function GuestController(globalDataSet, globalData, $modal,  auth, config, constants){
    var vm = this;
    vm.user = {};
    vm.submit = submit;

    function submit(){
      auth.createGuest(vm.user);
    }
  }

})();

