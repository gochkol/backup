(function () {
  'use strict';

  angular
    .module('app.stats')
    .controller('StatsController', StatsController);

  StatsController.$inject = ['$state', 'globalData', 'globalDataSet', 'userData', 'userDataSet', 'constants', 'config', 'infoFactory'];

  function StatsController($state, globalData, globalDataSet, userData, userDataSet, constants, config, infoFactory) {
    var vm = this;
    vm.user = userDataSet.user;
    vm.blockStats = userDataSet.blockStats;
    vm.globalDataSet = globalDataSet;
  }

})();

