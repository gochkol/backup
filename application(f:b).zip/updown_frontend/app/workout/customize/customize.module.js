(function () {
  'use strict';

  angular
    .module('app.workout.customize', []);

})();

