(function () {
  'use strict';

  angular
    .module('app.workout.quick', []);

})();


