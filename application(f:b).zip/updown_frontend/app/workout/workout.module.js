(function () {
  'use strict';

  angular
    .module('app.workout', [
      'app.workout.customize',
      'app.workout.quick',
      'app.workout.summary'
    ]);

})();

